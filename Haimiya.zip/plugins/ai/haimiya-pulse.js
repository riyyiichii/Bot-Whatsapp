// cr: haimiya md saca
// ai/haimiya — satu file: metadata + kode fitur (gabungan dari engine5/plugins/ai/haimiya.js)
const __hm = require("../../lib/adapter/e5.js")
const __meta = {
  "name": "Haimiya MD",
  "command": [
    "haimiya-pulse"
  ],
  "category": "ai",
  "desc": "Fitur Haimiya MD <pesan>",
  "usage": ".haimiya <pesan>",
  "limit": true
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/ai").split('\\').join('/')
module.exports = __hm.plugin("ai/haimiya", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/haimiya.js'
  const __hmExports = {};
  const handler = async (m, { sock, text, reply, example }) => {
  	if (!text) return reply(example('hai'));
  
  	await sock.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
  
  	try {
  		const data = await global.fetchApi('kyzz', '/api/ai/alya', {
  			message: text,
  			session: m.sender
  		});
  
  		if (!data.status) {
  			await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
  			return reply(data.message || 'Terjadi kesalahan dari API.');
  		}
  
  		const responseText = data.reply || data.result?.reply || data.result || 'Tidak ada balasan.';
  
  		await sock.sendMessage(m.chat, { react: { text: '✨', key: m.key } });
  		return reply(responseText);
  
  	} catch (e) {
  		console.error('[Haimiya MD ERROR]', e.response?.data || e.message);
  		await sock.sendMessage(m.chat, { react: { text: '⚠️', key: m.key } });
  		return reply('❌ Gagal menghubungi Haimiya MD.');
  	}
  };
  
  handler.help = ['Haimiya MD <pesan>'];
  handler.tags = ['ai'];
  handler.command = ['Haimiya MD'];
  handler.limit = true;
  
  const __hmDefault = handler;
  Object.defineProperty(__hmExports, "default", { enumerable: true, get: () => __hmDefault });
  return __hmExports
})
