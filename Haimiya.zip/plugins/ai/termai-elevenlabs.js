// cr: haimiya md saca
// fitur tambahan Haimiya MD (ai/termai-elevenlabs)
module.exports = require('../../lib/adapter/e9.js').plugin("ai/termai-elevenlabs", {"command":["elevenlabs","eleven","ttsel"],"category":"ai","desc":"Fitur elevenlabs <teks>","usage":".elevenlabs"})
