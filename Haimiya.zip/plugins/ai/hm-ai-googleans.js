// cr: haimiya md saca
// Plugin Haimiya MD (ai/googleans.js) — dijalankan lewat lib/haimiya-bridge.js
module.exports = require('../../lib/haimiya-bridge.js').bridge(require('../../lib/haimiya/plugins/ai/googleans.js'), { category: 'ai', name: 'ai-googleans' })
