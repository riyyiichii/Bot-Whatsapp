// cr: haimiya md saca
// Plugin Haimiya MD (ai/claude.js) — dijalankan lewat lib/haimiya-bridge.js
module.exports = require('../../lib/haimiya-bridge.js').bridge(require('../../lib/haimiya/plugins/ai/claude.js'), { category: 'ai', name: 'ai-claude' })
