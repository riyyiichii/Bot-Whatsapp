// cr: haimiya md saca
// Plugin Haimiya MD (ai/qwerty.js) — dijalankan lewat lib/haimiya-bridge.js
module.exports = require('../../lib/haimiya-bridge.js').bridge(require('../../lib/haimiya/plugins/ai/qwerty.js'), { category: 'ai', name: 'ai-qwerty' })
