// cr: haimiya md saca
// Plugin Haimiya MD (ai/aicover.js) — dijalankan lewat lib/haimiya-bridge.js
module.exports = require('../../lib/haimiya-bridge.js').bridge(require('../../lib/haimiya/plugins/ai/aicover.js'), { category: 'ai', name: 'ai-aicover' })
