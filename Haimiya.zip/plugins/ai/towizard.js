// cr: haimiya md saca
// ai-image/towizard — satu file: metadata + kode fitur (gabungan dari engine5/plugins/ai-image/towizard.js)
const __hm = require("../../lib/adapter/e5.js")
const __meta = {
  "name": "towizard",
  "command": [
    "towizard"
  ],
  "category": "ai",
  "desc": "Fitur towizard (reply foto)",
  "usage": ".towizard (reply foto)",
  "limit": true
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/ai-image").split('\\').join('/')
module.exports = __hm.plugin("ai-image/towizard", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/towizard.js'
  const __hmDef = (m) => (m && m.__esModule ? m.default : m);
  const __hmExports = {};
  const axios = __hmDef(require("axios"));
  const FormData = __hmDef(require("form-data"));
  
  async function uploadUguu(buffer, filename = 'image.jpg') {
    const form = new FormData();
    form.append('files[]', buffer, { filename, contentType: 'image/jpeg' });
    const { data } = await axios.post('https://uguu.se/upload', form, { headers: { ...form.getHeaders() } });
    return data?.files?.[0]?.url || null;
  }
  
  const PROMPT = 'transform into wizard, long beard, pointed hat, staff, spellbook, magical aura, while keeping the same original face and only changing the outfit';
  
  const handler = async (m, { sock, qmsg, mime, reply, usedPrefix, command }) => {
    if (!/^image\//.test(mime || '')) return reply(`❌ Reply/kirim gambar dengan caption *${usedPrefix + command}*`);
    await sock.sendMessage(m.chat, { react: { text: '🧙‍♂️', key: m.key } }).catch(() => null);
  
    try {
      const buffer = await qmsg.download().catch(() => null);
      if (!buffer) return reply('❌ Gagal mengunduh gambar!');
  
      const uguuUrl = await uploadUguu(buffer, `${command}-${Date.now()}.jpg`);
      if (!uguuUrl) return reply('❌ Gagal upload gambar ke Uguu!');
  
      const apiUrl = `https://api-faa.my.id/faa/editfoto?url=${encodeURIComponent(uguuUrl)}&prompt=${encodeURIComponent(PROMPT)}`;
      const response = await axios.get(apiUrl, { responseType: 'arraybuffer', timeout: 60000 });
  
      await sock.sendMessage(m.chat, { image: Buffer.from(response.data), caption: '✅ Done' }, { quoted: m });
      await sock.sendMessage(m.chat, { react: { text: '✅', key: m.key } }).catch(() => null);
    } catch (e) {
      console.error(`[${command.toUpperCase()} ERROR]:`, e);
      await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => null);
      reply('❌ Gagal memproses gambar pada API Edit Foto!');
    }
  };
  
  handler.help = ['towizard (reply foto)'];
  handler.tags = ['maker', 'ai'];
  handler.command = ['towizard'];
  handler.limit = true;
  
  const __hmDefault = handler;
  Object.defineProperty(__hmExports, "default", { enumerable: true, get: () => __hmDefault });
  return __hmExports
})
