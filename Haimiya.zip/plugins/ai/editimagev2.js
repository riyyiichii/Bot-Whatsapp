// cr: haimiya md saca
// ai/editimagev2 — fitur tambahan (plugins.zip), disesuaikan untuk Haimiya MD
const __hm = require("../../lib/adapter/e2.js")
const __meta = {
  "command": [
    "editimagev2"
  ],
  "category": "ai",
  "owner": false,
  "group": false,
  "admin": false,
  "botAdmin": false,
  "desc": "Fitur editimagev2",
  "usage": ".editimagev2 <prompt>"
}
const __vdir = __dirname.split('\\').join('/')
module.exports = __hm.plugin("vxnew/ai/editimagev2", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + "/editimagev2.js"
  const __hmDef = (m) => (m && m.__esModule ? m.default : m);
  const __hmImp = async (m) => { const r = require(m); return r && r.__esModule ? r : Object.assign({ default: r }, r) };
  const __hmExports = {};
  const uploadImage = __hmDef(require("../../lib/newlib/upload.js"));
  
  let handler = async (m, { conn, usedPrefix, command, args }) => {
    try {
      const prompt = args.join(' ');
      if (!prompt) return m.reply(`⚠️ Masukkan prompt editan!\nContoh: ${usedPrefix + command} ubah jadi rambut merah`);
      
      const q = m.quoted ? m.quoted : m;
      const mime = q?.msg?.mimetype || q?.mimetype || "";
      if (!/image/.test(mime)) {
        return m.reply(`⚠️ Reply gambar dengan caption ${usedPrefix + command} <prompt>`);
      }
      
      await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
      
      const media = await q.download();
      let url;
      try {
        url = await uploadImage(media);
      } catch (e) {
        return m.reply('❌ Gagal mengupload gambar ke server temporary. Coba lagi.');
      }
  
      const apiUrl = `${global.web}/api/ai/editimagev2?apikey=${global.apikey?.vxapi}`;
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ image_url: url, prompt: prompt })
      });
      const json = await response.json();
      
      if (!json.status) {
        throw new Error(json.error || json.detail || json.message || "Gagal mendapatkan respons");
      }
      
      let resultUrl = json.result?.image || json.result?.url || json.result?.image_url || json.data?.image || json.data?.url || (Array.isArray(json.result) ? json.result[0] : json.result) || json.data;
      if (typeof resultUrl === 'object' && resultUrl !== null) {
        resultUrl = resultUrl.url || resultUrl.image || JSON.stringify(resultUrl);
      }
      
      if (typeof resultUrl === 'string' && resultUrl.startsWith('http')) {
        await conn.sendMessage(m.chat, {
          image: { url: resultUrl },
          caption: `✅ *Edit Image V2 Success!*\n📝 *Prompt:* ${prompt}`
        }, { quoted: m }).catch(e => m.reply("Gagal mengirim media, ini linknya: " + resultUrl));
        await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
      } else {
        throw new Error("Format URL hasil gambar tidak valid");
      }
    } catch (e) {
      console.error(e);
      await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
      m.reply("❌ Error: " + (e.message || "Terjadi kesalahan internal"));
    }
  };
  
  handler.premium = true;
  handler.help = ["editimagev2 <prompt>"];
  handler.command = ["editimagev2"];
  handler.tags = ["ai"];
  handler.limit = 2;
  
  
  
  const __hmDefault = handler

  Object.defineProperty(__hmExports, "default", { enumerable: true, get: () => __hmDefault });
  for (const k of ['before', 'all']) { if (typeof __hmExports[k] === 'function' && typeof __hmDefault === 'function' && !__hmDefault[k]) __hmDefault[k] = __hmExports[k] }
  return __hmExports
})
