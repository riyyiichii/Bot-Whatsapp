// cr: haimiya md saca
// ai-image/tobabi — satu file: metadata + kode fitur (gabungan dari engine5/plugins/ai-image/tobabi.js)
const __hm = require("../../lib/adapter/e5.js")
const __meta = {
  "name": "tobabi",
  "command": [
    "tobabi"
  ],
  "category": "ai",
  "desc": "Fitur tobabi (reply gambar)",
  "usage": ".tobabi (reply gambar)",
  "limit": true
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/ai-image").split('\\').join('/')
module.exports = __hm.plugin("ai-image/tobabi", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/tobabi.js'
  const __hmDef = (m) => (m && m.__esModule ? m.default : m);
  const __hmExports = {};
  const axios = __hmDef(require("axios"));
  const FormData = __hmDef(require("form-data"));
  
  async function uploadUguu(buffer, filename = 'image.jpg') {
    const form = new FormData();
    form.append('files[]', buffer, { filename, contentType: 'image/jpeg' });
    const { data } = await axios.post('https://uguu.se/upload', form, { headers: { ...form.getHeaders() } });
    return data?.files?.[0]?.url || null;
  }
  
  const handler = async (m, { sock, qmsg, mime, reply, usedPrefix, command }) => {
    if (!/^image\//.test(mime || '')) {
      return reply(`❌ Reply atau kirim gambar dengan perintah *${usedPrefix + command}*`);
    }
  
    await sock.sendMessage(m.chat, { react: { text: '🕒', key: m.key } }).catch(() => null);
  
    try {
      const buffer = await qmsg.download().catch(() => null);
      if (!buffer) return reply('❌ Gagal mengunduh gambar!');
  
      const uguuUrl = await uploadUguu(buffer, `${command}-${Date.now()}.jpg`);
      if (!uguuUrl) return reply('❌ Gagal mengunggah gambar ke Uguu!');
  
      const apiUrl = `https://api-faa.my.id/faa/tobabi?url=${encodeURIComponent(uguuUrl)}`;
      const response = await axios.get(apiUrl, { responseType: 'arraybuffer', timeout: 60000 });
      const resultBuffer = Buffer.from(response.data);
  
      await sock.sendMessage(m.chat, { image: resultBuffer, caption: '✅ Done' }, { quoted: m });
      await sock.sendMessage(m.chat, { react: { text: '✅', key: m.key } }).catch(() => null);
  
    } catch (e) {
      console.error('[TOBABI ERROR]:', e);
      await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => null);
      reply('❌ Gagal memproses gambar!');
    }
  };
  
  handler.help = ['tobabi (reply gambar)'];
  handler.tags = ['maker'];
  handler.command = ['tobabi'];
  handler.limit = true;
  
  const __hmDefault = handler;
  Object.defineProperty(__hmExports, "default", { enumerable: true, get: () => __hmDefault });
  return __hmExports
})
