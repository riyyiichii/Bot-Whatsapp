// cr: haimiya md saca
// Plugin Haimiya MD (ai/gemini-persona.js) — dijalankan lewat lib/haimiya-bridge.js
module.exports = require('../../lib/haimiya-bridge.js').bridge(require('../../lib/haimiya/plugins/ai/gemini-persona.js'), { category: 'ai', name: 'ai-gemini-persona' })
