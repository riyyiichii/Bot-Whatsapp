// cr: haimiya md saca
// Plugin Haimiya MD (ai/gpt4.js) — dijalankan lewat lib/haimiya-bridge.js
module.exports = require('../../lib/haimiya-bridge.js').bridge(require('../../lib/haimiya/plugins/ai/gpt4.js'), { category: 'ai', name: 'ai-gpt4' })
