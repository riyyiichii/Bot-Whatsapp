// cr: haimiya md saca
// ai/toisland — satu file: metadata + kode fitur (gabungan dari engine3/plugins/ai/toisland.js)
const __hm = require("../../lib/adapter/e3.js")
const __meta = {
  "name": "toisland",
  "command": [
    "toisland",
    "island",
    "tropical"
  ],
  "category": "ai",
  "desc": "Ubah foto menjadi suasana pulau tropis",
  "usage": ".toisland (reply/kirim gambar)",
  "owner": false,
  "group": false,
  "private": false,
  "premium": true,
  "admin": false,
  "botAdmin": false,
  "cooldown": 60,
  "energi": 3,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/ai").split('\\').join('/')
module.exports = __hm.plugin("ai/toisland", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/toisland.js'
  const __hmDef = (m) => (m && m.__esModule ? m.default : m);
  const __hmExports = {};
  const { live3d } = require("../../lib/ext/src/scraper/seaart.e3.js");
  const te = __hmDef(require("../../lib/ext/src/lib/haimiya-error.js"));
  
  const pluginConfig = {
      name: 'toisland',
      alias: ['island', 'tropical'],
      category: 'ai',
      description: 'Ubah foto menjadi suasana pulau tropis',
      usage: '.toisland (reply/kirim gambar)',
      example: '.toisland',
      isOwner: false,
      isPremium: true,
      isGroup: false,
      isPrivate: false,
      cooldown: 60,
      energi: 3,
      isEnabled: true
  }
  
  const PROMPT = `Transform this image into a tropical island scene. 
  Place the subject in a beautiful island environment with clear blue ocean, palm trees, and warm sunlight. 
  Add realistic lighting, shadows, and vibrant tropical colors. 
  Keep the original identity, high detail, cinematic, photorealistic.`
  
  async function handler(m, { sock }) {
      const isImage = m.isImage || (m.quoted && (m.quoted.isImage || m.quoted.type === 'imageMessage'))
      
      if (!isImage) {
          return m.reply(
              `🏝️ *ᴛᴏ ɪsʟᴀɴᴅ*\n\n` +
              `> Kirim/reply gambar untuk suasana pulau\n\n` +
              `\`${m.prefix}toisland\``
          )
      }
      
      m.react('🕕')
      
      try {
          let buffer
          if (m.quoted && m.quoted.isMedia) {
              buffer = await m.quoted.download()
          } else if (m.isMedia) {
              buffer = await m.download()
          }
          
          if (!buffer) {
              m.react('❌')
              return m.reply(`❌ Gagal mendownload gambar`)
          }
          
          const result = await live3d(buffer, PROMPT)
          
          m.react('✅')
          
          await sock.sendMedia(m.chat, result.image, null, m, {
              type: 'image',
          })
          
      } catch (error) { globalThis.__haimiyaCatch?.(error);
          m.react('☢')
          m.reply(te(m.prefix, m.command, m.pushName))
      }
  }
  
  
  Object.defineProperty(__hmExports, "config", { enumerable: true, get: () => pluginConfig });
  Object.defineProperty(__hmExports, "handler", { enumerable: true, get: () => handler });
  return __hmExports
})
