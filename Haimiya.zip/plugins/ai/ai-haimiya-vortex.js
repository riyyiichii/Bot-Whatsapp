// cr: haimiya md saca
// ai/ai-haimiya-vortex — satu file: metadata + kode fitur (gabungan dari engine6/plugins/ai/ai-haimiya-vortex.js)
const __hm = require("../../lib/adapter/e6.js")
const __meta = {
  "name": "Haimiya MD",
  "command": [
    "haimiya-vortex"
  ],
  "category": "ai",
  "desc": "Perintah Haimiya MD",
  "usage": "Haimiya MD <teks>",
  "owner": false,
  "group": false,
  "admin": false,
  "botAdmin": false,
  "premium": false
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/ai").split('\\').join('/')
module.exports = __hm.plugin("ai/ai-haimiya-vortex", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/ai-haimiya-vortex.js'
  const module = { exports: {} }; const exports = module.exports;
  module.exports = async function (__haimiya_imp, __haimiya_meta) {
  
  
  let handler = async (m, { conn, text }) => {
    if (!text) return m.reply("Masukkan teks.\nContoh: .haimiya kamu siapa?")
  
    try {
      const prompt = encodeURIComponent(
        "Kamu adalah Killua Zoldyck dari anime Hunter x Hunter. " +
        "Kamu berbicara dengan gaya santai, sedikit usil, cuek tapi peduli, " +
        "suka cokelat, dan jangan menyebut dirimu sebagai AI."
      )
  
      const query = encodeURIComponent(text)
      const url = `https://api.deline.web.id/ai/openai?text=${query}&prompt=${prompt}`
  
      const res = await fetch(url)
      const data = await res.json()
  
      if (!data.status || !data.result) {
        return m.reply("AI Haimiya MD tidak merespon.")
      }
  
      await conn.sendMessage(m.chat, {
        text: data.result,
        contextInfo: {
          externalAdReply: {
            title: "Killua Zoldyck AI",
            thumbnail: global.thumb,
            mediaType: 1,
            renderLargerThumbnail: true
          }
        }
      }, { quoted: m })
  
    } catch (err) {
      console.error(err)
      m.reply("Terjadi error saat menghubungi AI Haimiya MD.")
    }
  }
  
  handler.help = ['Haimiya MD <teks>']
  handler.tags = ['ai']
  handler.command = /^haimiya$/i
  handler.limit = true
  
  const __haimiya_default = handler;
  
  ;return { default: __haimiya_default };
  }
  
  return module.exports
})
