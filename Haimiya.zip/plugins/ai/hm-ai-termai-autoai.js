// cr: haimiya md saca
// Plugin Haimiya MD (ai/termai-autoai.js) — dijalankan lewat lib/haimiya-bridge.js
module.exports = require('../../lib/haimiya-bridge.js').bridge(require('../../lib/haimiya/plugins/ai/termai-autoai.js'), { category: 'ai', name: 'ai-termai-autoai' })
