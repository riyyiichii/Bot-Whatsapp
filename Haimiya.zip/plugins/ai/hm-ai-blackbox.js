// cr: haimiya md saca
// Plugin Haimiya MD (ai/blackbox.js) — dijalankan lewat lib/haimiya-bridge.js
module.exports = require('../../lib/haimiya-bridge.js').bridge(require('../../lib/haimiya/plugins/ai/blackbox.js'), { category: 'ai', name: 'ai-blackbox' })
