// cr: haimiya md saca
// Plugin Haimiya MD (ai/termai-image.js) — dijalankan lewat lib/haimiya-bridge.js
module.exports = require('../../lib/haimiya-bridge.js').bridge(require('../../lib/haimiya/plugins/ai/termai-image.js'), { category: 'ai', name: 'ai-termai-image' })
