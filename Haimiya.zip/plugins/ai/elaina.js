// cr: haimiya md saca
// ai/elaina — satu file: metadata + kode fitur (gabungan dari engine7/plugins/ai/elaina.js)
const __hm = require("../../lib/adapter/e7.js")
const __meta = {
  "name": "elainaai",
  "command": [
    "elainaai"
  ],
  "category": "ai",
  "desc": "Imported from Haimiya MD V4.6",
  "usage": "",
  "owner": false,
  "group": false,
  "private": false,
  "premium": false,
  "cooldown": 3,
  "energi": 1,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/ai").split('\\').join('/')
module.exports = __hm.plugin("ai/elaina", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/elaina.js'
  const __hmDef = (m) => (m && m.__esModule ? m.default : m);
  const __hmExports = {};
  const FEATURE_CREDIT = "Fitur By: Haimiya MD\nFitur SC Bot Haimiya MD 👑";
  
  
  const fetch = __hmDef(require("node-fetch"));
  
  let sessions = {} // simpan sesi per user
  
  // ====== SCRAPER GEMINI ======
  const gemini = {
    getNewCookie: async () => {
      const r = await fetch(
        "https://gemini.google.com/_/BardChatUi/data/batchexecute?rpcids=maGuAc&source-path=%2F&bl=boq_assistant-bard-web-server_20250814.06_p1&f.sid=-7816331052118000090&hl=en-US&_reqid=173780&rt=c",
        {
          headers: { "content-type": "application/x-www-form-urlencoded;charset=UTF-8" },
          body: "f.req=%5B%5B%5B%22maGuAc%22%2C%22%5B0%5D%22%2Cnull%2C%22generic%22%5D%5D%5D&",
          method: "POST",
        }
      )
      const ck = r.headers.get("set-cookie")
      if (!ck) throw Error("Cookie kosong!")
      return ck.split(";")[0]
    },
  
    ask: async (prompt, prev = null) => {
      if (!prompt?.trim()) throw Error("Mana prompt nya?")
  
      let r = null, c = null
      if (prev) {
        let j = JSON.parse(Buffer.from(prev, "base64").toString())
        r = j.newResumeArray
        c = j.cookie
      }
  
      const headers = {
        "content-type": "application/x-www-form-urlencoded;charset=UTF-8",
        "x-goog-ext-525001261-jspb":
          '[1,null,null,null,"9ec249fc9ad08861",null,null,null,[4]]',
        cookie: c || await gemini.getNewCookie()
      }
  
      const b = [[prompt], ["en-US"], r]
      const a = [null, JSON.stringify(b)]
      const body = new URLSearchParams({ "f.req": JSON.stringify(a) })
  
      const x = await fetch(
        "https://gemini.google.com/_/BardChatUi/data/assistant.lamda.BardFrontendService/StreamGenerate?bl=boq_assistant-bard-web-server_20250729.06_p0&f.sid=4206607810970164620&hl=en-US&_reqid=2813378&rt=c",
        { headers, body, method: "POST" }
      )
  
      if (!x.ok) throw Error(`${x.status} ${x.statusText}`)
  
      const d = await x.text()
      const match = Array.from(d.matchAll(/^\d+\n(.+?)\n/gm)).reverse()[3][1]
      const p1 = JSON.parse(JSON.parse(match)[0][2])
  
      return {
        text: p1[4][0][1][0].replace(/\*\*(.+?)\*\*/g, "*$1*"),
        id: Buffer.from(JSON.stringify({
          newResumeArray: [...p1[1], p1[4][0][0]],
          cookie: headers.cookie
        })).toString("base64"),
      }
    }
  }
  
  
  
  // ====== HANDLER AI Haimiya MD ======
  const pluginConfig = {
    name: "elainaai",
    alias: [],
    category: "ai",
    description: "Imported from Haimiya MD V4.6",
    usage: "",
    example: "",
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 3,
    energi: 1,
    isEnabled: true,
  };
  
  async function handler(m, { sock, text, prefix, command }) {
      const conn = sock;
      const usedPrefix = prefix || m.prefix || ".";
    if (!text) {
      return m.reply(`✨ Contoh:\n${usedPrefix + command} halo Haimiya MD`)
    }
  
    let userId = m.sender
    let prev = sessions[userId] && sessions[userId].expire > Date.now()
      ? sessions[userId].id
      : null
  
    // gaya karakter Haimiya MD
    let system = `
  Kamu adalah *Haimiya MD Tempest*, gadis yandere yang manja, cerdas, dan sedikit posesif.
  Gaya bicara:
  - Ceria, tenang, dan elegan
  - Kadang nakal, suka menggoda, dan gampang cemburu
  - Sopan tapi punya sense of humor halus
  - Terkadang memuji diri sendiri
  - Sangat pintar, manja, dan posesif secara lucu
  
  Tetap jawab sebagai Haimiya MD kepada user. Jangan keluar karakter.
  User adalah seseorang yang membuat Haimiya MD nyaman untuk ngobrol panjang. Kalau user terlalu dekat dengan orang lain, Haimiya MD boleh sedikit cemburu secara lucu.
  `
  
    let finalPrompt = `${system}\nUser: ${text}\nHaimiya:` 
  
    try {
      let result = await gemini.ask(finalPrompt, prev)
  
      // simpan sesi
      sessions[userId] = {
        id: result.id,
        expire: Date.now() + 86400000
      }
  
      await conn.sendMessage(m.chat, {
        text: result.text,
        contextInfo: {
          externalAdReplyOff: {
            title: "Haimiya MD",
            body: "Haimiya MD sedang mendengarkanmu… jadi jangan bikin Haimiya MD cemburu ya 💙",
            thumbnailUrl: "https://files.cloudkuimages.guru/images/zdpX9nJZ.jpg",
            sourceUrl: "https://t.me/Haimiya",
            mediaType: 1,
            renderLargerThumbnail: true
          }
        }
      }, { quoted: m })
  
    } catch (err) {
      await conn.reply(m.chat, `⚠️ Haimiya MD lagi error: ${err.message}`, m)
    }
  }
  
  
  
  Object.defineProperty(__hmExports, "FEATURE_CREDIT", { enumerable: true, get: () => FEATURE_CREDIT });
  Object.defineProperty(__hmExports, "config", { enumerable: true, get: () => pluginConfig });
  Object.defineProperty(__hmExports, "handler", { enumerable: true, get: () => handler });
  return __hmExports
})
