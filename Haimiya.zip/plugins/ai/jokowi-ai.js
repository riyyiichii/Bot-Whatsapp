// cr: haimiya md saca
// ai/jokowi-ai — satu file: metadata + kode fitur (gabungan dari engine3/plugins/ai/jokowi-ai.js)
const __hm = require("../../lib/adapter/e3.js")
const __meta = {
  "name": "jokowi-ai",
  "command": [
    "jokowi-ai",
    "jokowiai",
    "jokowi",
    "pakjokowi"
  ],
  "category": "ai",
  "desc": "Chat dengan Pak Jokowi — Pria Solo",
  "usage": ".jokowi-ai <pertanyaan>",
  "owner": false,
  "group": false,
  "private": false,
  "premium": false,
  "admin": false,
  "botAdmin": false,
  "cooldown": 10,
  "energi": 2,
  "needs": {
    "apikeys": [],
    "scrapers": [
      "unlimitedai"
    ],
    "assets": []
  }
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/ai").split('\\').join('/')
module.exports = __hm.plugin("ai/jokowi-ai", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/jokowi-ai.js'
  const __hmDef = (m) => (m && m.__esModule ? m.default : m);
  const __hmExports = {};
  const { UnlimitedAI } = require("../../lib/ext/src/scraper/unlimitedai.js");
  const te = __hmDef(require("../../lib/ext/src/lib/haimiya-error.js"));
  
  const pluginConfig = {
    name: "jokowi-ai",
    alias: ["jokowiai", "jokowi", "pakjokowi"],
    category: "ai",
    description: "Chat dengan Pak Jokowi — Pria Solo",
    usage: ".jokowi-ai <pertanyaan>",
    example: ".jokowi-ai Pak, gimana kabar?",
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 2,
    isEnabled: true,
  };
  
  async function handler(m, { sock }) {
    const text = m.args.join(" ");
    if (!text) {
      return m.reply(
        `🏛️ *Pak Jokowi*\n\n` +
          `> Pria Solo — Mantan Presiden RI\n> Sederhana, bijak, dan suka blusukan\n\n` +
          `*PENGGUNAAN:*\n` +
          `> *${m.prefix}jokowi-ai <pertanyaan>*\n\n` +
          `*CONTOH:*\n` +
          `> *${m.prefix}jokowi-ai Pak, gimana kabar?*`
      );
    }
  
    await m.react("🕕");
  
    try {
      const result = await UnlimitedAI(text, "jokowi-ai");
  
      if (!result.status) {
        await m.react("☢");
        return m.reply(`❌ *Jokowi AI Error*\n\n> ${result.error || "Gagal mendapatkan respons"}`);
      }
  
      await m.react("✅");
      const reply = result.answer;
      await m.reply(reply.length > 4096 ? reply.slice(0, 4096) + "..." : reply);
    } catch (e) { globalThis.__haimiyaCatch?.(e);
      console.error(e);
      await m.react("☢");
      m.reply(te(m.prefix, m.command, m.pushName));
    }
  }
  
  
  
  Object.defineProperty(__hmExports, "config", { enumerable: true, get: () => pluginConfig });
  Object.defineProperty(__hmExports, "handler", { enumerable: true, get: () => handler });
  return __hmExports
})
