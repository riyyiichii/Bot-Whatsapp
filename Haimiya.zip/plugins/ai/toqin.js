// cr: haimiya md saca
// ai/toqin — fitur tambahan (plugins.zip), disesuaikan untuk Haimiya MD
const __hm = require("../../lib/adapter/e2.js")
const __meta = {
  "command": [
    "toqin"
  ],
  "category": "ai",
  "owner": false,
  "group": false,
  "admin": false,
  "botAdmin": false,
  "desc": "Fitur toqin",
  "usage": ".toqin"
}
const __vdir = __dirname.split('\\').join('/')
module.exports = __hm.plugin("vxnew/ai/toqin", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + "/toqin.js"
  const __hmDef = (m) => (m && m.__esModule ? m.default : m);
  const __hmImp = async (m) => { const r = require(m); return r && r.__esModule ? r : Object.assign({ default: r }, r) };
  const __hmExports = {};
  const uploadImage = __hmDef(require("../../lib/newlib/upload.js"));
  
  const DEFAULT_PROMPT = `Buat saya memakai kostum Qin Shi Huang dari anime Record of Ragnarok, termasuk desain penutup mata dan pakaian yang dikenakan Qin Shi Huang di dalam anime Record of Ragnarok. Buatkan pose khasnya. Characterized by stark cinematic lighting and intense contrast. Highly detailed realistic anime style.`.trim();
  
  let handler = async (m, { conn }) => {
    try {
      let q = m.quoted ? m.quoted : m;
      let mime = (q.msg || q).mimetype || "";
      if (!mime.startsWith("image/")) {
        return m.reply("🍂 *Reply gambar yang ingin diedit.*");
      }
      
      await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
      
      let buffer = await q.download();
      if (!buffer) {
        return m.reply("🍂 *Gagal membaca gambar.*");
      }
      
      let imgUrl = await uploadImage(buffer);
      let res = await fetch(`${global.web}/api/ai/editimage?apikey=${global.apikey?.vxapi}&url=${encodeURIComponent(imgUrl)}&prompt=${encodeURIComponent(DEFAULT_PROMPT)}`);
      let result = await res.json();
      
      let finalImg = result?.result?.image || result?.result?.images?.[0] || result?.result?.url || result?.data?.image || result?.data?.url || (Array.isArray(result?.result) ? result?.result[0] : result?.result) || result?.data;
      if (typeof finalImg === 'object' && finalImg !== null) {
        finalImg = finalImg.url || finalImg.image || JSON.stringify(finalImg);
      }
      
      if (!result?.status || !finalImg || typeof finalImg !== 'string' || !finalImg.startsWith('http')) {
        throw new Error(result?.error || result?.message || 'Server tidak mengembalikan hasil edit gambar.');
      }
      
      await conn.sendMessage(m.chat, {
        image: { url: finalImg },
        caption: '👑 *Qin Shi Huang AI Transformation Success!*'
      }, { quoted: m }).catch(e => m.reply("Gagal mengirim media, ini linknya: " + finalImg));
      
      await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
    } catch (e) {
      console.error(e);
      await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
      m.reply("🍂 *Gagal:* " + (e.message || "Terjadi kesalahan saat memproses gambar."));
    }
  };
  
  handler.help = ["toqin"];
  handler.tags = ["ai"];
  handler.premium = true;
  handler.command = /^(toqin)$/i;
  handler.limit = 1;
  
  
  
  const __hmDefault = handler

  Object.defineProperty(__hmExports, "default", { enumerable: true, get: () => __hmDefault });
  for (const k of ['before', 'all']) { if (typeof __hmExports[k] === 'function' && typeof __hmDefault === 'function' && !__hmDefault[k]) __hmDefault[k] = __hmExports[k] }
  return __hmExports
})
