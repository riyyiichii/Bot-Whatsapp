// cr: haimiya md saca
// Plugin Haimiya MD (ai/termai-audio.js) — dijalankan lewat lib/haimiya-bridge.js
module.exports = require('../../lib/haimiya-bridge.js').bridge(require('../../lib/haimiya/plugins/ai/termai-audio.js'), { category: 'ai', name: 'ai-termai-audio' })
