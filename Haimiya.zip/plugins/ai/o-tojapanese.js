// cr: haimiya md saca
// ai/tojapanese — satu file: metadata + kode fitur (gabungan dari engine3/plugins/ai/tojapanese.js)
const __hm = require("../../lib/adapter/e3.js")
const __meta = {
  "name": "tojapanese",
  "command": [
    "tojapanese",
    "japanese",
    "japanesestyle"
  ],
  "category": "ai",
  "desc": "Ubah gambar ke style Japanese",
  "usage": ".tojapanese (reply gambar)",
  "owner": false,
  "group": false,
  "private": false,
  "premium": false,
  "admin": false,
  "botAdmin": false,
  "cooldown": 30,
  "energi": 2,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/ai").split('\\').join('/')
module.exports = __hm.plugin("ai/tojapanese", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/tojapanese.js'
  const __hmDef = (m) => (m && m.__esModule ? m.default : m);
  const __hmExports = {};
  const axios = __hmDef(require("axios"));
  const { uploadImage } = require("../../lib/ext/src/lib/haimiya-uploader.js");
  const { f } = require("../../lib/ext/src/lib/haimiya-http.js");
  const te = __hmDef(require("../../lib/ext/src/lib/haimiya-error.js"));
  const pluginConfig = {
      name: 'tojapanese',
      alias: ['japanese', 'japanesestyle'],
      category: 'ai',
      description: 'Ubah gambar ke style Japanese',
      usage: '.tojapanese (reply gambar)',
      example: '.tojapanese',
      isOwner: false,
      isPremium: false,
      isGroup: false,
      isPrivate: false,
      cooldown: 30,
      energi: 2,
      isEnabled: true
  }
  
  async function handler(m, { sock }) {
      const isImage = m.isImage || (m.quoted && m.quoted.type === 'imageMessage')
      
      if (!isImage) {
          return m.reply(`🎌 *ᴊᴀᴘᴀɴᴇsᴇ sᴛʏʟᴇ*\n\n> Kirim/reply gambar untuk diubah ke style Japanese\n\n\`${m.prefix}tojapanese\``)
      }
      
      m.react('🕕')
   
      try {
          let buffer
          if (m.quoted && m.quoted.isMedia) {
              buffer = await m.quoted.download()
          } else if (m.isMedia) {
              buffer = await m.download()
          }
          
          if (!buffer) {
              m.react('❌')
              return m.reply(`❌ Gagal mendownload gambar`)
          }
          
          const imageUrl = await uploadImage(buffer, 'image.jpg')
          
          const url = `https://api-faa.my.id/faa/tojapanese?url=${encodeURIComponent(imageUrl)}`
          const res = await f(url, 'arrayBuffer')
          
          m.react('✅')
          
          await sock.sendMedia(m.chat, Buffer.from(res), null, m, {
              type: 'image',
          })
          
      } catch (error) { globalThis.__haimiyaCatch?.(error);
          m.react('☢')
          m.reply(te(m.prefix, m.command, m.pushName))
      }
  }
  
  
  Object.defineProperty(__hmExports, "config", { enumerable: true, get: () => pluginConfig });
  Object.defineProperty(__hmExports, "handler", { enumerable: true, get: () => handler });
  return __hmExports
})
