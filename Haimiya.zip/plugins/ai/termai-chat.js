// cr: haimiya md saca
// fitur tambahan Haimiya MD (ai/termai-chat)
module.exports = require('../../lib/adapter/e9.js').plugin("ai/termai-chat", {"command":["gpt","gpt3","deepseek","deepseek-r1","bard","bardai"],"category":"ai","desc":"Fitur gpt3 <pertanyaan>","usage":".gpt"})
