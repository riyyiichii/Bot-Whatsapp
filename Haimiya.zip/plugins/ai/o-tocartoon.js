// cr: haimiya md saca
// ai/tocartoon — satu file: metadata + kode fitur (gabungan dari engine3/plugins/ai/tocartoon.js)
const __hm = require("../../lib/adapter/e3.js")
const __meta = {
  "name": "tocartoon",
  "command": [
    "tocartoon",
    "cartoon",
    "cartoonify",
    "tooncartoon"
  ],
  "category": "ai",
  "desc": "Ubah foto menjadi gaya kartun",
  "usage": ".tocartoon (reply/kirim gambar)",
  "owner": false,
  "group": false,
  "private": false,
  "premium": true,
  "admin": false,
  "botAdmin": false,
  "cooldown": 60,
  "energi": 3,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/ai").split('\\').join('/')
module.exports = __hm.plugin("ai/tocartoon", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/tocartoon.js'
  const __hmDef = (m) => (m && m.__esModule ? m.default : m);
  const __hmExports = {};
  const te = __hmDef(require("../../lib/ext/src/lib/haimiya-error.js"));
  const { live3d } = require("../../lib/ext/src/scraper/seaart.e3.js");
  const pluginConfig = {
      name: 'tocartoon',
      alias: ['cartoon', 'cartoonify', 'tooncartoon'],
      category: 'ai',
      description: 'Ubah foto menjadi gaya kartun',
      usage: '.tocartoon (reply/kirim gambar)',
      example: '.tocartoon',
      isOwner: false,
      isPremium: true,
      isGroup: false,
      isPrivate: false,
      cooldown: 60,
      energi: 3,
      isEnabled: true
  }
  
  const PROMPT = `Transform this image into a vibrant cartoon style like Disney or Pixar animation. 
  Apply bold colors, smooth shading, exaggerated features, and that playful cartoon aesthetic. 
  Keep the original composition but make it look like a frame from an animated movie with 
  clean lines, expressive faces, and bright cheerful colors.`
  
  async function handler(m, { sock }) {
      const isImage = m.isImage || (m.quoted && (m.quoted.isImage || m.quoted.type === 'imageMessage'))
      
      if (!isImage) {
          return m.reply(
              `🎬 *ᴛᴏ ᴄᴀʀᴛᴏᴏɴ*\n\n` +
              `> Kirim/reply gambar untuk diubah ke gaya kartun\n\n` +
              `\`${m.prefix}tocartoon\``
          )
      }
      
      m.react('🕕')
      
      try {
          let buffer
          if (m.quoted && m.quoted.isMedia) {
              buffer = await m.quoted.download()
          } else if (m.isMedia) {
              buffer = await m.download()
          }
          
          if (!buffer) {
              m.react('❌')
              return m.reply(`❌ Gagal mendownload gambar`)
          }
          
          const result = await live3d(buffer, PROMPT)
          
          m.react('✅')
          
          await sock.sendMedia(m.chat, result.image, null, m, {
              type: 'image'
          })
          
      } catch (error) { globalThis.__haimiyaCatch?.(error);
          m.react('☢')
          m.reply(te(m.prefix, m.command, m.pushName))
      }
  }
  
  
  Object.defineProperty(__hmExports, "config", { enumerable: true, get: () => pluginConfig });
  Object.defineProperty(__hmExports, "handler", { enumerable: true, get: () => handler });
  return __hmExports
})
