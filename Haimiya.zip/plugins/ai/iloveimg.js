// cr: haimiya md saca
// ai/iloveimg — fitur tambahan (plugins.zip), disesuaikan untuk Haimiya MD
const __hm = require("../../lib/adapter/e2.js")
const __meta = {
  "command": [
    "iloveimg",
    "compressimage"
  ],
  "category": "ai",
  "owner": false,
  "group": false,
  "admin": false,
  "botAdmin": false,
  "desc": "Fitur iloveimg",
  "usage": ".iloveimg <url/reply gambar>"
}
const __vdir = __dirname.split('\\').join('/')
module.exports = __hm.plugin("vxnew/ai/iloveimg", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + "/iloveimg.js"
  const __hmDef = (m) => (m && m.__esModule ? m.default : m);
  const __hmImp = async (m) => { const r = require(m); return r && r.__esModule ? r : Object.assign({ default: r }, r) };
  const __hmExports = {};
  let handler = async (m, { conn, usedPrefix, command, text }) => {
    try {
      const q = m.quoted ? m.quoted : m;
      const mime = q?.msg?.mimetype || q?.mimetype || "";
      let imgUrl = text ? text.trim() : "";
      
      if (/image/.test(mime)) {
        await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
        const media = await q.download();
        imgUrl = await (await __hmImp("../../lib/newlib/upload.js")).uploader(media);
      }
      
      if (!imgUrl) return m.reply(`⚠️ Kirim/reply gambar atau berikan URL gambar!\nContoh: ${usedPrefix + command} https://example.com/image.jpg`);
      
      if (!m.quoted || !/image/.test(mime)) {
        await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
      }
      
      const response = await fetch(`${global.web}/api/ai/iloveimg?apikey=${global.apikey?.vxapi}&url=${encodeURIComponent(imgUrl)}`);
      const json = await response.json();
      
      let resultUrl = json.result?.image || json.result?.url || json.data?.image || json.data?.url || json.result || json.data;
      if (typeof resultUrl === 'object' && resultUrl !== null) {
        resultUrl = resultUrl.url || resultUrl.image || JSON.stringify(resultUrl);
      }
      
      if (json.status && typeof resultUrl === 'string' && resultUrl.startsWith('http')) {
        await conn.sendMessage(m.chat, {
          image: { url: resultUrl },
          caption: `✅ *Compress Image Success!*`
        }, { quoted: m }).catch(e => m.reply("Gagal mengirim media, ini linknya: " + resultUrl));
        await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
      } else {
        throw new Error(json.error || json.message || "Gagal memproses gambar");
      }
    } catch (e) {
      console.error(e);
      await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
      m.reply("❌ Error: " + (e.message || e));
    }
  };
  
  handler.help = ["iloveimg <url/reply gambar>"];
  handler.premium = true;
  handler.command = ["iloveimg", "compressimage"];
  handler.tags = ["ai"];
  handler.limit = 1;
  
  
  
  const __hmDefault = handler

  Object.defineProperty(__hmExports, "default", { enumerable: true, get: () => __hmDefault });
  for (const k of ['before', 'all']) { if (typeof __hmExports[k] === 'function' && typeof __hmDefault === 'function' && !__hmDefault[k]) __hmDefault[k] = __hmExports[k] }
  return __hmExports
})
