// cr: haimiya md saca
// Plugin Haimiya MD (ai/add-ai.js) — dijalankan lewat lib/haimiya-bridge.js
module.exports = require('../../lib/haimiya-bridge.js').bridge(require('../../lib/haimiya/plugins/ai/add-ai.js'), { category: 'ai', name: 'ai-add-ai' })
