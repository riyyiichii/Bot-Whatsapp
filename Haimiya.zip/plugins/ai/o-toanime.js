// cr: haimiya md saca
// ai/toanime — satu file: metadata + kode fitur (gabungan dari engine3/plugins/ai/toanime.js)
const __hm = require("../../lib/adapter/e3.js")
const __meta = {
  "name": "toanime",
  "command": [
    "toanime",
    "anime",
    "animefy",
    "ghibli"
  ],
  "category": "ai",
  "desc": "Ubah foto menjadi gaya anime/Ghibli Studio",
  "usage": ".toanime (reply/kirim gambar)",
  "owner": false,
  "group": false,
  "private": false,
  "premium": true,
  "admin": false,
  "botAdmin": false,
  "cooldown": 60,
  "energi": 3,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/ai").split('\\').join('/')
module.exports = __hm.plugin("ai/toanime", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/toanime.js'
  const __hmDef = (m) => (m && m.__esModule ? m.default : m);
  const __hmExports = {};
  const te = __hmDef(require("../../lib/ext/src/lib/haimiya-error.js"));
  const { live3d } = require("../../lib/ext/src/scraper/seaart.e3.js");
  const pluginConfig = {
      name: 'toanime',
      alias: ['anime', 'animefy', 'ghibli'],
      category: 'ai',
      description: 'Ubah foto menjadi gaya anime/Ghibli Studio',
      usage: '.toanime (reply/kirim gambar)',
      example: '.toanime',
      isOwner: false,
      isPremium: true,
      isGroup: false,
      isPrivate: false,
      cooldown: 60,
      energi: 3,
      isEnabled: true
  }
  
  const PROMPT = `Transform this image into Studio Ghibli anime style. 
  Make the characters look like they belong in a Ghibli movie with soft colors, 
  detailed backgrounds, expressive eyes, and that signature warm, magical atmosphere. 
  Keep the original composition but apply the distinct Ghibli artistic style with 
  watercolor-like textures and dreamy lighting.`
  
  async function handler(m, { sock }) {
      const isImage = m.isImage || (m.quoted && (m.quoted.isImage || m.quoted.type === 'imageMessage'))
      
      if (!isImage) {
          return m.reply(
              `🎨 *ᴛᴏ ᴀɴɪᴍᴇ*\n\n` +
              `> Kirim/reply gambar untuk diubah ke gaya anime\n\n` +
              `\`${m.prefix}toanime\``
          )
      }
      
      try {
          let buffer
          if (m.quoted && m.quoted.isMedia) {
              buffer = await m.quoted.download()
          } else if (m.isMedia) {
              buffer = await m.download()
          }
          
          if (!buffer) {
              m.react('❌')
              return m.reply(`❌ Gagal mendownload gambar`)
          }
          
          await m.react('🕕')
          
          const result = await live3d(buffer, PROMPT)
          
          m.react('✅')
          
          await sock.sendMedia(m.chat, result.image, null, m, {
              type: 'image'
          })
          
      } catch (error) { globalThis.__haimiyaCatch?.(error);
          console.log(error)
          m.react('☢')
          m.reply(te(m.prefix, m.command, m.pushName))
      }
  }
  
  
  Object.defineProperty(__hmExports, "config", { enumerable: true, get: () => pluginConfig });
  Object.defineProperty(__hmExports, "handler", { enumerable: true, get: () => handler });
  return __hmExports
})
