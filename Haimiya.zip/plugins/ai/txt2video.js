// cr: haimiya md saca
// ai/txt2video — fitur tambahan (plugins.zip), disesuaikan untuk Haimiya MD
const __hm = require("../../lib/adapter/e2.js")
const __meta = {
  "command": [
    "txt2video",
    "text2video"
  ],
  "category": "ai",
  "owner": false,
  "group": false,
  "admin": false,
  "botAdmin": false,
  "desc": "Fitur txt2video",
  "usage": ".txt2video <teks>"
}
const __vdir = __dirname.split('\\').join('/')
module.exports = __hm.plugin("vxnew/ai/txt2video", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + "/txt2video.js"
  const __hmDef = (m) => (m && m.__esModule ? m.default : m);
  const __hmImp = async (m) => { const r = require(m); return r && r.__esModule ? r : Object.assign({ default: r }, r) };
  const __hmExports = {};
  let handler = async (m, { conn, usedPrefix, command, text }) => {
    try {
      if (!text) return m.reply(`⚠️ Masukkan prompt video!\nContoh: ${usedPrefix + command} sunset over futuristic neo tokyo`);
      await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
      m.reply("🎬 Sedang memproses Text to Video AI... Mohon tunggu (estimasi 1 - 2 menit).");
  
      const response = await fetch(`${global.web}/api/ai/txt2video?apikey=${global.apikey?.vxapi}&prompt=${encodeURIComponent(text)}&model=Anime`);
      const json = await response.json();
      
      let videoUrl = json.result?.video_url || json.result?.video || json.result?.url || json.data?.video_url || json.data?.video || json.data?.url || json.video_url || json.result || json.data;
      if (typeof videoUrl === 'object' && videoUrl !== null) {
        videoUrl = videoUrl.video_url || videoUrl.url || videoUrl.video || JSON.stringify(videoUrl);
      }
  
      if (json.status && typeof videoUrl === 'string' && videoUrl.startsWith('http')) {
        await conn.sendMessage(m.chat, {
          video: { url: videoUrl },
          caption: `🎬 *Text to Video AI Success!*\n\n📝 *Prompt:* ${text}`
        }, { quoted: m }).catch(e => m.reply("Gagal mengirim video, ini linknya: " + videoUrl));
        await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
      } else {
        throw new Error(json.error || json.message || "Gagal menghasilkan video AI dari prompt");
      }
    } catch (e) {
      console.error(e);
      await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
      m.reply("❌ Error: " + (e.message || e));
    }
  };
  
  handler.help = ["txt2video <teks>"];
  handler.tags = ["ai"];
  handler.command = ["txt2video", "text2video"];
  handler.limit = 3;
  
  
  
  const __hmDefault = handler

  Object.defineProperty(__hmExports, "default", { enumerable: true, get: () => __hmDefault });
  for (const k of ['before', 'all']) { if (typeof __hmExports[k] === 'function' && typeof __hmDefault === 'function' && !__hmDefault[k]) __hmDefault[k] = __hmExports[k] }
  return __hmExports
})
