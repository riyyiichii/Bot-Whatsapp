// cr: haimiya md saca
// ai/haimiya-ai — satu file: metadata + kode fitur (gabungan dari engine3/plugins/ai/haimiya-ai.js)
const __hm = require("../../lib/adapter/e3.js")
const __meta = {
  "name": "haimiya-ai",
  "command": [
    "haimiya-ai",
    "haimiyaai",
    "Haimiya MD"
  ],
  "category": "ai",
  "desc": "Chat dengan Haimiya MD — Asisten bot cerdas",
  "usage": ".haimiya-ai <pertanyaan>",
  "owner": false,
  "group": false,
  "private": false,
  "premium": false,
  "admin": false,
  "botAdmin": false,
  "cooldown": 10,
  "energi": 2,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/ai").split('\\').join('/')
module.exports = __hm.plugin("ai/haimiya-ai", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/haimiya-ai.js'
  const __hmDef = (m) => (m && m.__esModule ? m.default : m);
  const __hmExports = {};
  const { UnlimitedAI } = require("../../lib/ext/src/scraper/unlimitedai.js");
  const te = __hmDef(require("../../lib/ext/src/lib/haimiya-error.js"));
  
  const pluginConfig = {
    name: "haimiya-ai",
    alias: ["haimiyaai", "Haimiya MD"],
    category: "ai",
    description: "Chat dengan Haimiya MD — Asisten bot cerdas",
    usage: ".haimiya-ai <pertanyaan>",
    example: ".haimiya-ai Apa itu Node.js?",
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 2,
    isEnabled: true,
  };
  
  async function handler(m, { sock }) {
    const text = m.args.join(" ");
    if (!text) {
      return m.reply(
        `🤖 *Haimiya MD*\n\n` +
          `> Asisten cerdas siap membantu\n\n` +
          `*PENGGUNAAN:*\n` +
          `> *${m.prefix}haimiya-ai <pertanyaan>*\n\n` +
          `*CONTOH:*\n` +
          `> *${m.prefix}haimiya-ai Apa itu Node.js?*`
      );
    }
  
    await m.react("🕕");
  
    try {
      const result = await UnlimitedAI(text, "haimiya-ai");
  
      if (!result.status) {
        await m.react("☢");
        return m.reply(`❌ *Haimiya MD Error*\n\n> ${result.error || "Gagal mendapatkan respons"}`);
      }
  
      await m.react("✅");
      const reply = result.answer;
      await m.reply(reply.length > 4096 ? reply.slice(0, 4096) + "..." : reply);
    } catch (e) { globalThis.__haimiyaCatch?.(e);
      console.error(e);
      await m.react("☢");
      m.reply(te(m.prefix, m.command, m.pushName));
    }
  }
  
  
  
  Object.defineProperty(__hmExports, "config", { enumerable: true, get: () => pluginConfig });
  Object.defineProperty(__hmExports, "handler", { enumerable: true, get: () => handler });
  return __hmExports
})
