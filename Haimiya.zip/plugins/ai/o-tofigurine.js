// cr: haimiya md saca
// ai/tofigurine — satu file: metadata + kode fitur (gabungan dari engine3/plugins/ai/tofigurine.js)
const __hm = require("../../lib/adapter/e3.js")
const __meta = {
  "name": "tofigure3",
  "command": [
    "tofigure3",
    "figurine3",
    "bandai3",
    "actionfigure3"
  ],
  "category": "ai",
  "desc": "Ubah foto menjadi action figure/figurine koleksi",
  "usage": ".tofigure3 (reply/kirim gambar)",
  "owner": false,
  "group": false,
  "private": false,
  "premium": true,
  "admin": false,
  "botAdmin": false,
  "cooldown": 60,
  "energi": 3,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/ai").split('\\').join('/')
module.exports = __hm.plugin("ai/tofigurine", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/tofigurine.js'
  const __hmDef = (m) => (m && m.__esModule ? m.default : m);
  const __hmExports = {};
  const te = __hmDef(require("../../lib/ext/src/lib/haimiya-error.js"));
  const { live3d } = require("../../lib/ext/src/scraper/seaart.e3.js");
  const pluginConfig = {
      name: 'tofigure3',
      alias: ['figurine3', 'tofigure3', 'bandai3', 'actionfigure3'],
      category: 'ai',
      description: 'Ubah foto menjadi action figure/figurine koleksi',
      usage: '.tofigure3 (reply/kirim gambar)',
      example: '.tofigure3',
      isOwner: false,
      isPremium: true,
      isGroup: false,
      isPrivate: false,
      cooldown: 60,
      energi: 3,
      isEnabled: true
  }
  
  const PROMPT = `Using the model, create a 1/7 scale commercialized figurine of the characters in the picture, 
  in a realistic style, in a real environment. The figurine is placed on a computer desk. 
  The figurine has a round transparent acrylic base, with no text on the base. 
  The content on the computer screen is the modeling process of this figurine. 
  Next to the computer screen is a BANDAI-style toy packaging box printed with the original artwork. 
  The packaging features two-dimensional flat illustrations.`
  
  async function handler(m, { sock }) {
      const isImage = m.isImage || (m.quoted && (m.quoted.isImage || m.quoted.type === 'imageMessage'))
      
      if (!isImage) {
          return m.reply(
              `🎭 *ᴛᴏ ꜰɪɢᴜʀ 3*\n\n` +
              `> Kirim/reply gambar untuk diubah ke figurine/action figure\n\n` +
              `\`${m.prefix}tofigure3\``
          )
      }
      
      m.react('🕕')
      
      try {
          let buffer
          if (m.quoted && m.quoted.isMedia) {
              buffer = await m.quoted.download()
          } else if (m.isMedia) {
              buffer = await m.download()
          }
          
          if (!buffer) {
              m.react('❌')
              return m.reply(`❌ Gagal mendownload gambar`)
          }
          
          
          
          const result = await live3d(buffer, PROMPT)
          
          m.react('✅')
          
          await sock.sendMedia(m.chat, result.image, null, m, {
              type: 'image'
          })
          
      } catch (error) { globalThis.__haimiyaCatch?.(error);
          m.react('☢')
          m.reply(te(m.prefix, m.command, m.pushName))
      }
  }
  
  
  Object.defineProperty(__hmExports, "config", { enumerable: true, get: () => pluginConfig });
  Object.defineProperty(__hmExports, "handler", { enumerable: true, get: () => handler });
  return __hmExports
})
