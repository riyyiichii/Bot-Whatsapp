// cr: haimiya md saca
// ai/chatcompletion — fitur tambahan (plugins.zip), disesuaikan untuk Haimiya MD
const __hm = require("../../lib/adapter/e2.js")
const __meta = {
  "command": [
    "chatcompletion"
  ],
  "category": "ai",
  "owner": false,
  "group": false,
  "admin": false,
  "botAdmin": false,
  "desc": "Fitur chatcompletion",
  "usage": ".chatcompletion <teks>"
}
const __vdir = __dirname.split('\\').join('/')
module.exports = __hm.plugin("vxnew/ai/chatcompletion", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + "/chatcompletion.js"
  const __hmDef = (m) => (m && m.__esModule ? m.default : m);
  const __hmImp = async (m) => { const r = require(m); return r && r.__esModule ? r : Object.assign({ default: r }, r) };
  const __hmExports = {};
  let handler = async (m, { conn, usedPrefix, command, text }) => {
    try {
      if (!text) return m.reply(`⚠️ Masukkan pertanyaan/prompt!\nContoh: ${usedPrefix + command} halo`);
      await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
      
      const response = await fetch(`${global.web}/api/ai/chatcompletion?apikey=${global.apikey?.vxapi}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          role: 'user',
          query: text,
          model: 'gpt-4o'
        })
      });
      const json = await response.json();
      
      let resultText = '';
      if (json.status && json.result) {
        resultText = typeof json.result === 'object' ? (json.result.answer || json.result.response || json.result.reply || json.result.message || JSON.stringify(json.result, null, 2)) : json.result;
      } else if (json.status && json.data) {
        resultText = typeof json.data === 'object' ? (json.data.answer || json.data.response || json.data.reply || json.data.message || JSON.stringify(json.data, null, 2)) : json.data;
      } else if (json.status && json.answer) {
        resultText = typeof json.answer === 'object' ? JSON.stringify(json.answer, null, 2) : json.answer;
      } else {
        throw new Error(json.error || json.message || "Gagal mendapatkan respons AI");
      }
      
      await m.reply(String(resultText).trim());
      await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
    } catch (e) {
      console.error(e);
      await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
      m.reply("❌ Error: " + (e.message || e));
    }
  };
  
  handler.help = ["chatcompletion <teks>"];
  handler.tags = ["ai"];
  handler.command = ["chatcompletion", "openai", "gpt4o"];
  handler.limit = true;
  
  
  
  const __hmDefault = handler

  Object.defineProperty(__hmExports, "default", { enumerable: true, get: () => __hmDefault });
  for (const k of ['before', 'all']) { if (typeof __hmExports[k] === 'function' && typeof __hmDefault === 'function' && !__hmDefault[k]) __hmDefault[k] = __hmExports[k] }
  return __hmExports
})
