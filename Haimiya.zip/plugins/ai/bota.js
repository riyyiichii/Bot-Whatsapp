// cr: haimiya md saca
// fitur tambahan Haimiya MD (ai/bota)
module.exports = require('../../lib/adapter/e9.js').plugin("ai/bota", {"command":["bota"],"category":"ai","desc":"Fitur bota <pesan>","usage":".bota"})
