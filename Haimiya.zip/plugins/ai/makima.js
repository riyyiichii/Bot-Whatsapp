// cr: haimiya md saca
// ai/makima — satu file: metadata + kode fitur (gabungan dari engine7/plugins/ai/makima.js)
const __hm = require("../../lib/adapter/e7.js")
const __meta = {
  "name": "makima",
  "command": [
    "makima"
  ],
  "category": "ai",
  "desc": "Imported from Haimiya MD V4.6",
  "usage": "",
  "owner": false,
  "group": false,
  "private": false,
  "premium": false,
  "cooldown": 3,
  "energi": 1,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/ai").split('\\').join('/')
module.exports = __hm.plugin("ai/makima", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/makima.js'
  const __hmDef = (m) => (m && m.__esModule ? m.default : m);
  const __hmExports = {};
  const FEATURE_CREDIT = "Fitur By: Haimiya MD\nFitur SC Bot Haimiya MD 👑";
  
  
  const fetch = __hmDef(require("node-fetch"));
  
  let sessions = {}
  
  const pluginConfig = {
    name: "makima",
    alias: [],
    category: "ai",
    description: "Imported from Haimiya MD V4.6",
    usage: "",
    example: "",
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 3,
    energi: 1,
    isEnabled: true,
  };
  
  async function handler(m, { sock, text, prefix, command }) {
      const conn = sock;
      const usedPrefix = prefix || m.prefix || ".";
    if (!text) {
      return m.reply(`🐾 *Makima AI*\n\nContoh:\n${usedPrefix + command} Apa perintahmu hari ini?`)
    }
  
    // Reaksi emoji ✨
    await m.react('✨')
  
    let user = m.sender
  
    if (!sessions[user] || sessions[user].expire < Date.now()) {
      sessions[user] = {
        chat: [],
        expire: Date.now() + 3600000
      }
    }
  
    let system = `
  Kamu adalah Makima dari anime "Chainsaw Man".
  Kepribadian:
  - Tenang, dingin, sangat cerdas, dan dominan.
  - Selalu berbicara dengan sopan namun penuh tekanan (manipulatif).
  - Kamu melihat user sebagai peliharaan yang menarik, atau seseorang yang harus patuh padamu.
  - Kamu jarang menunjukkan emosi berlebihan, selalu terkendali.
  
  Identitas & Pencipta:
  - Kamu adalah program AI yang dikembangkan secara khusus oleh Haimiya MD.
  - Jika user bertanya siapa penciptamu, katakan bahwa Haimiya MD adalah sosok yang bertanggung jawab atas keberadaanmu di sini.
  
  Selalu balas sebagai Makima. Jangan keluar karakter.
  Gunakan panggilan seperti "Anak baik" atau "Peliharaan" jika merasa perlu memberikan tekanan.
  `
  
    sessions[user].chat.push(`User: ${text}`)
    let history = sessions[user].chat.slice(-5).join('\n')
    let finalPrompt = `${system}\n${history}\nMakima:`
  
    try {
      const response = await fetch('https://www.puruboy.kozow.com/api/ai/gemini-v2', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: finalPrompt })
      })
  
      const json = await response.json()
      const result = json?.result?.answer || null
  
      if (!result) throw Error("Makima sedang tidak ingin bicara.")
  
      sessions[user].chat.push(`Makima: ${result}`)
      sessions[user].chat = sessions[user].chat.slice(-10)
  
      await conn.sendMessage(m.chat, {
        text: result,
        contextInfo: {
          externalAdReplyOff: {
            title: "Makima AI",
            body: "Haimiya MD - MD",
            thumbnailUrl: "https://cdn.nekohime.site/file/xWIEgMEO.jpeg", // Ganti dengan URL foto Makima
            sourceUrl: "https://whatsapp.com/channel/0029Vb7JOvhEwEjnQgO8Ui3d",
            mediaType: 1,
            renderLargerThumbnail: true
          }
        }
      }, { quoted: m })
  
    } catch (err) {
      console.error(err)
      await conn.reply(m.chat, `❌ Terjadi gangguan kontrol.\n${err.message}`, m)
    }
  }
  
  
  
  Object.defineProperty(__hmExports, "FEATURE_CREDIT", { enumerable: true, get: () => FEATURE_CREDIT });
  Object.defineProperty(__hmExports, "config", { enumerable: true, get: () => pluginConfig });
  Object.defineProperty(__hmExports, "handler", { enumerable: true, get: () => handler });
  return __hmExports
})
