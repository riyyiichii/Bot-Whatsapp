// cr: haimiya md saca
// fitur tambahan Haimiya MD (ai/blackbox)
module.exports = require('../../lib/adapter/e9.js').plugin("ai/blackbox", {"command":["blackbox","blackboxai"],"category":"ai","desc":"Fitur blackbox <pertanyaan>","usage":".blackbox"})
