// cr: haimiya md saca
// ai/pixa-removebg — fitur tambahan (plugins.zip), disesuaikan untuk Haimiya MD
const __hm = require("../../lib/adapter/e2.js")
const __meta = {
  "command": [
    "pixa-removebg",
    "pixaremovebg"
  ],
  "category": "ai",
  "owner": false,
  "group": false,
  "admin": false,
  "botAdmin": false,
  "desc": "Fitur pixa-removebg",
  "usage": ".pixa-removebg <url/reply image>"
}
const __vdir = __dirname.split('\\').join('/')
module.exports = __hm.plugin("vxnew/ai/pixa-removebg", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + "/pixa-removebg.js"
  const __hmDef = (m) => (m && m.__esModule ? m.default : m);
  const __hmImp = async (m) => { const r = require(m); return r && r.__esModule ? r : Object.assign({ default: r }, r) };
  const __hmExports = {};
  const uploadImage = __hmDef(require("../../lib/newlib/upload.js"));
  
  let handler = async (m, { conn, usedPrefix, command, text }) => {
    try {
      const q = m.quoted ? m.quoted : m;
      const mime = q?.msg?.mimetype || q?.mimetype || "";
      let imgUrl = text ? text.trim() : "";
  
      if (/image/.test(mime)) {
        await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
        const media = await q.download();
        imgUrl = await uploadImage(media);
      }
  
      if (!imgUrl) {
        return m.reply(`⚠️ Kirim/reply gambar atau berikan URL gambar!\nContoh: ${usedPrefix + command} https://example.com/image.jpg`);
      }
  
      if (!m.quoted || !/image/.test(mime)) {
        await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
      }
  
      const response = await fetch(`${global.web}/api/ai/pixa-removebg?apikey=${global.apikey?.vxapi}&url=${encodeURIComponent(imgUrl)}`);
      
      if (!response.ok) {
        let errText = "Gagal memproses gambar";
        try {
          const errJson = await response.json();
          errText = errJson.error || errJson.message || errText;
        } catch (e) {}
        throw new Error(errText);
      }
  
      const resultBuffer = Buffer.from(await response.arrayBuffer());
  
      await conn.sendMessage(m.chat, {
        image: resultBuffer,
        caption: `✅ *Pixa RemoveBG Success!*`
      }, { quoted: m });
      
      await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
    } catch (e) {
      console.error(e);
      await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
      m.reply("❌ Error: " + (e.message || "Terjadi kesalahan internal"));
    }
  };
  
  handler.help = ["pixa-removebg <url/reply image>", "pixaremovebg <url/reply image>"];
  handler.premium = true;
  handler.command = ["pixa-removebg", "pixaremovebg"];
  handler.tags = ["ai"];
  handler.limit = 1;
  
  
  
  const __hmDefault = handler

  Object.defineProperty(__hmExports, "default", { enumerable: true, get: () => __hmDefault });
  for (const k of ['before', 'all']) { if (typeof __hmExports[k] === 'function' && typeof __hmDefault === 'function' && !__hmDefault[k]) __hmDefault[k] = __hmExports[k] }
  return __hmExports
})
