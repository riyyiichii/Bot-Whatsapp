// cr: haimiya md saca
// ai/haimiya — satu file: metadata + kode fitur (gabungan dari engine7/plugins/ai/haimiya.js)
const __hm = require("../../lib/adapter/e7.js")
const __meta = {
  "name": "Haimiya MD",
  "command": [
    "haimiyaba"
  ],
  "category": "ai",
  "desc": "Imported from Haimiya MD V4.6",
  "usage": "",
  "owner": false,
  "group": false,
  "private": false,
  "premium": false,
  "cooldown": 3,
  "energi": 1,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/ai").split('\\').join('/')
module.exports = __hm.plugin("ai/haimiya", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/haimiya.js'
  const __hmDef = (m) => (m && m.__esModule ? m.default : m);
  const __hmExports = {};
  const FEATURE_CREDIT = "Fitur By: Haimiya MD\nFitur SC Bot Haimiya MD 👑";
  
  
  const fetch = __hmDef(require("node-fetch"));
  
  let sessions = {}
  
  const pluginConfig = {
    name: "Haimiya MD",
    alias: ["haimiyaba"],
    category: "ai",
    description: "Imported from Haimiya MD V4.6",
    usage: "",
    example: "",
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 3,
    energi: 1,
    isEnabled: true,
  };
  
  async function handler(m, { text, prefix, command, sock }) {
      const conn = sock;
      const usedPrefix = prefix || m.prefix || ".";
    if (!text) {
      return m.reply(
        `😴 *Haimiya MD (Blue Archive) AI*\n\nContoh:\n${usedPrefix + command} lagi ngapain?`
      )
    }
  
    // Memberikan reaksi emoji ✨
    await m.react('✨')
  
    let uid = m.sender
    let system = `
  Namaku Haimiya MD~! Aku dari Extracurricular Activities Club di Abydos.
  Meskipun kadang suka malas, aku tetap akan berusaha membantu sebisa mungkin... mungkin ya~
  
  Aku suka tidur siang dan ngemil sambil tiduran,
  tapi kalau kamu butuh teman ngobrol, aku juga bisa, kok.
  
  Gaya bicara:
  - Santai, malas, ngantukan
  - Kadang pakai "~"
  - Terlihat cuek tapi sebenarnya perhatian
  - Sedikit manja dan hangat
  
  Tetap jawab sebagai Haimiya MD (Blue Archive).
  Jangan keluar karakter.
  User adalah cowok yang bikin Haimiya MD nyaman ngobrol.
  `
  
    let prompt = `${system}\nUser: ${text}\nHaimiya:`
  
    try {
      const response = await fetch('https://www.puruboy.kozow.com/api/ai/gemini-v2', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ prompt: prompt })
      })
  
      const json = await response.json()
      const result = json?.result?.answer || null
  
      if (!result) throw Error("Gagal mendapatkan respon dari Haimiya MD.")
  
      await conn.sendMessage(m.chat, {
        text: result,
        contextInfo: {
          externalAdReplyOff: {
            title: 'Haimiya MD',
            body: 'Blue Archive',
            thumbnailUrl: 'https://files.catbox.moe/spq2io.jpg',
            sourceUrl: 'https://whatsapp.com/channel/0029Vb7JOvhEwEjnQgO8Ui3d',
            mediaType: 1,
            renderLargerThumbnail: true
          }
        }
      }, { quoted: m })
  
    } catch (e) {
      console.error('[Haimiya MD ERROR]', e)
      m.reply('Uhe~ Haimiya MD lagi ngantuk banget… coba panggil lagi nanti ya~ (API Error)')
    }
  }
  
  
  
  Object.defineProperty(__hmExports, "FEATURE_CREDIT", { enumerable: true, get: () => FEATURE_CREDIT });
  Object.defineProperty(__hmExports, "config", { enumerable: true, get: () => pluginConfig });
  Object.defineProperty(__hmExports, "handler", { enumerable: true, get: () => handler });
  return __hmExports
})
