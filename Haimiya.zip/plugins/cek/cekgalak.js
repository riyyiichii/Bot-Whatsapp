// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/cekgalak)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekgalak", {"command":["cekgalak"],"category":"cek","desc":"Fitur cekgalak [@user]","usage":".cekgalak"})
