// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/cekkarismatik)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekkarismatik", {"command":["cekkarismatik"],"category":"cek","desc":"Fitur cekkarismatik [@user]","usage":".cekkarismatik"})
