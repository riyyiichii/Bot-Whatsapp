// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/cekganteng)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekganteng", {"command":["cekganteng"],"category":"cek","desc":"Fitur cekganteng [@tag/nama]","usage":".cekganteng"})
