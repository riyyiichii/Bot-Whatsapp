// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/cekbego)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekbego", {"command":["cekbego"],"category":"cek","desc":"Fitur cekbego [@tag/nama]","usage":".cekbego"})
