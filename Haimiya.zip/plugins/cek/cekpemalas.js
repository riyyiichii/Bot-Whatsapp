// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/cekpemalas)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekpemalas", {"command":["cekpemalas"],"category":"cek","desc":"Fitur cekpemalas [@user]","usage":".cekpemalas"})
