// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/cekkpopers)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekkpopers", {"command":["cekkpopers","kpopers","kpop"],"category":"cek","desc":"Cek tingkat kpopers kamu","usage":".cekkpopers"})
