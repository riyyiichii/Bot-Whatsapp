// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/cekgay)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekgay", {"command":["cekgay"],"category":"cek","desc":"Fitur cekgay [@tag/nama]","usage":".cekgay"})
