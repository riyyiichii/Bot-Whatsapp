// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/cekmemek)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekmemek", {"command":["cekmemek"],"category":"cek","desc":"Fitur cekmemek [@tag/nama]","usage":".cekmemek"})
