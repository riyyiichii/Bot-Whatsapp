// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/cekcupu)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekcupu", {"command":["cekcupu"],"category":"cek","desc":"Fitur cekcupu [@user]","usage":".cekcupu"})
