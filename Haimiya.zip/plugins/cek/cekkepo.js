// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/cekkepo)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekkepo", {"command":["cekkepo"],"category":"cek","desc":"Fitur cekkepo [@user]","usage":".cekkepo"})
