// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/cekgila)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekgila", {"command":["cekgila"],"category":"cek","desc":"Fitur cekgila [@user]","usage":".cekgila"})
