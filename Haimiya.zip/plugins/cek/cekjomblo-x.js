// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/cekjomblo)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekjomblo", {"command":["cekjomblo"],"category":"cek","desc":"Fitur cekjomblo [@user]","usage":".cekjomblo"})
