// cr: haimiya md saca
// cek/cekjomblo — satu file: metadata + kode fitur (gabungan dari engine3/plugins/cek/cekjomblo.js)
const __hm = require("../../lib/adapter/e3.js")
const __meta = {
  "name": "cekjomblo",
  "command": [
    "jomblo",
    "single"
  ],
  "category": "cek",
  "desc": "Cek tingkat kejombloan kamu",
  "usage": ".cekjomblo <nama>",
  "owner": false,
  "group": false,
  "private": false,
  "premium": false,
  "admin": false,
  "botAdmin": false,
  "cooldown": 5,
  "energi": 0,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/cek").split('\\').join('/')
module.exports = __hm.plugin("cek/cekjomblo", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/cekjomblo.js'
  const __hmExports = {};
  const pluginConfig = {
      name: 'cekjomblo',
      alias: ['jomblo', 'single'],
      category: 'cek',
      description: 'Cek tingkat kejombloan kamu',
      usage: '.cekjomblo <nama>',
      example: '.cekjomblo Budi',
      isOwner: false,
      isPremium: false,
      isGroup: false,
      isPrivate: false,
      cooldown: 5,
      energi: 0,
      isEnabled: true
  }
  
  async function handler(m) {
          const percent = Math.floor(Math.random() * 101)
      const mentioned = m.mentionedJid[0] || m.sender
                      
      let desc = ''
      if (percent >= 90) desc = 'Jomblo abadi! Single is happiness~ 💔😎'
      else if (percent >= 70) desc = 'Strong independent person! 💪'
      else if (percent >= 50) desc = 'MasihPDKT mode ON 😍'
      else if (percent >= 30) desc = 'Ada yang naksir kayaknya~ 👀'
      else desc = 'Soon taken! 💕'
      
      let txt = mentioned === m.sender ? `Hai @${mentioned.split('@')[0]}
      
  Tingkat kejombloan kamu *${percent}%*
  \`\`\`${desc}\`\`\`` : `Kamu ingin ngecek tingkat kejombloan @${mentioned.split('@')[0]} yak? 
      
  Tingkat kejombloan dia sebesar *${percent}%*
  \`\`\`${desc}\`\`\``
      
      await m.reply(txt, { mentions: [mentioned] })
  }
  
  
  Object.defineProperty(__hmExports, "config", { enumerable: true, get: () => pluginConfig });
  Object.defineProperty(__hmExports, "handler", { enumerable: true, get: () => handler });
  return __hmExports
})
