// cr: haimiya md saca
// cek/cekpelit — satu file: metadata + kode fitur (gabungan dari engine3/plugins/cek/cekpelit.js)
const __hm = require("../../lib/adapter/e3.js")
const __meta = {
  "name": "cekpelit",
  "command": [
    "pelit",
    "kikir"
  ],
  "category": "cek",
  "desc": "Cek seberapa pelit kamu",
  "usage": ".cekpelit <nama>",
  "owner": false,
  "group": false,
  "private": false,
  "premium": false,
  "admin": false,
  "botAdmin": false,
  "cooldown": 5,
  "energi": 0,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/cek").split('\\').join('/')
module.exports = __hm.plugin("cek/cekpelit", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/cekpelit.js'
  const __hmExports = {};
  const pluginConfig = {
      name: 'cekpelit',
      alias: ['pelit', 'kikir'],
      category: 'cek',
      description: 'Cek seberapa pelit kamu',
      usage: '.cekpelit <nama>',
      example: '.cekpelit Budi',
      isOwner: false,
      isPremium: false,
      isGroup: false,
      isPrivate: false,
      cooldown: 5,
      energi: 0,
      isEnabled: true
  }
  
  async function handler(m) {
          const percent = Math.floor(Math.random() * 101)
      const mentioned = m.mentionedJid[0] || m.sender
                      
      let desc = ''
      if (percent >= 90) {
          desc = 'SUPER PELIT! Duit dijaga mati-matian! 💸'
      } else if (percent >= 70) {
          desc = 'Pelit banget! 🙊'
      } else if (percent >= 50) {
          desc = 'Lumayan pelit 😅'
      } else if (percent >= 30) {
          desc: 'Sedikit hemat 😊'
      } else {
          desc = 'Dermawan banget! 🎁'
      }
      
      let txt = mentioned === m.sender ? `Hai @${mentioned.split('@')[0]}
      
  Tingkat kepelitan kamu *${percent}%*
  \`\`\`${desc}\`\`\`` : `Kamu ingin ngecek tingkat kepelitan @${mentioned.split('@')[0]} yak? 
      
  Tingkat kepelitan dia sebesar *${percent}%*
  \`\`\`${desc}\`\`\``
      
      await m.reply(txt, { mentions: [mentioned] })
  }
  
  
  Object.defineProperty(__hmExports, "config", { enumerable: true, get: () => pluginConfig });
  Object.defineProperty(__hmExports, "handler", { enumerable: true, get: () => handler });
  return __hmExports
})
