// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/ceklemot)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/ceklemot", {"command":["ceklemot"],"category":"cek","desc":"Fitur ceklemot [@user]","usage":".ceklemot"})
