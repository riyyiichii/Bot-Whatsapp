// cr: haimiya md saca
// cek/cekjahat — satu file: metadata + kode fitur (gabungan dari engine3/plugins/cek/cekjahat.js)
const __hm = require("../../lib/adapter/e3.js")
const __meta = {
  "name": "cekjahat",
  "command": [
    "cekjahat",
    "jahat",
    "evil"
  ],
  "category": "cek",
  "desc": "Cek seberapa jahat kamu",
  "usage": ".cekjahat <nama>",
  "owner": false,
  "group": false,
  "private": false,
  "premium": false,
  "admin": false,
  "botAdmin": false,
  "cooldown": 5,
  "energi": 0,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/cek").split('\\').join('/')
module.exports = __hm.plugin("cek/cekjahat", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/cekjahat.js'
  const __hmExports = {};
  const pluginConfig = {
      name: 'cekjahat',
      alias: ['jahat', 'evil'],
      category: 'cek',
      description: 'Cek seberapa jahat kamu',
      usage: '.cekjahat <nama>',
      example: '.cekjahat Budi',
      isOwner: false,
      isPremium: false,
      isGroup: false,
      isPrivate: false,
      cooldown: 5,
      energi: 0,
      isEnabled: true
  }
  
  async function handler(m) {
          const percent = Math.floor(Math.random() * 101)
      const mentioned = m.mentionedJid[0] || m.sender
                      
      let desc = ''
      if (percent >= 90) {
          desc = 'VILLAIN LEVEL! 😈👿'
      } else if (percent >= 70) {
          desc = 'Jahat banget! 💀'
      } else if (percent >= 50) {
          desc = 'Lumayan jahat 😏'
      } else if (percent >= 30) {
          desc = 'Sedikit nakal 😊'
      } else {
          desc = 'Baik kok, gak jahat! 😇'
      }
      
      let txt = mentioned === m.sender ? `Hai @${mentioned.split('@')[0]}
      
  Tingkat kejahatan kamu *${percent}%*
  \`\`\`${desc}\`\`\`` : `Kamu ingin ngecek tingkat kejahatan @${mentioned.split('@')[0]} yak? 
      
  Tingkat kejahatan dia sebesar *${percent}%*
  \`\`\`${desc}\`\`\``
      
      await m.reply(txt, { mentions: [mentioned] })
  }
  
  
  Object.defineProperty(__hmExports, "config", { enumerable: true, get: () => pluginConfig });
  Object.defineProperty(__hmExports, "handler", { enumerable: true, get: () => handler });
  return __hmExports
})
