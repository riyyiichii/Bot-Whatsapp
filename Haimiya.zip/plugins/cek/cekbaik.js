// cr: haimiya md saca
// cek/cekbaik — satu file: metadata + kode fitur (gabungan dari engine3/plugins/cek/cekbaik.js)
const __hm = require("../../lib/adapter/e3.js")
const __meta = {
  "name": "cekbaik",
  "command": [
    "cekbaik",
    "baik",
    "kind"
  ],
  "category": "cek",
  "desc": "Cek seberapa baik kamu",
  "usage": ".cekbaik <nama>",
  "owner": false,
  "group": false,
  "private": false,
  "premium": false,
  "admin": false,
  "botAdmin": false,
  "cooldown": 5,
  "energi": 0,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/cek").split('\\').join('/')
module.exports = __hm.plugin("cek/cekbaik", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/cekbaik.js'
  const __hmExports = {};
  const pluginConfig = {
      name: 'cekbaik',
      alias: ['baik', 'kind'],
      category: 'cek',
      description: 'Cek seberapa baik kamu',
      usage: '.cekbaik <nama>',
      example: '.cekbaik Budi',
      isOwner: false,
      isPremium: false,
      isGroup: false,
      isPrivate: false,
      cooldown: 5,
      energi: 0,
      isEnabled: true
  }
  
  async function handler(m) {
      const percent = Math.floor(Math.random() * 101)
      const mentioned = m.mentionedJid[0] || m.sender
      
      let desc = ''
      if (percent >= 90) {
          desc = 'Mantappp! kamu adalah orang paling Baik di dunia ini! 😇✨'
      } else if (percent >= 70) {
          desc = 'Baik hati dan tidak sombong! 💝'
      } else if (percent >= 50) {
          desc = 'Lumayan baik 😊'
      } else if (percent >= 30) {
          desc = 'Sedikit baik 🙂'
      } else {
          desc = 'Hmm, perlu introspeksi ?? 🤔'
      }
      
      let txt = mentioned === m.sender ? `Hai @${mentioned.split('@')[0]}
      
  Tingkat kebaikan kamu *${percent}%*
  \`\`\`${desc}\`\`\`` : `Kamu ingin ngecek tingkat kebaikan @${mentioned.split('@')[0]} yak? 
      
  Tingkat kebaikan dia sebesar *${percent}%*
  \`\`\`${desc}\`\`\``
      
      await m.reply(txt, { mentions: [mentioned] })
  }
  
  
  Object.defineProperty(__hmExports, "config", { enumerable: true, get: () => pluginConfig });
  Object.defineProperty(__hmExports, "handler", { enumerable: true, get: () => handler });
  return __hmExports
})
