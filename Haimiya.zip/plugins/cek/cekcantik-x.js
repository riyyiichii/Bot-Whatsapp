// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/cekcantik)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekcantik", {"command":["cekcantik"],"category":"cek","desc":"Fitur cekcantik [@tag/nama]","usage":".cekcantik"})
