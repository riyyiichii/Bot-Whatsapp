// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/cekbaik)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekbaik", {"command":["cekbaik"],"category":"cek","desc":"Fitur cekbaik [@user]","usage":".cekbaik"})
