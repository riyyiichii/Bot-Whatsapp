// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/cekgabut)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekgabut", {"command":["cekgabut"],"category":"cek","desc":"Fitur cekgabut [@user]","usage":".cekgabut"})
