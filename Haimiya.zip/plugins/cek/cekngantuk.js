// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/cekngantuk)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekngantuk", {"command":["cekngantuk","ngantuk","sleepy"],"category":"cek","desc":"Cek tingkat ngantuk kamu","usage":".cekngantuk"})
