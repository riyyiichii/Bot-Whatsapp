// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/cekngeselin)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekngeselin", {"command":["cekngeselin"],"category":"cek","desc":"Fitur cekngeselin [@user]","usage":".cekngeselin"})
