// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/cekkontol)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekkontol", {"command":["cekkontol"],"category":"cek","desc":"Fitur cekkontol [@tag/nama]","usage":".cekkontol"})
