// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/ceknoob)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/ceknoob", {"command":["ceknoob"],"category":"cek","desc":"Fitur ceknoob [@user]","usage":".ceknoob"})
