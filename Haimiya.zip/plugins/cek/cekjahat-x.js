// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/cekjahat)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekjahat", {"command":["cekjahat"],"category":"cek","desc":"Fitur cekjahat [@user]","usage":".cekjahat"})
