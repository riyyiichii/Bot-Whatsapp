// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/cekbersyukur)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekbersyukur", {"command":["cekbersyukur"],"category":"cek","desc":"Fitur cekbersyukur [@user]","usage":".cekbersyukur"})
