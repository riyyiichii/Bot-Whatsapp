// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/cekcerewet)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekcerewet", {"command":["cekcerewet"],"category":"cek","desc":"Fitur cekcerewet [@user]","usage":".cekcerewet"})
