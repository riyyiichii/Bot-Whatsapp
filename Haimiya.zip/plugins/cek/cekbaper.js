// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/cekbaper)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekbaper", {"command":["cekbaper"],"category":"cek","desc":"Fitur cekbaper [@user]","usage":".cekbaper"})
