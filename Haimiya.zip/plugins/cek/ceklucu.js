// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/ceklucu)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/ceklucu", {"command":["ceklucu"],"category":"cek","desc":"Fitur ceklucu [@user]","usage":".ceklucu"})
