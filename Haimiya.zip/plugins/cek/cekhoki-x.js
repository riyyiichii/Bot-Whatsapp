// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/cekhoki)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekhoki", {"command":["cekhoki"],"category":"cek","desc":"Fitur cekhoki [@tag/nama]","usage":".cekhoki"})
