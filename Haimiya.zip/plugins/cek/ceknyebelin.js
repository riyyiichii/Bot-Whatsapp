// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/ceknyebelin)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/ceknyebelin", {"command":["ceknyebelin"],"category":"cek","desc":"Fitur ceknyebelin [@user]","usage":".ceknyebelin"})
