// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/cekcreative)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekcreative", {"command":["cekcreative","creative","kreatif"],"category":"cek","desc":"Cek tingkat kreativitas kamu","usage":".cekcreative"})
