// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/cekbucin)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekbucin", {"command":["cekbucin"],"category":"cek","desc":"Fitur cekbucin [@tag/nama]","usage":".cekbucin"})
