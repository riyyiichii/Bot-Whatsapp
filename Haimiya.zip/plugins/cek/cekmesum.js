// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/cekmesum)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekmesum", {"command":["cekmesum","mesum"],"category":"cek","desc":"Cek seberapa mesum kamu","usage":".cekmesum"})
