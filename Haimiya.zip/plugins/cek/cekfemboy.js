// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/cekfemboy)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekfemboy", {"command":["cekfemboy","femboy"],"category":"cek","desc":"Fitur cekfemboy [nama/@user]","usage":".cekfemboy"})
