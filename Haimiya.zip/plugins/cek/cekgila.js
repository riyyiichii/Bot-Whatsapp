// cr: haimiya md saca
// cek/cekgila — satu file: metadata + kode fitur (gabungan dari engine3/plugins/cek/cekgila.js)
const __hm = require("../../lib/adapter/e3.js")
const __meta = {
  "name": "cekgila",
  "command": [
    "cekgila",
    "gila",
    "crazy"
  ],
  "category": "cek",
  "desc": "Cek seberapa gila kamu",
  "usage": ".cekgila <nama>",
  "owner": false,
  "group": false,
  "private": false,
  "premium": false,
  "admin": false,
  "botAdmin": false,
  "cooldown": 5,
  "energi": 0,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/cek").split('\\').join('/')
module.exports = __hm.plugin("cek/cekgila", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/cekgila.js'
  const __hmExports = {};
  const pluginConfig = {
      name: 'cekgila',
      alias: ['gila', 'crazy'],
      category: 'cek',
      description: 'Cek seberapa gila kamu',
      usage: '.cekgila <nama>',
      example: '.cekgila Budi',
      isOwner: false,
      isPremium: false,
      isGroup: false,
      isPrivate: false,
      cooldown: 5,
      energi: 0,
      isEnabled: true
  }
  
  async function handler(m) {
          const percent = Math.floor(Math.random() * 101)
      const mentioned = m.mentionedJid[0] || m.sender
                      
      let desc = ''
      if (percent >= 90) {
          desc = 'GILA BENERAN! Masuk RSJ! 🤪'
      } else if (percent >= 70) {
          desc = 'Hampir gila 😵'
      } else if (percent >= 50) {
          desc = 'Lumayan waras 😅'
      } else if (percent >= 30) {
          desc: 'Normal kok 🙂'
      } else {
          desc = 'Waras banget! 😇'
      }
      
      let txt = mentioned === m.sender ? `Hai @${mentioned.split('@')[0]}
      
  Tingkat kegilaan kamu *${percent}%*
  \`\`\`${desc}\`\`\`` : `Kamu ingin ngecek tingkat kegilaan @${mentioned.split('@')[0]} yak? 
      
  Tingkat kegilaan dia sebesar *${percent}%*
  \`\`\`${desc}\`\`\``
      
      await m.reply(txt, { mentions: [mentioned] })
  }
  
  
  Object.defineProperty(__hmExports, "config", { enumerable: true, get: () => pluginConfig });
  Object.defineProperty(__hmExports, "handler", { enumerable: true, get: () => handler });
  return __hmExports
})
