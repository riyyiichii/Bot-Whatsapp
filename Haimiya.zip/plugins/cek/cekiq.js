// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/cekiq)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekiq", {"command":["cekiq"],"category":"cek","desc":"Fitur cekiq [@tag/nomor]","usage":".cekiq"})
