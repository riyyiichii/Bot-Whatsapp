// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/ceklebay)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/ceklebay", {"command":["ceklebay"],"category":"cek","desc":"Fitur ceklebay [@user]","usage":".ceklebay"})
