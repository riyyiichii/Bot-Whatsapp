// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/cekjenius)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekjenius", {"command":["cekjenius"],"category":"cek","desc":"Fitur cekjenius [@user]","usage":".cekjenius"})
