// cr: haimiya md saca
// cek/cekganteng — satu file: metadata + kode fitur (gabungan dari engine3/plugins/cek/cekganteng.js)
const __hm = require("../../lib/adapter/e3.js")
const __meta = {
  "name": "cekganteng",
  "command": [
    "ganteng",
    "handsome"
  ],
  "category": "cek",
  "desc": "Cek seberapa ganteng kamu",
  "usage": ".cekganteng <nama>",
  "owner": false,
  "group": false,
  "private": false,
  "premium": false,
  "admin": false,
  "botAdmin": false,
  "cooldown": 5,
  "energi": 0,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/cek").split('\\').join('/')
module.exports = __hm.plugin("cek/cekganteng", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/cekganteng.js'
  const __hmExports = {};
  const pluginConfig = {
      name: 'cekganteng',
      alias: ['ganteng', 'handsome'],
      category: 'cek',
      description: 'Cek seberapa ganteng kamu',
      usage: '.cekganteng <nama>',
      example: '.cekganteng Budi',
      isOwner: false,
      isPremium: false,
      isGroup: false,
      isPrivate: false,
      cooldown: 5,
      energi: 0,
      isEnabled: true
  }
  
  async function handler(m) {
          const percent = Math.floor(Math.random() * 101)
      const mentioned = m.mentionedJid[0] || m.sender
                      
      let desc = ''
      if (percent >= 90) {
          desc = 'Ganteng maksimal! 😍🔥'
      } else if (percent >= 70) {
          desc = 'Ganteng banget! 😎'
      } else if (percent >= 50) {
          desc = 'Lumayan ganteng~ 👍'
      } else if (percent >= 30) {
          desc = 'Biasa aja sih 😅'
      } else {
          desc = 'Mungkin inner beauty? 🤭'
      }
      
      let txt = mentioned === m.sender ? `Hai @${mentioned.split('@')[0]}
      
  Tingkat kegantengan kamu *${percent}%*
  \`\`\`${desc}\`\`\`` : `Kamu ingin ngecek tingkat kegantengan @${mentioned.split('@')[0]} yak? 
      
  Tingkat kegantengan dia sebesar *${percent}%*
  \`\`\`${desc}\`\`\``
      
      await m.reply(txt, { mentions: [mentioned] })
  }
  
  
  Object.defineProperty(__hmExports, "config", { enumerable: true, get: () => pluginConfig });
  Object.defineProperty(__hmExports, "handler", { enumerable: true, get: () => handler });
  return __hmExports
})
