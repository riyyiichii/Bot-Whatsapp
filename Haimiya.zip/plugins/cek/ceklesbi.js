// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/ceklesbi)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/ceklesbi", {"command":["ceklesbi"],"category":"cek","desc":"Fitur ceklesbi [@tag/nama]","usage":".ceklesbi"})
