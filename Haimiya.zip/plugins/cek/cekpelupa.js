// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/cekpelupa)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekpelupa", {"command":["cekpelupa"],"category":"cek","desc":"Fitur cekpelupa [@user]","usage":".cekpelupa"})
