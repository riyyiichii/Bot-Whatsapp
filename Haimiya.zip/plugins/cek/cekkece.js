// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/cekkece)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekkece", {"command":["cekkece","kece","cool"],"category":"cek","desc":"Cek seberapa kece kamu","usage":".cekkece"})
