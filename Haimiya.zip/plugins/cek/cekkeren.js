// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/cekkeren)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekkeren", {"command":["cekkeren"],"category":"cek","desc":"Fitur cekkeren [@user]","usage":".cekkeren"})
