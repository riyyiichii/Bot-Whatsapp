// cr: haimiya md saca
// cek/cekcantik — satu file: metadata + kode fitur (gabungan dari engine3/plugins/cek/cekcantik.js)
const __hm = require("../../lib/adapter/e3.js")
const __meta = {
  "name": "cekcantik",
  "command": [
    "cantik",
    "beautiful"
  ],
  "category": "cek",
  "desc": "Cek seberapa cantik kamu",
  "usage": ".cekcantik <nama>",
  "owner": false,
  "group": false,
  "private": false,
  "premium": false,
  "admin": false,
  "botAdmin": false,
  "cooldown": 5,
  "energi": 0,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/cek").split('\\').join('/')
module.exports = __hm.plugin("cek/cekcantik", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/cekcantik.js'
  const __hmExports = {};
  const pluginConfig = {
      name: 'cekcantik',
      alias: ['cantik', 'beautiful'],
      category: 'cek',
      description: 'Cek seberapa cantik kamu',
      usage: '.cekcantik <nama>',
      example: '.cekcantik Ani',
      isOwner: false,
      isPremium: false,
      isGroup: false,
      isPrivate: false,
      cooldown: 5,
      energi: 0,
      isEnabled: true
  }
  
  async function handler(m) {
          const percent = Math.floor(Math.random() * 101)
      const mentioned = m.mentionedJid[0] || m.sender
                      
      let desc = ''
      if (percent >= 90) {
          desc = 'Cantik banget kayak bidadari! 👸✨'
      } else if (percent >= 70) {
          desc = 'Cantik banget! 💕'
      } else if (percent >= 50) {
          desc = 'Manis dan cantik~ 🌸'
      } else if (percent >= 30) {
          desc = 'Lumayan cantik 😊'
      } else {
          desc = 'Tetep cantik kok! 💖'
      }
      
      let txt = mentioned === m.sender ? `Hai @${mentioned.split('@')[0]}
      
  Tingkat kecantikan kamu *${percent}%*
  \`\`\`${desc}\`\`\`` : `Kamu ingin ngecek tingkat kecantikan @${mentioned.split('@')[0]} yak? 
      
  Tingkat kecantikan dia sebesar *${percent}%*
  \`\`\`${desc}\`\`\``
      
      await m.reply(txt, { mentions: [mentioned] })
  }
  
  
  Object.defineProperty(__hmExports, "config", { enumerable: true, get: () => pluginConfig });
  Object.defineProperty(__hmExports, "handler", { enumerable: true, get: () => handler });
  return __hmExports
})
