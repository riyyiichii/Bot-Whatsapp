// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/ceklapar)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/ceklapar", {"command":["ceklapar","lapar","hungry"],"category":"cek","desc":"Cek tingkat kelaparan kamu","usage":".ceklapar"})
