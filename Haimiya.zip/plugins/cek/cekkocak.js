// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/cekkocak)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekkocak", {"command":["cekkocak"],"category":"cek","desc":"Fitur cekkocak [@user]","usage":".cekkocak"})
