// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/cekbodoh)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekbodoh", {"command":["cekbodoh"],"category":"cek","desc":"Fitur cekbodoh [@user]","usage":".cekbodoh"})
