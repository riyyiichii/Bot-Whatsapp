// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/cekimut)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekimut", {"command":["cekimut"],"category":"cek","desc":"Fitur cekimut [@user]","usage":".cekimut"})
