// cr: haimiya md saca
// fitur tambahan Haimiya MD (cek/cekmunafik)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekmunafik", {"command":["cekmunafik"],"category":"cek","desc":"Fitur cekmunafik [@user]","usage":".cekmunafik"})
