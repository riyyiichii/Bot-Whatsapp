// cr: haimiya md saca
// asupan/asupan — satu file: metadata + kode fitur (gabungan dari engine3/plugins/asupan/asupan.js)
const __hm = require("../../lib/adapter/e3.js")
const __meta = {
  "name": "asupan",
  "command": [
    "asupan",
    "asupanrandom"
  ],
  "category": "asupan",
  "desc": "Random video asupan",
  "usage": ".asupan",
  "owner": false,
  "group": false,
  "private": false,
  "premium": false,
  "admin": false,
  "botAdmin": false,
  "cooldown": 10,
  "energi": 1,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/asupan").split('\\').join('/')
module.exports = __hm.plugin("asupan/asupan", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/asupan.js'
  const __hmDef = (m) => (m && m.__esModule ? m.default : m);
  const __hmExports = {};
  const axios = __hmDef(require("axios"));
  const fs = __hmDef(require("fs"));
  const path = __hmDef(require("path"));
  const { f } = require("../../lib/ext/src/lib/haimiya-http.js");
  const pluginConfig = {
      name: 'asupan',
      alias: ['asupanrandom'],
      category: 'asupan',
      description: 'Random video asupan',
      usage: '.asupan',
      example: '.asupan',
      isOwner: false,
      isPremium: false,
      isGroup: false,
      isPrivate: false,
      cooldown: 10,
      energi: 1,
      isEnabled: true
  }
  
  function loadJsonData() {
      const tiktokDir = path.join(process.cwd(), 'src', 'tiktok')
      const files = ['bocil.json', 'gheayubi.json', 'kayes.json', 'notnot.json', 'panrika.json', 'santuy.json', 'tiktokgirl.json', 'ukhty.json']
      let allUrls = []
      
      for (const file of files) {
          try {
              const filePath = path.join(tiktokDir, file)
              if (fs.existsSync(filePath)) {
                  const data = JSON.parse(fs.readFileSync(filePath, 'utf-8'))
                  allUrls = allUrls.concat(data.map(d => d.url))
              }
          } catch {}
      }
      
      return allUrls
  }
  
  async function handler(m, { sock }) {
      m.react('🕕')
      
      try {
          const urls = loadJsonData()
          
          if (urls.length === 0) {
              m.react('❌')
              return m.reply(`❌ Data asupan tidak tersedia`)
          }
          
          const url = urls[Math.floor(Math.random() * urls.length)]
          
          const res = await f(url, 'arrayBuffer')
          
          m.react('✅')
          
          await sock.sendMedia(m.chat, Buffer.from(res), null, m, {
              type: 'video'
          })
          
      } catch (error) {
          m.react('❌')
          m.reply(`❌ *ᴇʀʀᴏʀ*\n\n> Video asupan tidak ditemukan`)
      }
  }
  
  
  Object.defineProperty(__hmExports, "config", { enumerable: true, get: () => pluginConfig });
  Object.defineProperty(__hmExports, "handler", { enumerable: true, get: () => handler });
  return __hmExports
})
