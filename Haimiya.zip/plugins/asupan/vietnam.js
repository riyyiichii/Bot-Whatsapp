// cr: haimiya md saca
// cecan/vietnam — satu file: metadata + kode fitur (gabungan dari engine5/plugins/cecan/vietnam.js)
const __hm = require("../../lib/adapter/e5.js")
const __meta = {
  "name": "vietnam",
  "command": [
    "vietnam"
  ],
  "category": "asupan",
  "desc": "Fitur vietnam",
  "usage": ".vietnam",
  "limit": true
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/cecan").split('\\').join('/')
module.exports = __hm.plugin("cecan/vietnam", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/vietnam.js'
  const __hmDef = (m) => (m && m.__esModule ? m.default : m);
  const __hmExports = {};
  const sendCecan = __hmDef(require("../../lib/ext/lib/scrape/cecan.js"));
  
  const handler = async (m, { sock, reply }) => {
  	try {
  		await sendCecan(sock, m, reply, 'Vietnam');
  	} catch (e) {
  		console.error('[CECAN VIETNAM ERROR]', e);
  		await sock.sendMessage(m.chat, { react: { text: '⚠️', key: m.key } });
  		reply('❌ Gagal mengambil gambar cecan Vietnam.');
  	}
  };
  
  handler.help = ['vietnam'];
  handler.tags = ['cewerandom'];
  handler.command = ['vietnam'];
  handler.limit = true;
  
  const __hmDefault = handler;
  Object.defineProperty(__hmExports, "default", { enumerable: true, get: () => __hmDefault });
  return __hmExports
})
