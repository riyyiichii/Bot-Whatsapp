// cr: haimiya md saca
// cecan/rose — satu file: metadata + kode fitur (gabungan dari engine5/plugins/cecan/rose.js)
const __hm = require("../../lib/adapter/e5.js")
const __meta = {
  "name": "rose",
  "command": [
    "rose"
  ],
  "category": "asupan",
  "desc": "Fitur rose",
  "usage": ".rose",
  "limit": true
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/cecan").split('\\').join('/')
module.exports = __hm.plugin("cecan/rose", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/rose.js'
  const __hmDef = (m) => (m && m.__esModule ? m.default : m);
  const __hmExports = {};
  const sendCecan = __hmDef(require("../../lib/ext/lib/scrape/cecan.js"));
  
  const handler = async (m, { sock, reply }) => {
  	try {
  		await sendCecan(sock, m, reply, 'Rose');
  	} catch (e) {
  		console.error('[CECAN ROSE ERROR]', e);
  		await sock.sendMessage(m.chat, { react: { text: '⚠️', key: m.key } });
  		reply('❌ Gagal mengambil gambar cecan Rose.');
  	}
  };
  
  handler.help = ['rose'];
  handler.tags = ['cewerandom'];
  handler.command = ['rose'];
  handler.limit = true;
  
  const __hmDefault = handler;
  Object.defineProperty(__hmExports, "default", { enumerable: true, get: () => __hmDefault });
  return __hmExports
})
