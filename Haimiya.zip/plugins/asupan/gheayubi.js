// cr: haimiya md saca
// asupan/gheayubi — satu file: metadata + kode fitur (gabungan dari engine5/plugins/asupan/gheayubi.js)
const __hm = require("../../lib/adapter/e5.js")
const __meta = {
  "name": "gheayubi",
  "command": [
    "gheayubi",
    "ghea"
  ],
  "category": "asupan",
  "desc": "Fitur gheayubi",
  "usage": ".gheayubi",
  "limit": true
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/asupan").split('\\').join('/')
module.exports = __hm.plugin("asupan/gheayubi", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/gheayubi.js'
  const __hmExports = {};
  const handler = async (m, { sock, reply }) => {
  	await sock.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
  
  	try {
  		const baseUrl = global.APIs?.kyzz;
  		const apiKey = global.APIKeys?.[baseUrl] || global.APIKeys?.kyzz;
  		const fallbackUrl = `${baseUrl}/api/asupan/gheayubi?apikey=${apiKey}`;
  
  		const data = await global.fetchApi('kyzz', '/api/asupan/gheayubi').catch(() => null);
  
  		let mediaUrl = fallbackUrl;
  		if (data) {
  			if (typeof data === 'string' && data.startsWith('http')) {
  				mediaUrl = data;
  			} else if (data.url) {
  				mediaUrl = data.url;
  			} else if (data.result) {
  				mediaUrl = typeof data.result === 'string' ? data.result : (data.result.url || data.result.link);
  			}
  		}
  
  		try {
  			await sock.sendMessage(m.chat, {
  				video: { url: mediaUrl },
  				caption: `🎥 *Asupan Ghea Yubi*\n\n© ${global.namaBot}`,
  				mimetype: 'video/mp4'
  			}, { quoted: m });
  		} catch {
  			await sock.sendMessage(m.chat, {
  				image: { url: mediaUrl },
  				caption: `📸 *Asupan Ghea Yubi*\n\n© ${global.namaBot}`
  			}, { quoted: m });
  		}
  
  		await sock.sendMessage(m.chat, { react: { text: '✨', key: m.key } });
  
  	} catch (e) {
  		console.error('[ASUPAN GHEAYUBI ERROR]', e);
  		await sock.sendMessage(m.chat, { react: { text: '⚠️', key: m.key } });
  		return reply('❌ Gagal mengambil asupan Ghea Yubi.');
  	}
  };
  
  handler.help = ['gheayubi'];
  handler.tags = ['asupan'];
  handler.command = ['gheayubi', 'ghea'];
  handler.limit = true;
  
  const __hmDefault = handler;
  Object.defineProperty(__hmExports, "default", { enumerable: true, get: () => __hmDefault });
  return __hmExports
})
