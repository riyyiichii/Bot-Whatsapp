// cr: haimiya md saca
// cecan/china — satu file: metadata + kode fitur (gabungan dari engine5/plugins/cecan/china.js)
const __hm = require("../../lib/adapter/e5.js")
const __meta = {
  "name": "china",
  "command": [
    "china",
    "cecan-china"
  ],
  "category": "asupan",
  "desc": "Fitur china",
  "usage": ".china",
  "limit": true
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/cecan").split('\\').join('/')
module.exports = __hm.plugin("cecan/china", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/china.js'
  const __hmDef = (m) => (m && m.__esModule ? m.default : m);
  const __hmExports = {};
  const sendCecan = __hmDef(require("../../lib/ext/lib/scrape/cecan.js"));
  
  const handler = async (m, { sock, reply }) => {
  	await sock.sendMessage(m.chat, { react: { text: '⏳', key: m.key } }).catch(() => null);
  
  	try {
  		await sendCecan(sock, m, reply, 'China');
  		await sock.sendMessage(m.chat, { react: { text: '✨', key: m.key } }).catch(() => null);
  	} catch (e) {
  		console.error('[CECAN CHINA ERROR]:', e);
  		await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => null);
  		return reply('❌ Gagal mengambil gambar cecan China.');
  	}
  };
  
  handler.help = ['china'];
  handler.tags = ['cecan'];
  handler.command = ['china', 'cecan-china', 'cecanchina'];
  handler.limit = true;
  
  const __hmDefault = handler;
  Object.defineProperty(__hmExports, "default", { enumerable: true, get: () => __hmDefault });
  return __hmExports
})
