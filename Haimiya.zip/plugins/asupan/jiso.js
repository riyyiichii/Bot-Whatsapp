// cr: haimiya md saca
// cecan/jiso — satu file: metadata + kode fitur (gabungan dari engine5/plugins/cecan/jiso.js)
const __hm = require("../../lib/adapter/e5.js")
const __meta = {
  "name": "jiso",
  "command": [
    "jiso",
    "jisoo"
  ],
  "category": "asupan",
  "desc": "Perintah jiso",
  "usage": "",
  "limit": true
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/cecan").split('\\').join('/')
module.exports = __hm.plugin("cecan/jiso", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/jiso.js'
  const __hmDef = (m) => (m && m.__esModule ? m.default : m);
  const __hmExports = {};
  const sendCecan = __hmDef(require("../../lib/ext/lib/scrape/cecan.js"));
  
  const handler = async (m, { sock, reply }) => {
  	try {
  		await sendCecan(sock, m, reply, 'Jiso');
  	} catch (e) {
  		console.error('[CECAN JISO ERROR]', e);
  		await sock.sendMessage(m.chat, { react: { text: '⚠️', key: m.key } });
  		reply('❌ Gagal mengambil gambar cecan Jiso.');
  	}
  };
  
  handler.command = ['jiso', 'jisoo'];
  handler.limit = true;
  
  const __hmDefault = handler;
  Object.defineProperty(__hmExports, "default", { enumerable: true, get: () => __hmDefault });
  return __hmExports
})
