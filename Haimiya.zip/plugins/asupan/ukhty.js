// cr: haimiya md saca
// asupan/ukhty — satu file: metadata + kode fitur (gabungan dari engine3/plugins/asupan/ukhty.js)
const __hm = require("../../lib/adapter/e3.js")
const __meta = {
  "name": "ukhty",
  "command": [
    "ukhty",
    "ukht"
  ],
  "category": "asupan",
  "desc": "Video ukhty",
  "usage": ".ukhty",
  "owner": false,
  "group": false,
  "private": false,
  "premium": false,
  "admin": false,
  "botAdmin": false,
  "cooldown": 10,
  "energi": 1,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/asupan").split('\\').join('/')
module.exports = __hm.plugin("asupan/ukhty", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/ukhty.js'
  const __hmDef = (m) => (m && m.__esModule ? m.default : m);
  const __hmExports = {};
  const axios = __hmDef(require("axios"));
  const fs = __hmDef(require("fs"));
  const path = __hmDef(require("path"));
  const pluginConfig = {
      name: 'ukhty',
      alias: ['ukht'],
      category: 'asupan',
      description: 'Video ukhty',
      usage: '.ukhty',
      example: '.ukhty',
      isOwner: false,
      isPremium: false,
      isGroup: false,
      isPrivate: false,
      cooldown: 10,
      energi: 1,
      isEnabled: true
  }
  
  function loadJsonData(filename) {
      try {
          const filePath = path.join(process.cwd(), 'src', 'tiktok', filename)
          if (fs.existsSync(filePath)) {
              return JSON.parse(fs.readFileSync(filePath, 'utf-8'))
          }
      } catch {}
      return []
  }
  
  async function handler(m, { sock }) {
      m.react('🕕')
      
      try {
          const data = loadJsonData('ukhty.json')
          
          if (data.length === 0) {
              m.react('❌')
              return m.reply(`❌ Data tidak tersedia`)
          }
          
          const item = data[Math.floor(Math.random() * data.length)]
          
          await sock.sendMedia(m.chat, item.url, null, m, {
              type: 'video'
          })
          m.react('✅')
          
      } catch (error) {
          m.react('❌')
          m.reply(`❌ *ᴇʀʀᴏʀ*\n\n> Video tidak ditemukan`)
      }
  }
  
  
  Object.defineProperty(__hmExports, "config", { enumerable: true, get: () => pluginConfig });
  Object.defineProperty(__hmExports, "handler", { enumerable: true, get: () => handler });
  return __hmExports
})
