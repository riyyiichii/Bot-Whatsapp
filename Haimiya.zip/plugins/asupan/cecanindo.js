// cr: haimiya md saca
// random/cecanindo — satu file: metadata + kode fitur (gabungan dari engine3/plugins/random/cecanindo.js)
const __hm = require("../../lib/adapter/e3.js")
const __meta = {
  "name": "cecanindo",
  "command": [
    "cecanindo",
    "cewekindo",
    "cewekindonesia"
  ],
  "category": "asupan",
  "desc": "Random gambar cewek cantik Indonesia",
  "usage": ".cecanindo",
  "owner": false,
  "group": false,
  "private": false,
  "premium": false,
  "admin": false,
  "botAdmin": false,
  "cooldown": 5,
  "energi": 1,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/random").split('\\').join('/')
module.exports = __hm.plugin("random/cecanindo", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/cecanindo.js'
  const __hmDef = (m) => (m && m.__esModule ? m.default : m);
  const __hmExports = {};
  const axios = __hmDef(require("axios"));
  const config = __hmDef(require("../../lib/ext/config.e3.js"));
  const te = __hmDef(require("../../lib/ext/src/lib/haimiya-error.js"));
  const pluginConfig = {
      name: 'cecanindo',
      alias: ['cewekindo', 'cewekindonesia'],
      category: 'cecan',
      description: 'Random gambar cewek cantik Indonesia',
      usage: '.cecanindo',
      example: '.cecanindo',
      isOwner: false,
      isPremium: false,
      isGroup: false,
      isPrivate: false,
      cooldown: 5,
      energi: 1,
      isEnabled: true
  }
  
  async function handler(m, { sock }) {
      const api = 'https://api.nexray.web.id/random/cecan/indonesia'
      await m.react('🇮🇩')
      try {
          await sock.sendMedia(m.chat, api, null, m, {
              type: 'image'
          })
          await m.react('✅')
      } catch (e) {
          await m.react('☢')
          m.reply(te(m.prefix, m.command, m.pushName))
      }
  }
  
  
  Object.defineProperty(__hmExports, "config", { enumerable: true, get: () => pluginConfig });
  Object.defineProperty(__hmExports, "handler", { enumerable: true, get: () => handler });
  return __hmExports
})
