// cr: haimiya md saca
// fitur tambahan Haimiya MD (anime/anichin)
module.exports = require('../../lib/adapter/e9.js').plugin("anime/anichin", {"command":["anichin"],"category":"anime","desc":"Fitur anichin","usage":".anichin"})
