// cr: haimiya md saca
// fitur tambahan Haimiya MD (anime/animeseason)
module.exports = require('../../lib/adapter/e9.js').plugin("anime/animeseason", {"command":["animeseason"],"category":"anime","desc":"Info lengkap anime musim ini (Spring/Summer/Fall/Winter) + statistik","usage":".animeseason","group":true})
