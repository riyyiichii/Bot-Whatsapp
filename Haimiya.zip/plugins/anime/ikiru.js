// cr: haimiya md saca
// fitur tambahan Haimiya MD (anime/ikiru)
module.exports = require('../../lib/adapter/e9.js').plugin("anime/ikiru", {"command":["ikiru"],"category":"anime","desc":"Fitur ikiru","usage":".ikiru"})
