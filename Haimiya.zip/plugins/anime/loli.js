// cr: haimiya md saca
// fitur tambahan Haimiya MD (anime/loli)
module.exports = require('../../lib/adapter/e9.js').plugin("anime/loli", {"command":["loli"],"category":"anime","desc":"Fitur loli","usage":".loli"})
