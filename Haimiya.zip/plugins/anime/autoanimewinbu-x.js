// cr: haimiya md saca
// fitur tambahan Haimiya MD (anime/autoanimewinbu)
module.exports = require('../../lib/adapter/e9.js').plugin("anime/autoanimewinbu", {"command":["autoanimewinbu"],"category":"anime","desc":"Auto upload ongoing anime & donghua dari winbu.net (720p Pixeldrain)","usage":".autoanimewinbu","owner":true})
