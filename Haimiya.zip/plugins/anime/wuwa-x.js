// cr: haimiya md saca
// fitur tambahan Haimiya MD (anime/wuwa)
module.exports = require('../../lib/adapter/e9.js').plugin("anime/wuwa", {"command":["wuwa"],"category":"anime","desc":"Menampilkan sheet material karakter Wuthering Waves","usage":".wuwa"})
