// cr: haimiya md saca
// fitur tambahan Haimiya MD (anime/animedl)
module.exports = require('../../lib/adapter/e9.js').plugin("anime/animedl", {"command":["animedl"],"category":"anime","desc":"Download anime batch/single episode dari Kusonime","usage":".animedl"})
