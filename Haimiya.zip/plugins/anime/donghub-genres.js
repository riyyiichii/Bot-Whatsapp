// cr: haimiya md saca
// anime/donghub-genres — fitur tambahan (plugins.zip), disesuaikan untuk Haimiya MD
const __hm = require("../../lib/adapter/e2.js")
const __meta = {
  "command": [
    "donghub-genres",
    "donghubgenres",
    "donghuagenres",
    "listgenredonghua"
  ],
  "category": "anime",
  "owner": false,
  "group": false,
  "admin": false,
  "botAdmin": false,
  "desc": "Fitur donghub-genres",
  "usage": ".donghub-genres"
}
const __vdir = __dirname.split('\\').join('/')
module.exports = __hm.plugin("vxnew/donghua/donghub-genres", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + "/donghub-genres.js"
  const __hmDef = (m) => (m && m.__esModule ? m.default : m);
  const __hmImp = async (m) => { const r = require(m); return r && r.__esModule ? r : Object.assign({ default: r }, r) };
  const __hmExports = {};
  const fetch = __hmDef(require("../../lib/newlib/fetch.js"));
  
  let handler = async (m, { conn, usedPrefix, command }) => {
      await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
      try {
          let apiKey = global.apikey?.vxapi || global.apiKey;
          let url = `${global.web}/api/donghua/donghub-genres?apikey=${apiKey}`;
          
          let res = await fetch(url);
          let json = await res.json();
          
          if (json.status && json.result) {
              let list = json.result;
              const botName = (global.botname || 'BOT').toUpperCase();
              let txt = `🐉 *${botName} - DAFTAR GENRE DONGHUA*\n\n`;
              txt += `Berikut seluruh genre donghua yang tersedia:\n\n`;
  
              list.forEach((g, idx) => {
                  txt += `• *${g.name || g.slug}* (Slug: \`${g.slug}\`)\n`;
              });
  
              txt += `\n💡 *Tips:* Ketik *${usedPrefix}donghub-genre <slug>* untuk melihat donghua pada genre tersebut.`;
  
              await m.reply(txt.trim());
              await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
          } else {
              await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } }).catch(() => {});
              m.reply(json.error || 'Gagal memuat daftar genre donghua.');
          }
      } catch (e) {
          console.error('[Donghub Genres Error]', e);
          await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } }).catch(() => {});
          m.reply('Terjadi kesalahan: ' + (e.message || 'Server error.'));
      }
  }
  
  handler.help = ['donghub-genres']
  handler.tags = ['donghua']
  handler.command = /^(donghub-genres|donghubgenres|donghuagenres|listgenredonghua)$/i
  handler.premium = false
  handler.limit = 1;
  
  
  
  const __hmDefault = handler

  Object.defineProperty(__hmExports, "default", { enumerable: true, get: () => __hmDefault });
  for (const k of ['before', 'all']) { if (typeof __hmExports[k] === 'function' && typeof __hmDefault === 'function' && !__hmDefault[k]) __hmDefault[k] = __hmExports[k] }
  return __hmExports
})
