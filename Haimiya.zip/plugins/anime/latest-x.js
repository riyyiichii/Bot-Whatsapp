// cr: haimiya md saca
// fitur tambahan Haimiya MD (anime/latest)
module.exports = require('../../lib/adapter/e9.js').plugin("anime/latest", {"command":["animelatest"],"category":"anime","desc":"Fitur animelatest","usage":".animelatest"})
