// cr: haimiya md saca
// fitur tambahan Haimiya MD (anime/konachan)
module.exports = require('../../lib/adapter/e9.js').plugin("anime/konachan", {"command":["konachan"],"category":"anime","desc":"Cari gambar anime dari konachan","usage":".konachan"})
