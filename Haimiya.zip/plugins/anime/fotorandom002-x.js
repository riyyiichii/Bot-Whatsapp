// cr: haimiya md saca
// fitur tambahan Haimiya MD (anime/fotorandom002)
module.exports = require('../../lib/adapter/e9.js').plugin("anime/fotorandom002", {"command":["fotorandom002"],"category":"anime","desc":"Haimiya random image 💗","usage":".fotorandom002"})
