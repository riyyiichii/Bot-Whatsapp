// cr: haimiya md saca
// fitur tambahan Haimiya MD (anime/yande)
module.exports = require('../../lib/adapter/e9.js').plugin("anime/yande", {"command":["yande"],"category":"anime","desc":"Fitur yande","usage":".yande"})
