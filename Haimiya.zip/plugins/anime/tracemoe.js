// cr: haimiya md saca
// fitur tambahan Haimiya MD (anime/tracemoe)
module.exports = require('../../lib/adapter/e9.js').plugin("anime/tracemoe", {"command":["tracemoe"],"category":"anime","desc":"Fitur tracemoe (reply/kirim gambar)","usage":".tracemoe"})
