// cr: haimiya md saca
// fitur tambahan Haimiya MD (anime/alqanime)
module.exports = require('../../lib/adapter/e9.js').plugin("anime/alqanime", {"command":["alqanime"],"category":"anime","desc":"Fitur alqanime <on|off|status|test>","usage":".alqanime","group":true,"admin":true})
