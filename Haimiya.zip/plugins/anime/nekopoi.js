// cr: haimiya md saca
// fitur tambahan Haimiya MD (anime/nekopoi)
module.exports = require('../../lib/adapter/e9.js').plugin("anime/nekopoi", {"command":["nekopoi"],"category":"anime","desc":"Fitur <kata kunci | latest | url | dl url>","usage":".nekopoi"})
