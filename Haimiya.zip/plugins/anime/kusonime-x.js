// cr: haimiya md saca
// fitur tambahan Haimiya MD (anime/kusonime)
module.exports = require('../../lib/adapter/e9.js').plugin("anime/kusonime", {"command":["kusonime"],"category":"anime","desc":"Cari anime dari kusonime.com (batch download)","usage":".kusonime"})
