// cr: haimiya md saca
// fitur tambahan Haimiya MD (pushkontak/setjeda)
module.exports = require('../../lib/adapter/e9.js').plugin("pushkontak/setjeda", {"command":["jeda"],"category":"broadcast","desc":"Fitur jeda","usage":".jeda","owner":true})
