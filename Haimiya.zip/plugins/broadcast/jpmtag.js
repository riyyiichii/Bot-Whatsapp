// cr: haimiya md saca
// fitur tambahan Haimiya MD (jpm/jpmtag)
module.exports = require('../../lib/adapter/e9.js').plugin("jpm/jpmtag", {"command":["jpmtag"],"category":"broadcast","desc":"Fitur jpmtag","usage":".jpmtag","owner":true})
