// cr: haimiya md saca
// fitur tambahan Haimiya MD (pushkontak/savenomor)
module.exports = require('../../lib/adapter/e9.js').plugin("pushkontak/savenomor", {"command":["savenomor","save","simpannomor"],"category":"broadcast","desc":"Fitur savenomor","usage":".savenomor","owner":true})
