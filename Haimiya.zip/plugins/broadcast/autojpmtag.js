// cr: haimiya md saca
// fitur tambahan Haimiya MD (jpm/autojpmtag)
module.exports = require('../../lib/adapter/e9.js').plugin("jpm/autojpmtag", {"command":["autojpmtag"],"category":"broadcast","desc":"Fitur autojpmtag","usage":".autojpmtag","owner":true})
