// cr: haimiya md saca
// fitur tambahan Haimiya MD (jpm/swgcall)
module.exports = require('../../lib/adapter/e9.js').plugin("jpm/swgcall", {"command":["swgcall"],"category":"broadcast","desc":"Fitur swgcall","usage":".swgcall","owner":true})
