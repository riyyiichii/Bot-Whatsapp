// cr: haimiya md saca
// fitur tambahan Haimiya MD (jpm/setdelayautoswgc)
module.exports = require('../../lib/adapter/e9.js').plugin("jpm/setdelayautoswgc", {"command":["setdelayautoswgc"],"category":"broadcast","desc":"Fitur setdelayautoswgc","usage":".setdelayautoswgc","owner":true})
