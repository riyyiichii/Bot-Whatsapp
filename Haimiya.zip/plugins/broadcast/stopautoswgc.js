// cr: haimiya md saca
// fitur tambahan Haimiya MD (jpm/stopautoswgc)
module.exports = require('../../lib/adapter/e9.js').plugin("jpm/stopautoswgc", {"command":["stopautoswgc"],"category":"broadcast","desc":"Fitur stopautoswgc","usage":".stopautoswgc","owner":true})
