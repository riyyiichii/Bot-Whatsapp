// cr: haimiya md saca
// fitur tambahan Haimiya MD (jpm/stopautojpm)
module.exports = require('../../lib/adapter/e9.js').plugin("jpm/stopautojpm", {"command":["stopautojpm"],"category":"broadcast","desc":"Fitur stopautojpm","usage":".stopautojpm","owner":true})
