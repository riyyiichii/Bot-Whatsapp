// cr: haimiya md saca
// fitur tambahan Haimiya MD (jpm/setdelayjpmtag)
module.exports = require('../../lib/adapter/e9.js').plugin("jpm/setdelayjpmtag", {"command":["setdelayjpmtag"],"category":"broadcast","desc":"Fitur setdelayjpmtag","usage":".setdelayjpmtag","owner":true})
