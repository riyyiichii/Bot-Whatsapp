// cr: haimiya md saca
// fitur tambahan Haimiya MD (pushkontak/setdelaypushkontak)
module.exports = require('../../lib/adapter/e9.js').plugin("pushkontak/setdelaypushkontak", {"command":["setdelaypushkontak"],"category":"broadcast","desc":"Fitur setdelaypushkontak","usage":".setdelaypushkontak","owner":true})
