// cr: haimiya md saca
// fitur tambahan Haimiya MD (jpm/stopswgc)
module.exports = require('../../lib/adapter/e9.js').plugin("jpm/stopswgc", {"command":["stopswgc"],"category":"broadcast","desc":"Fitur stopswgc","usage":".stopswgc","owner":true})
