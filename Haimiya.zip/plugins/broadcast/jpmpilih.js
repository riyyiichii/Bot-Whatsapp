// cr: haimiya md saca
// fitur tambahan Haimiya MD (jpm/jpmpilih)
module.exports = require('../../lib/adapter/e9.js').plugin("jpm/jpmpilih", {"command":["jpmpilih"],"category":"broadcast","desc":"Fitur jpmpilih","usage":".jpmpilih","owner":true})
