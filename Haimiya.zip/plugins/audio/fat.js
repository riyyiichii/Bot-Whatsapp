// cr: haimiya md saca
// fitur tambahan Haimiya MD (audio/fat)
module.exports = require('../../lib/adapter/e9.js').plugin("audio/fat", {"command":["fat"],"category":"audio","desc":"Fitur fat","usage":".fat"})
