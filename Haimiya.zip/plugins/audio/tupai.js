// cr: haimiya md saca
// fitur tambahan Haimiya MD (audio/tupai)
module.exports = require('../../lib/adapter/e9.js').plugin("audio/tupai", {"command":["tupai"],"category":"audio","desc":"Fitur tupai","usage":".tupai"})
