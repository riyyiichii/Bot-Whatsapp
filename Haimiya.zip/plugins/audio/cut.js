// cr: haimiya md saca
// fitur tambahan Haimiya MD (audio/cut)
module.exports = require('../../lib/adapter/e9.js').plugin("audio/cut", {"command":["cut"],"category":"audio","desc":"Fitur cutaudio","usage":".cut"})
