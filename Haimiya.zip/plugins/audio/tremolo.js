// cr: haimiya md saca
// fitur tambahan Haimiya MD (audio/tremolo)
module.exports = require('../../lib/adapter/e9.js').plugin("audio/tremolo", {"command":["tremolo"],"category":"audio","desc":"Fitur tremolo","usage":".tremolo"})
