// cr: haimiya md saca
// fitur tambahan Haimiya MD (audio/robot)
module.exports = require('../../lib/adapter/e9.js').plugin("audio/robot", {"command":["robot"],"category":"audio","desc":"Fitur robot","usage":".robot"})
