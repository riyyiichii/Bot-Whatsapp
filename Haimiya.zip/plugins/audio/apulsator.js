// cr: haimiya md saca
// fitur tambahan Haimiya MD (audio/apulsator)
module.exports = require('../../lib/adapter/e9.js').plugin("audio/apulsator", {"command":["apulsator"],"category":"audio","desc":"Fitur apulsator","usage":".apulsator"})
