// cr: haimiya md saca
// fitur tambahan Haimiya MD (audio/nightcore)
module.exports = require('../../lib/adapter/e9.js').plugin("audio/nightcore", {"command":["nightcore"],"category":"audio","desc":"Fitur nightcore","usage":".nightcore"})
