// cr: haimiya md saca
// tts/ttseminem — satu file: metadata + kode fitur (gabungan dari engine7/plugins/tts/ttseminem.js)
const __hm = require("../../lib/adapter/e7.js")
const __meta = {
  "name": "ttseminem",
  "command": [
    "ttseminem",
    "eminemtts"
  ],
  "category": "audio",
  "desc": "Text to Speech dengan suara Eminem",
  "usage": ".ttseminem <text>",
  "owner": false,
  "group": false,
  "private": false,
  "premium": false,
  "cooldown": 15,
  "energi": 1,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/tts").split('\\').join('/')
module.exports = __hm.plugin("tts/ttseminem", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/ttseminem.js'
  const __hmDef = (m) => (m && m.__esModule ? m.default : m);
  const __hmExports = {};
  const axios = __hmDef(require("axios"));
  const { spawn } = require("child_process");
  const fs = __hmDef(require("fs"));
  const path = __hmDef(require("path"));
  const pluginConfig = {
      name: 'ttseminem',
      alias: ['eminemtts'],
      category: 'tts',
      description: 'Text to Speech dengan suara Eminem',
      usage: '.ttseminem <text>',
      example: '.ttseminem Rap God!',
      isOwner: false,
      isPremium: false,
      isGroup: false,
      isPrivate: false,
      cooldown: 15,
      energi: 1,
      isEnabled: true
  }
  
  async function convertToOpus(inputPath, outputPath) {
      return new Promise((resolve, reject) => {
          const ffmpeg = spawn('ffmpeg', ['-i', inputPath, '-c:a', 'libopus', '-b:a', '64k', '-vbr', 'on', '-compression_level', '10', '-y', outputPath])
          ffmpeg.on('close', (code) => code === 0 ? resolve(true) : reject(new Error(`FFmpeg error`)))
          ffmpeg.on('error', reject)
      })
  }
  
  async function handler(m, { sock }) {
      const text = m.text?.trim()
      if (!text) return m.reply(`🎤 *ᴇᴍɪɴᴇᴍ ᴛᴛs*\n\n> Gunakan: \`${m.prefix}ttseminem <text>\``)
      
      m.react('🎤')
      
      try {
          const res = await axios.get(`https://api.emiliabot.my.id/tools/text-to-speech?text=${encodeURIComponent(text)}`, { timeout: 60000 })
          const voice = res.data?.result?.find(v => v.eminem && !v.error)
          if (!voice) {
              m.react('❌')
              return m.reply(`❌ Eminem voice error. Coba TTS lain.`)
          }
          
          const tempDir = path.join(process.cwd(), 'temp')
          if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true })
          
          const wavPath = path.join(tempDir, `tts_${Date.now()}.wav`)
          const opusPath = path.join(tempDir, `tts_${Date.now()}.ogg`)
          
          const audioRes = await axios.get(voice.eminem, { responseType: 'arraybuffer' })
          fs.writeFileSync(wavPath, Buffer.from(audioRes.data))
          await convertToOpus(wavPath, opusPath)
          
          await sock.sendMessage(m.chat, {
              audio: fs.readFileSync(opusPath),
              mimetype: 'audio/ogg; codecs=opus',
              ptt: true,
              contextInfo: { isForwarded: true, forwardingScore: 999, externalAdReply: { title: '🎤 Eminem TTS', body: text.substring(0, 50), mediaType: 2 } }
          }, { quoted: m })
          
          fs.unlinkSync(wavPath)
          fs.unlinkSync(opusPath)
          m.react('✅')
      } catch (err) {
          m.react('❌')
          m.reply(`❌ *ᴇʀʀᴏʀ*\n\n> ${err.message}`)
      }
  }
  
  
  
  Object.defineProperty(__hmExports, "config", { enumerable: true, get: () => pluginConfig });
  Object.defineProperty(__hmExports, "handler", { enumerable: true, get: () => handler });
  return __hmExports
})
