// cr: haimiya md saca
// fitur tambahan Haimiya MD (audio/slow)
module.exports = require('../../lib/adapter/e9.js').plugin("audio/slow", {"command":["slow"],"category":"audio","desc":"Fitur slow","usage":".slow"})
