// cr: haimiya md saca
// fitur tambahan Haimiya MD (audio/bass)
module.exports = require('../../lib/adapter/e9.js').plugin("audio/bass", {"command":["bass"],"category":"audio","desc":"Fitur bass","usage":".bass"})
