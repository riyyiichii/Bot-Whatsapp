// cr: haimiya md saca
// fitur tambahan Haimiya MD (audio/echo)
module.exports = require('../../lib/adapter/e9.js').plugin("audio/echo", {"command":["echo"],"category":"audio","desc":"Fitur echo","usage":".echo"})
