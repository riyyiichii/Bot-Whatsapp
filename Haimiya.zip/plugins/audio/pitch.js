// cr: haimiya md saca
// fitur tambahan Haimiya MD (audio/pitch)
module.exports = require('../../lib/adapter/e9.js').plugin("audio/pitch", {"command":["pitch"],"category":"audio","desc":"Fitur pitch","usage":".pitch"})
