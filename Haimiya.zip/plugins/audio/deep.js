// cr: haimiya md saca
// fitur tambahan Haimiya MD (audio/deep)
module.exports = require('../../lib/adapter/e9.js').plugin("audio/deep", {"command":["deep"],"category":"audio","desc":"Fitur deep","usage":".deep"})
