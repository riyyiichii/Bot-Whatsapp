// cr: haimiya md saca
// fitur tambahan Haimiya MD (audio/blown)
module.exports = require('../../lib/adapter/e9.js').plugin("audio/blown", {"command":["blown"],"category":"audio","desc":"Fitur blown","usage":".blown"})
