// cr: haimiya md saca
// fitur tambahan Haimiya MD (audio/chorus)
module.exports = require('../../lib/adapter/e9.js').plugin("audio/chorus", {"command":["chorus"],"category":"audio","desc":"Fitur chorus","usage":".chorus"})
