// cr: haimiya md saca
// fitur tambahan Haimiya MD (audio/reverse)
module.exports = require('../../lib/adapter/e9.js').plugin("audio/reverse", {"command":["reverse"],"category":"audio","desc":"Fitur reverse","usage":".reverse"})
