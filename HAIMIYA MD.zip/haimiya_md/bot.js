// cr: haimiya md saca
require("./lib/bootstrap.js") // pasang dependency otomatis kalau belum ada (panel: cukup klik Start)
require("./lib/ffpath.js").install() // ffmpeg bawaan masuk PATH kalau server tidak punya
const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore,
  normalizeMessageContent,
  Browsers
} = require('@whiskeysockets/baileys')
require("./lib/quietlog.js").install()
try { require("./settings.js") } catch {}
// Banner ANSI sengaja TIDAK dicetak di sini lagi — kalau dicetak paling atas, dia ketimbun ratusan baris
// log pemuatan plugin dan jadi tidak kelihatan di console panel. Sekarang dicetak di startBot(), persis
// sebelum prompt nomor WhatsApp, supaya jadi hal terakhir (paling bawah) yang user lihat.
// Saringan warning Node yang cuma bikin berisik di console panel (mis. ExperimentalWarning WebSocket/HTTP2)
process.on('warning', (w) => { if (w?.name !== 'ExperimentalWarning') console.warn(w) })
// Respon cepat & anti-macet: IPv4 dulu (IPv6 yang buntu bikin request menggantung di VPS/panel) + batas waktu default semua request axios
try { require('dns').setDefaultResultOrder('ipv4first') } catch {}
try { const ax = require('axios'); if (!ax.defaults.timeout) ax.defaults.timeout = 45000 } catch {}
const { Boom } = require('@hapi/boom')
const pino = require('pino')
const readline = require('readline')
const fs = require('fs')
const path = require('path')
const config = require("./config.js")
const { userOf, getGroupInfo } = require("./lib/utils.js")
const { addExp } = require("./lib/db.js")
const { handleAntiLink } = require("./lib/antilink.js")
const { handleParticipants } = require("./lib/groups.js")
const { isBanned, handleAfk, handleBadWord, isMutedFor } = require("./lib/guard.js")
const { startScheduler } = require("./lib/scheduler.js")

const logger = pino({ level: 'silent' })
const pluginDir = path.join(__dirname, 'plugins')
const plugins = new Map()
global.__vanPlugins = () => [...new Set(plugins.values())] // dipakai lib/engine/registry.js (totalfitur2, benefitowner, searchplugin, dst.)
// Modul "hook" (tanpa perintah): passive(ctx) dipanggil untuk setiap pesan (return true = hentikan pemrosesan),
// onParticipants(sock, ev) untuk peristiwa anggota grup, init(sock) saat bot terhubung (harus idempoten).
const hooks = []

// ---------- Settings (mode self/public) ----------
const settingsFile = path.join(__dirname, 'settings.json')
const settings = { mode: 'public' }
try {
  Object.assign(settings, JSON.parse(fs.readFileSync(settingsFile, 'utf8')))
} catch {}
const saveSettings = () => fs.writeFileSync(settingsFile, JSON.stringify(settings, null, 2))

// ---------- Auto load plugins (rekursif) ----------
function walk(dir) {
  const out = []
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name)
    if (entry.name.startsWith('.')) continue
    if (entry.isDirectory()) out.push(...walk(full))
    else if (entry.name.endsWith('.js')) out.push(full)
  }
  return out
}

function loadPlugins() {
  plugins.clear()
  hooks.length = 0
  if (!fs.existsSync(pluginDir)) fs.mkdirSync(pluginDir, { recursive: true })
  const result = { loaded: 0, failed: [] }
  const cats = require("./lib/categories.js")

  // Tahap 1: muat semua file (kategori otomatis dirapikan lewat lib/categories.js)
  const found = []
  for (const full of walk(pluginDir).sort()) {
    const file = path.relative(pluginDir, full)
    try {
      delete require.cache[require.resolve(full)]
      const plugin = require(full)
      if (plugin && plugin.hook === true && (plugin.passive || plugin.onParticipants || plugin.init)) {
        found.push({ file, full, plugin, hook: true })
        continue
      }
      if (typeof plugin.run !== 'function' || !plugin.command) {
        plog('skip', file, 'format salah (butuh run & command)')
        result.failed.push({ file, error: 'format salah (butuh run & command)' })
        continue
      }
      plugin.category = cats.canon(plugin.category)
      found.push({ file, full, plugin, hook: false })
    } catch (err) {
      // Error modul native (mis. sharp "Could not load... Possible solutions: ...") panjangnya bisa puluhan baris
      // dan isinya path file + saran install — kalau ditampilkan apa adanya, console panel jadi penuh sampah
      // dan banner/prompt nomor ketimbun. Di sini cukup 1 baris ringkas; detail lengkapnya disimpan ke file log.
      const fullMsg = String(err?.stack || err?.message || err)
      const firstLine = String(err?.message || err).split('\n')[0].trim()
      const isNative = /\.node\b|invalid ELF header|was compiled against a different|NODE_MODULE_VERSION|Could not load the ["'].*["']\s+module|libvips/i.test(fullMsg)
      plog('fail', file, isNative ? 'modul native tidak kompatibel dengan server ini' : firstLine)
      try {
        fs.mkdirSync(path.join(__dirname, 'logs'), { recursive: true })
        fs.appendFileSync(path.join(__dirname, 'logs', 'plugin-errors.log'), `[${new Date().toISOString()}] ${file}\n${fullMsg}\n\n`)
      } catch {}
      result.failed.push({ file, error: firstLine })
    }
  }

  // Tahap 2: fitur asli Haimiya MD selalu menang — fitur dari engine/ (plugin.__ported = peringkat) didaftarkan paling akhir
  // dan tidak menimpa command yang sudah ada.
  found.sort((a, b) => (a.plugin.__ported || 0) - (b.plugin.__ported || 0) || (a.file < b.file ? -1 : 1))
  for (const { file, full, plugin, hook } of found) {
    if (hook) {
      hooks.push(plugin)
      result.loaded++
      continue
    }
    // catat file asal (tidak ikut ter-enumerate) untuk .addfitur / .delfitur
    Object.defineProperty(plugin, '__file', { value: full, enumerable: false, configurable: true, writable: true })
    let cmds = (Array.isArray(plugin.command) ? plugin.command : [plugin.command]).map((c) => String(c).toLowerCase())
    // plugin.override = varian terbaik hasil merge: sengaja MENIMPA command bercabang (play, tiktok, ytmp3, dst.)
    if (plugin.__ported && !plugin.override) {
      cmds = cmds.filter((c) => !plugins.has(c))
      if (!cmds.length) { result.loaded++; continue }
      plugin.command = cmds
    }
    for (const cmd of cmds) plugins.set(cmd, plugin)
    result.loaded++
  }
  const okTxt = pc.teal(`✔ ${result.loaded} plugin dimuat`)
  const failTxt = result.failed.length ? pc.red(`  ✖ ${result.failed.length} gagal`) + pc.dim(' (lihat baris di atas)') : ''
  console.log(`${pc.pink('[PLUGIN]')} ${okTxt}${failTxt}`)
  return result
}


// ---------- Helper ----------
const seen = new Set()

// Pesan "sedang diproses" tidak perlu jadi chat: cukup reaksi ⏳. Pesan gagal ditandai ❌.
const WAIT_RE = /^\s*(⏳|⌛|🔎|🔬)|^\s*(Mengunduh|Mencari|Membuat|Menguji|Mengirim|Memproses|Menghitung|Menyiapkan|Masuk antrian)/i
const FAIL_RE = /^\s*(❌|⚠️)|gagal|tidak ditemukan|tidak bisa|tidak valid|\berror\b|ditolak|kesalahan/i

function getBody(msg) {
  const m = normalizeMessageContent(msg.message)
  if (!m) return ''

  // Tombol interaktif (quick_reply / list): id tombol dipakai sebagai perintah
  const flow = m.interactiveResponseMessage?.nativeFlowResponseMessage
  if (flow) {
    let id = ''
    try {
      const parsed = typeof flow.paramsJson === 'string' ? JSON.parse(flow.paramsJson || '{}') : flow.paramsJson || {}
      id = parsed.id || parsed.selectedId || parsed.row_id || ''
      // cadangan: cocokkan teks tombol dengan kartu yang dibalas
      if (!id) id = require("./lib/cardreply.js").lookupByLabel(msg, parsed.display_text || m.interactiveResponseMessage?.body?.text) || ''
    } catch (err) {
      console.log('[BTN] paramsJson tidak terbaca:', err.message)
    }
    console.log(`[BTN] tombol ditekan (${flow.name || '?'}): ${id ? id.slice(0, 120) : 'KOSONG, mentah=' + String(flow.paramsJson).slice(0, 200)}`)
    return id
  }
  if (m.templateButtonReplyMessage?.selectedId) return m.templateButtonReplyMessage.selectedId

  return (
    m.conversation ||
    m.extendedTextMessage?.text ||
    m.imageMessage?.caption ||
    m.videoMessage?.caption ||
    m.buttonsResponseMessage?.selectedButtonId ||
    m.listResponseMessage?.singleSelectReply?.selectedRowId ||
    ''
  )
}

const owners = require("./lib/owners.js")
const isOwnerJid = (jid) => owners.isOwner(jid)

function question(text) {
  // Console Pterodactyl hanya menampilkan baris yang diakhiri newline. Prompt readline tidak pakai newline,
  // jadi tulisannya tidak pernah muncul dan bot terlihat "stuck". Tulis dulu lewat console.log.
  console.log(text)
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: false })
  return new Promise((resolve) =>
    rl.question('\u001b[38;2;127;255;212m❯ \u001b[0m', (answer) => {
      rl.close()
      resolve(answer)
    })
  )
}

// Warna-warni buat notifikasi pairing (truecolor ANSI, sama seperti kotak nomor WhatsApp)
const pc = {
  pink: (t) => `\u001b[1;38;2;255;110;199m${t}\u001b[0m`,
  purple: (t) => `\u001b[1;38;2;192;132;252m${t}\u001b[0m`,
  blue: (t) => `\u001b[1;38;2;96;165;250m${t}\u001b[0m`,
  teal: (t) => `\u001b[1;38;2;127;255;212m${t}\u001b[0m`,
  yellow: (t) => `\u001b[1;38;2;251;191;36m${t}\u001b[0m`,
  red: (t) => `\u001b[1;38;2;248;113;113m${t}\u001b[0m`,
  white: (t) => `\u001b[1;38;2;249;250;251m${t}\u001b[0m`,
  dim: (t) => `\u001b[38;2;156;163;175m${t}\u001b[0m`
}
// Log per-plugin seragam: [PLUGIN] <status berwarna> <nama file> — <keterangan>
function plog(kind, file, msg = '') {
  const tag = pc.pink('[PLUGIN]')
  const map = {
    ok: [pc.teal, '✔ dimuat'],
    skip: [pc.yellow, '⚠ dilewati'],
    fail: [pc.red, '✖ gagal']
  }
  const [col, label] = map[kind] || [pc.white, kind]
  console.log(`${tag} ${col(label)} ${pc.purple(file)}${msg ? pc.dim(' — ' + msg) : ''}`)
}

// Kode pairing dalam kotak gradasi: setiap karakter beda warna (pink -> ungu -> biru -> teal)
function pairingBox(code) {
  const pretty = String(code).match(/.{1,4}/g)?.join('-') || String(code)
  const palette = [[255,110,199],[192,132,252],[96,165,250],[127,255,212]]
  const grad = [...pretty].map((ch, i) => {
    if (ch === '-') return pc.dim(ch)
    const t = i / Math.max(1, pretty.length - 1)
    const seg = Math.min(palette.length - 2, Math.floor(t * (palette.length - 1)))
    const f = t * (palette.length - 1) - seg
    const a = palette[seg], b = palette[seg + 1]
    const c = a.map((v, k) => Math.round(v + (b[k] - v) * f))
    return `\u001b[1;38;2;${c[0]};${c[1]};${c[2]}m${ch}\u001b[0m`
  }).join('')
  const title = 'PAIRING CODE'
  const inner = Math.max(title.length, pretty.length) + 4 // lebar isi kotak (tanpa border)
  const padTo = (plain) => ' '.repeat(Math.max(0, inner - plain.length))
  const titleLine = '  ' + title + padTo('  ' + title)
  const codeLine = '  ' + grad + ' '.repeat(Math.max(0, inner - 2 - pretty.length))
  const line = (c) => pc.teal('│') + c + pc.teal('│')
  return [
    '',
    pc.teal('╭' + '─'.repeat(inner) + '╮'),
    line(pc.pink(titleLine)),
    line(codeLine),
    pc.teal('╰' + '─'.repeat(inner) + '╯')
  ].join('\n')
}

// Kotak prompt bergaya buat nanya nomor WhatsApp di console panel (dipanggil persis sebelum question()).
function phoneBox(title, hint) {
  const teal = (s) => `\u001b[38;2;127;255;212m${s}\u001b[0m`
  const pink = (s) => `\u001b[38;2;255;110;199m${s}\u001b[0m`
  const dim = (s) => `\u001b[38;2;150;150;150m${s}\u001b[0m`
  const width = Math.max(title.length, hint.length) + 2
  const pad = (s) => s + ' '.repeat(Math.max(0, width - s.length))
  return [
    '',
    teal('╭─' + '─'.repeat(width) + '─╮'),
    teal('│ ') + pink(pad(title)) + teal(' │'),
    teal('│ ') + dim(pad(hint)) + teal(' │'),
    teal('╰─' + '─'.repeat(width) + '─╯')
  ].join('\n')
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

// fetchLatestBaileysVersion tidak punya timeout; kalau GitHub lambat/diblok panel, bot menggantung diam-diam.
async function getWaVersion() {
  try {
    const res = await Promise.race([
      fetchLatestBaileysVersion(),
      new Promise((_, rej) => setTimeout(() => rej(new Error('timeout 8 detik')), 8000))
    ])
    return res.version
  } catch (err) {
    console.log('[BOT] gagal ambil versi WA terbaru, pakai versi bawaan Baileys:', err.message)
    return undefined
  }
}

// Identitas perangkat: Android hanya jika sesi sudah terdaftar dan Baileys mendukung Browsers.android
function pickBrowser(state) {
  const web = Browsers.ubuntu ? Browsers.ubuntu('Chrome') : ['Ubuntu', 'Chrome', '20.0.04']
  if (!state?.creds?.registered) return web
  try {
    // Otomatis: akun WhatsApp Business (platform 'smba'/'smbi') pakai SMB_ANDROID, akun biasa pakai Android
    const platform = String(state.creds.platform || '').toLowerCase()
    if (platform.startsWith('smb') && Browsers.SMB_ANDROID) return Browsers.SMB_ANDROID
    if (typeof Browsers.android === 'function') return Browsers.android('13')
  } catch {}
  console.log('[BOT] Baileys ini tidak punya Browsers.android — pakai identitas web (view-once tidak akan terkirim ke bot). Upgrade ke 7.0.0-rc14+')
  return web
}

// ---------- Start bot ----------
async function startBot() {
  console.log('[BOT] membaca sesi & menyiapkan koneksi...')
  const { state, saveCreds } = await useMultiFileAuthState(
    path.join(__dirname, config.sessionDir)
  )
  const version = await getWaVersion()

  const sock = makeWASocket({
    ...(version ? { version } : {}),
    logger,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, logger)
    },
    // View-once hanya dikirim WhatsApp ke perangkat Android: web saat pairing (Android merusak pairing code), Android setelah terdaftar
    browser: pickBrowser(state),
    markOnlineOnConnect: false,
    syncFullHistory: false, // jangan unduh riwayat lama: start lebih cepat & hemat RAM
    connectTimeoutMs: 60000,
    keepAliveIntervalMs: 25000,
    defaultQueryTimeoutMs: 60000,
    retryRequestDelayMs: 250,
    getMessage: async (key) => require("./lib/viewonce.js").getStoredWAMessage(key) // simpan pesan masuk: dipakai kirim ulang & .vv
  })
  global.conn = global.mainSock = sock // fitur gaya `conn` membaca global ini

  sock.ev.on('creds.update', saveCreds)

  // jalur kirim mentah (tanpa lapisan tampilan)
  sock.__rawSend = sock.sendMessage.bind(sock)
  // Pesan rich (kartu HTML, game HTML, AI rich) langsung tampil tanpa tombol "Unduh" (lib/richfix.js). Dipasang paling dalam
  // supaya semua pengirim rich di bawahnya (richui, plugin game, engine) otomatis kebagian.
  require("./lib/richfix.js").install(sock)
  require("./lib/thumb.js").install() // global.getThumbnail() / getMenuMedia(): foto & GIF thumbnail dari settings.js
  // UI kartu HTML: semua balasan teks otomatis jadi kartu (lihat lib/richui.js; matikan lewat global.uiMode = 'text')
  require("./lib/richui.js").install(sock, config)
  // Rapikan semua balasan teks fitur bergaya Haimiya MD (judul, garis, baris label, footer). Matikan: global.uiFormat = false
  global.__mess = config.mess
  global.__prefix = config.prefix
  require("./lib/fmt.js").install(sock)
  // Pengirim tombol / carousel / produk / AI rich = kode Haimiya MD asli (engine/lib/wraper-send). Dipasang paling luar.
  await require("./lib/adapter/send.js").install(sock)

  // ---------- Pairing code (tanpa QR) ----------
  if (!sock.authState.creds.registered) {
    // Nomor bisa diisi di settings.js (global.pairingNumber = '628xxx') atau env PAIRING_NUMBER,
    // jadi tidak perlu mengetik di console panel. Kalau kosong, bot menanyakannya di console.
    let input = process.env.PAIRING_NUMBER || global.pairingNumber || ''
    if (!String(input).replace(/[^0-9]/g, '')) {
      // Banner dicetak di sini (paling bawah, persis sebelum tanya nomor) biar tidak ketimbun log plugin/npm di atasnya
      require("./lib/banner.js").print()
      input = await question(phoneBox('📱  MASUKKAN NOMOR WHATSAPP BOT', 'Contoh: 628123456789 (kode negara, tanpa + atau spasi)'))
    }
    const phoneNumber = String(input).replace(/[^0-9]/g, '')
    if (!phoneNumber) {
      console.log('Nomor tidak valid.')
      process.exit(1)
    }
    console.log(`[BOT] meminta pairing code untuk ${phoneNumber}...`)
    await sleep(3000) // tunggu websocket terbuka dulu
    let code
    for (let i = 1; i <= 3 && !code; i++) {
      try {
        // Custom pairing code: WhatsApp cuma terima tepat 8 karakter huruf/angka (ditampilkan XXXX-XXXX).
        // "KUREZAMD" pas 8 karakter. Kalau nanti mau ganti kata lain, pastikan tetap 8 karakter persis.
        code = await sock.requestPairingCode(phoneNumber, 'KUREZAMD')
      } catch (err) {
        console.log(pc.red(`[BOT] ✖ gagal minta pairing code (percobaan ${i}/3): `) + pc.yellow(err.message))
        await sleep(3000)
      }
    }
    if (!code) {
      console.log(pc.red('[BOT] ✖ pairing code gagal diminta. ') + pc.yellow('Cek nomor (pakai kode negara, tanpa +) dan koneksi internet panel, lalu restart.'))
      process.exit(1)
    }
    console.log(pairingBox(code))
    console.log(pc.blue('📲 Buka ') + pc.purple('WhatsApp > Perangkat tertaut > Tautkan dengan nomor telepon') + pc.blue(', lalu masukkan kode di atas.'))
    console.log(pc.yellow('⏳ Kode berlaku sebentar, segera masukkan di WhatsApp.') + '\n')
  }

  sock.ev.on('connection.update', ({ connection, lastDisconnect }) => {
    if (connection === 'open') {
      console.log(`[${config.botName}] terhubung sebagai ${sock.user?.id}`)
      startScheduler(sock)
      for (const h of hooks) if (typeof h.init === 'function') Promise.resolve().then(() => h.init(sock)).catch((err) => console.log('[HOOK] init', h.name, err.message))
      require("./lib/voip.js").init(sock).catch(() => {})
      require("./lib/autojoin.js").run(sock).catch((err) => console.log('[AUTOJOIN]', err.message))
    }

    if (connection === 'close') {
      const code = new Boom(lastDisconnect?.error)?.output?.statusCode
      if (code === DisconnectReason.loggedOut) {
        console.log('Sesi logout. Hapus isi folder session lalu jalankan ulang untuk pairing baru.')
        process.exit(1)
      }
      console.log(`Koneksi terputus (kode ${code}), menyambung ulang...`)
      startBot()
    }
  })

  // ---------- Welcome / leave ----------
  sock.ev.on('group-participants.update', (ev) =>
    handleParticipants(sock, ev).catch((err) => console.log('[ERROR] welcome/leave:', err.message))
  )
  sock.ev.on('group-participants.update', async (ev) => {
    for (const h of hooks) if (typeof h.onParticipants === 'function') { try { await h.onParticipants(sock, ev) } catch (err) { console.log('[HOOK] onParticipants', h.name, err.message) } }
  })

  // Satu fungsi pemroses pesan untuk bot utama DAN jadibot (parameter sock = socket yang menerima pesan)
  const handleUpsert = async (sock, { messages, type }) => {
    if (type !== 'notify' && type !== 'append') return

    for (const msg of messages) {
      try {
        if (msg.key.remoteJid === 'status@broadcast') continue
        if (!msg.message) continue // peristiwa grup/sistem atau pesan yang gagal didekripsi (diringkas oleh lib/quietlog)
        try { require("./lib/viewonce.js").rememberWAMessage(msg) } catch {} // simpan SEMUA pesan masuk (store untuk .vv & getMessage)
        if (type === 'notify') { try { require("./lib/viewonce.js").capture(sock, msg) } catch {}; try { require("./lib/adapter/e9.js").captureViewOnce(sock, msg) } catch {} } // simpan media sekali-lihat saat masuk (dipakai .rvo)
        // 'append' = pesan lama/riwayat; hanya tekanan tombol yang masih baru yang diproses
        const tap = require("./lib/cardreply.js").isTap(msg)
        if (type === 'append' && !(tap && Date.now() / 1000 - Number(msg.messageTimestamp || 0) < 120)) continue
        if (seen.has(msg.key.id)) continue
        seen.add(msg.key.id)
        if (seen.size > 2000) seen.delete(seen.values().next().value)
        if (tap) console.log(`[RX] balasan tombol diterima (${Object.keys(msg.message).join(',')}) dari ${msg.key.participant || msg.key.remoteJid}`)

        const from = msg.key.remoteJid
        const isGroup = from.endsWith('@g.us')
        const sender = isGroup
          ? msg.key.participant || msg.participant
          : msg.key.fromMe
            ? sock.user.id
            : from

        let body = getBody(msg).trim()
        if (tap && !body) console.log('[BTN] balasan tombol diterima tetapi tidak ada perintahnya:', JSON.stringify(msg.message).slice(0, 400))

        // Balas kartu interaktif dengan angka/kata (cadangan bila tombol tidak merespons)
        if (body && !body.startsWith(config.prefix)) {
          const viaReply = require("./lib/cardreply.js").resolve(msg, body)
          if (viaReply) {
            console.log(`[BTN] via balasan kartu: "${body}" → ${viaReply.slice(0, 100)}`)
            body = viaReply
          }
        }

        if (isGroup && !msg.key.fromMe && sender) require("./lib/activity.js").count(from, sender)

        // Antidelete + auto-respon grup (lib/grouptools.js). Gagal di sini tidak boleh menghentikan bot.
        let autoStop = false
        try { autoStop = await require("./lib/grouptools.js").observe(sock, msg, { from, sender, isGroup, body, prefix: config.prefix }) } catch (err) { console.log('[GROUPTOOLS]', err.message) }
        if (autoStop) continue

        // Antilink: jalan untuk semua pesan grup (bukan hanya perintah)
        if (isGroup && !msg.key.fromMe && (await handleAntiLink(sock, msg, { from, sender, body, isOwner: isOwnerJid(sender) || owners.isOwnerMsg(msg) }))) continue

        // Antibadword + AFK: jalan untuk semua pesan, bukan hanya perintah
        if (isGroup && !msg.key.fromMe && (await handleBadWord(sock, msg, { from, sender, body, isOwner: isOwnerJid(sender) || owners.isOwnerMsg(msg) }))) continue
        if (!msg.key.fromMe) await handleAfk(sock, msg, { from, sender, body, prefix: config.prefix })

        // Anti-spam grup: hanya cek info admin ketika batas flood terlewati
        if (isGroup && !msg.key.fromMe && sender && require("./lib/antispam.js").enabled(from) && !isOwnerJid(sender) && !owners.isOwnerMsg(msg)) {
          const hit = require("./lib/antispam.js").check(from, sender, msg.key)
          if (hit) {
            const info = await getGroupInfo(sock, from, sender)
            if (!info.isAdmin) {
              if (info.isBotAdmin) for (const k of hit.keys) sock.sendMessage(from, { delete: k }).catch(() => {})
              if (hit.warn) await sock.sendMessage(from, { text: `🚫 @${userOf(sender)} terdeteksi spam (pesan beruntun). Mohon kirim pesan dengan wajar.`, mentions: [sender] })
              continue
            }
          }
        }

        // Hook pasif plugin (anti-tagall, jawaban game tanpa prefix, dll). Return true = pesan sudah ditangani.
        if (hooks.length) {
          const hookCtx = { sock, msg, from, sender, isGroup, body, prefix: config.prefix, config, settings, isOwner: !!msg.key.fromMe || isOwnerJid(sender) || owners.isOwnerMsg(msg) }
          let stop = false
          for (const h of hooks) {
            if (typeof h.passive !== 'function') continue
            try { if (await h.passive(hookCtx)) { stop = true; break } } catch (err) { console.log('[HOOK] passive', h.name, err.message) }
          }
          if (stop) continue
        }

        const isOwner = !!msg.key.fromMe || isOwnerJid(sender) || owners.isOwnerMsg(msg)
        // prefix dinamis (.setprefix) + mode tanpa prefix (.prefix off / .noprfx on) — lib/haimiya.js
        const plen = require("./lib/adapter/core.js").prefixLen(body, isOwner, (w) => plugins.has(w))
        if (plen < 0) continue

        const args = body.slice(plen).trim().split(/\s+/)
        let command = (args.shift() || '').toLowerCase()
        if (!command) continue
        try { if (command === require("./lib/viewonce.js").vvName()) command = 'vv' } catch {} // nama kustom dari .setvvcmd

        const plugin = plugins.get(command)
        if (!plugin) continue

        // Wajib daftar (.regis on): user belum terdaftar diminta .daftar dulu
        if (require("./lib/adapter/core.js").regisBlock(sender, isOwner, command)) {
          await sock.sendMessage(from, { text: `Kamu belum terdaftar. Ketik *${config.prefix}daftar* dulu untuk memakai bot.` }, { quoted: msg }).catch(() => {})
          continue
        }

        // Mode self: hanya owner yang dilayani
        if (settings.mode === 'self' && !isOwner && !(isGroup && require("./lib/adapter/owner.js").isBypass(from))) continue

        // User di-ban & grup di-mute (kecuali admin) diabaikan
        if (!isOwner && isBanned(sender)) continue
        if (isGroup && !isOwner && (await isMutedFor(sock, { from, sender, command }))) continue

        const ctx = {
          sock,
          msg,
          from,
          sender,
          isGroup,
          isOwner,
          body,
          args,
          text: args.join(' '),
          command,
          prefix: config.prefix,
          config,
          settings,
          saveSettings,
          plugins: [...new Set(plugins.values())],
          reloadPlugins: loadPlugins
        }

        // ---- Indikator proses lewat reaksi emoji: ⏳ saat menunggu, ✅ saat selesai, ❌ saat gagal ----
        const state = { waiting: false, failed: false }
        const react = (emoji) => sock.sendMessage(from, { react: { text: emoji, key: msg.key } }).catch(() => {})
        ctx.react = (emoji = '⏳') => {
          if (emoji === '⏳') {
            if (state.waiting) return Promise.resolve()
            state.waiting = true
          }
          return react(emoji)
        }
        ctx.reply = (text) => {
          const t = String(text)
          if (WAIT_RE.test(t)) return ctx.react('⏳') // "Mengunduh..." dll tidak dikirim sebagai chat
          if (state.waiting && FAIL_RE.test(t.slice(0, 120))) state.failed = true
          return sock.sendMessage(from, { text }, { quoted: msg })
        }
        // perintah yang berjalan lebih dari ±1,2 detik otomatis diberi ⏳
        const slowTimer = plugin.selfReact ? null : setTimeout(() => ctx.react('⏳'), 1200)

        if (plugin.owner && !isOwner) {
          clearTimeout(slowTimer)
          await ctx.reply(config.mess.only.owner)
          continue
        }

        if ((plugin.group || plugin.admin || plugin.botAdmin) && !isGroup) {
          clearTimeout(slowTimer)
          await ctx.reply(config.mess.only.group)
          continue
        }

        // Plugin yang membaca isAdmin / isBotAdmin / groupMetadata dari ctx otomatis mendapat info grup
        // (sebelumnya hanya plugin ber-flag admin/botAdmin, sehingga swgc/absen/topchat selalu menolak admin).
        const wantsInfo = isGroup && !plugin.admin && !plugin.botAdmin && (plugin.needsInfo || /\b(isAdmin|isBotAdmin|groupMetadata)\b/.test(String(plugin.run)))
        if (wantsInfo) {
          try {
            const info = await getGroupInfo(sock, from, sender)
            ctx.groupMetadata = info.metadata
            ctx.isAdmin = info.isAdmin
            ctx.isBotAdmin = info.isBotAdmin
          } catch (err) {
            console.log('[GROUP] gagal membaca info grup:', err.message)
            ctx.isAdmin = false
            ctx.isBotAdmin = false
          }
        }

        if (plugin.admin || plugin.botAdmin) {
          const info = await getGroupInfo(sock, from, sender)
          if (plugin.admin && !info.isAdmin && !isOwner) {
            clearTimeout(slowTimer)
            await ctx.reply(config.mess.only.admin)
            continue
          }
          if (plugin.botAdmin && !info.isBotAdmin) {
            clearTimeout(slowTimer)
            await ctx.reply(config.mess.only.badmin)
            continue
          }
          ctx.groupMetadata = info.metadata
          ctx.isAdmin = info.isAdmin
          ctx.isBotAdmin = info.isBotAdmin
        }

        // ---- Mode bertahan hidup: tiap fitur memakai energi, saldo, dan limit (lib/survival.js) ----
        let spent = null
        try {
          const gate = require("./lib/survival.js").charge({ sender, plugin, command, isOwner, isPremium: require("./lib/adapter/owner.js").isPremium(sender) })
          if (gate.block) { clearTimeout(slowTimer); await ctx.reply(gate.block); continue }
          spent = gate
        } catch (err) { console.log('[SURVIVAL]', err.message) }

        try { require("./lib/cmdstats.js").hit(plugin.name || command, sender) } catch {}
        const player = addExp(sender, 10)
        if (msg.pushName) player.name = msg.pushName
        try {
          const names = [].concat(plugin.command).map((c) => String(c).toLowerCase())
          const richui = require("./lib/richui.js")
          await richui.run(
            {
              t0: Date.now(), name: msg.pushName || '', number: String(sender || '').split('@')[0].split(':')[0], category: plugin.category, command, body: ctx.body,
              title: String(plugin.name || command).replace(/[-_]+/g, ' '), icon: require("./lib/menuicons.js").cmdIcon(plugin, plugin.category),
              plain: names.some((n) => richui.OPTS.plain.has(n)),
              // metadata untuk panduan & detail eksekusi otomatis (lib/uidoc.js)
              desc: plugin.desc || '', usage: plugin.usage || '', aliases: names, isGroup, isOwner,
              owner: !!plugin.owner, admin: !!plugin.admin, group: !!plugin.group, botAdmin: !!plugin.botAdmin,
              groupName: ctx.groupMetadata?.subject || ''
            },
            () => require("./lib/menuflow.js").wrap(ctx, command, () => plugin.run(ctx))
          )
          clearTimeout(slowTimer)
          if (state.waiting) await react(state.failed ? '❌' : '✅')
        } catch (err) {
          clearTimeout(slowTimer)
          console.log(`[ERROR] ${command}:`, err)
          if (spent && spent.refund) spent.refund() // fitur gagal -> biaya dikembalikan
          if (state.waiting) await react('❌')
          await sock.sendMessage(from, { text: config.mess.error.fitur }, { quoted: msg }).catch(() => {})
        }
      } catch (err) {
        console.log('[ERROR] handler pesan:', err)
      }
    }
  }
  sock.ev.on('messages.upsert', (ev) => handleUpsert(sock, ev))
  global.__hmHandleUpsert = handleUpsert
}

// Satu folder session = satu proses. Dua proses sekaligus merusak sesi enkripsi (Bad MAC).
{
  const lockDir = path.join(__dirname, config.sessionDir)
  fs.mkdirSync(lockDir, { recursive: true })
  const lock = require("./lib/singleton.js").acquire(path.join(lockDir, '.bot.pid'))
  if (!lock.ok && !process.env.ALLOW_MULTI) {
    console.log(`\n[STOP] Bot ini sudah berjalan di proses lain (PID ${lock.pid}).`)
    console.log('Menjalankan dua bot dengan folder session yang sama merusak enkripsi (error "Bad MAC").')
    console.log(`Hentikan yang lama dulu:  kill ${lock.pid}   (atau pm2 stop all / tutup tab Termux lain)\n`)
    process.exit(1)
  }
}

{
  const code = owners.newClaimCode()
  console.log(`[OWNER] Kalau bot bilang "hanya untuk owner" padahal kamu owner (ID WhatsApp berupa @lid):`)
  console.log(`[OWNER] di CHAT PRIBADI ke bot kirim:  ${config.prefix}claimowner ${code}   (berlaku 30 menit, sekali pakai)`)
}

loadPlugins()
startBot()

process.on('unhandledRejection', (err) => console.log('[unhandledRejection]', err))
process.on('uncaughtException', (err) => console.log('[uncaughtException]', err))
