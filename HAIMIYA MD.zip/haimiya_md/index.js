// cr: haimiya md saca
// Alias entry point: beberapa panel memakai index.js sebagai file utama.
require('./bot')
