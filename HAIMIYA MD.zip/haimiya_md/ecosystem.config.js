// cr: haimiya md saca
module.exports = {
  apps: [
    {
      name: 'Haimiya MD',
      script: 'bot.js',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '500M',
      env: {
        NODE_ENV: 'production'
      }
    }
  ]
}
