# Credits

- **KurezaMD** — pembuat script dasar yang dipakai bot ini. Terima kasih.
- Bot: Haimiya MD

Ubah nama kredit di `settings.js` (`global.credit`).
