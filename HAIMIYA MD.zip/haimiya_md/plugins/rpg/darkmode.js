// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/darkmode)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/darkmode", {"command":["darkmode"],"category":"rpg","desc":"Fitur darkmode","usage":".darkmode"})
