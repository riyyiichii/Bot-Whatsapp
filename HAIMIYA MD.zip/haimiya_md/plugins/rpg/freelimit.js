// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/freelimit)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/freelimit", {"command":["freelimit"],"category":"rpg","desc":"Fitur freelimit","usage":".freelimit","group":true})
