// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/rpg-warteg)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/rpg-warteg", {"command":["rpg-warteg"],"category":"rpg","desc":"Fitur rpg-warteg","usage":".rpg-warteg","group":true})
