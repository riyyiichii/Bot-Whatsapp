// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/rpg-bank)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/rpg-bank", {"command":["rpg-bank"],"category":"rpg","desc":"Fitur rpg-bank","usage":".rpg-bank","group":true})
