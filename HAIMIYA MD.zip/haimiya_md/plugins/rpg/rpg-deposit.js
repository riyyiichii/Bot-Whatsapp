// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/rpg-deposit)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/rpg-deposit", {"command":["rpg-deposit"],"category":"rpg","desc":"Fitur rpg-deposit","usage":".rpg-deposit"})
