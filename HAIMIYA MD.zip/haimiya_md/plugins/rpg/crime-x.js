// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/crime)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/crime", {"command":["crime"],"category":"rpg","desc":"Melakukan kejahatan membobol ATM (risiko tinggi)","usage":".crime"})
