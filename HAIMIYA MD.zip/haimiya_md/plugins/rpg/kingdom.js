// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/kingdom)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/kingdom", {"command":["kingdom"],"category":"rpg","desc":"Fitur kingdom","usage":".kingdom"})
