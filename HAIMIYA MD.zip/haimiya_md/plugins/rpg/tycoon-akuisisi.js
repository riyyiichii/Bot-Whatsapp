// cr: haimiya md saca
// fitur tambahan Haimiya MD (tycoon/tycoon-akuisisi)
module.exports = require('../../lib/adapter/e9.js').plugin("tycoon/tycoon-akuisisi", {"command":["tycoon-akuisisi"],"category":"rpg","desc":"Akuisisi paksa","usage":".tycoon-akuisisi"})
