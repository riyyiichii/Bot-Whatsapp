// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/huntboss)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/huntboss", {"command":["huntboss"],"category":"rpg","desc":"Fitur huntboss","usage":".huntboss"})
