// cr: haimiya md saca
// fitur tambahan Haimiya MD (clan/clan-approve)
module.exports = require('../../lib/adapter/e9.js').plugin("clan/clan-approve", {"command":["clan-approve"],"category":"rpg","desc":"Setujui permintaan join (ketua): .clan-approve [all|nomor]","usage":".clan-approve","group":true})
