// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/rpg-buy)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/rpg-buy", {"command":["rpg-buy"],"category":"rpg","desc":"Fitur rpg-buy","usage":".rpg-buy","group":true})
