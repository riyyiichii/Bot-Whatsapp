// cr: haimiya md saca
// fitur tambahan Haimiya MD (tycoon/tycoon-dagang)
module.exports = require('../../lib/adapter/e9.js').plugin("tycoon/tycoon-dagang", {"command":["tycoon-dagang"],"category":"rpg","desc":"Dagang Harian","usage":".tycoon-dagang"})
