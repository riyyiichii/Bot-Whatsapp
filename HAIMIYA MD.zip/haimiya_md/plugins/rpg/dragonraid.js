// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/dragonraid)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/dragonraid", {"command":["dragonraid"],"category":"rpg","desc":"Fitur dragonraid","usage":".dragonraid"})
