// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/fish)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/fish", {"command":["fish"],"category":"rpg","desc":"Fitur fish","usage":".fish"})
