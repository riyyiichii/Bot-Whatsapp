// cr: haimiya md saca
// fitur tambahan Haimiya MD (koboy/koboy-daily)
module.exports = require('../../lib/adapter/e9.js').plugin("koboy/koboy-daily", {"command":["koboy-daily"],"category":"rpg","desc":"Fitur koboy-daily","usage":".koboy-daily"})
