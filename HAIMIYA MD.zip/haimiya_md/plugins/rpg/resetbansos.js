// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/resetbansos)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/resetbansos", {"command":["resetbansos"],"category":"rpg","desc":"Fitur resetbansos <nomor>","usage":".resetbansos","owner":true})
