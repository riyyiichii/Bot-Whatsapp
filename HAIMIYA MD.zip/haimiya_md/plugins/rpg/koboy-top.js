// cr: haimiya md saca
// fitur tambahan Haimiya MD (koboy/koboy-top)
module.exports = require('../../lib/adapter/e9.js').plugin("koboy/koboy-top", {"command":["koboy-top"],"category":"rpg","desc":"Fitur koboy-top","usage":".koboy-top"})
