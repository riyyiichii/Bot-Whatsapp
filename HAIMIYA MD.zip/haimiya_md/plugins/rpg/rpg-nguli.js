// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/rpg-nguli)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/rpg-nguli", {"command":["rpg-nguli"],"category":"rpg","desc":"Fitur rpg-nguli","usage":".rpg-nguli","group":true})
