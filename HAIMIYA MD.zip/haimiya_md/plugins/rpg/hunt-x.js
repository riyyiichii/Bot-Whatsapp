// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/hunt)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/hunt", {"command":["hunt"],"category":"rpg","desc":"Berburu, dapat drop + exp","usage":".hunt"})
