// cr: haimiya md saca
// fitur tambahan Haimiya MD (clan/clanraport)
module.exports = require('../../lib/adapter/e9.js').plugin("clan/clanraport", {"command":["clanraport"],"category":"rpg","desc":"Lihat laporan aktivitas clan","usage":".clanraport"})
