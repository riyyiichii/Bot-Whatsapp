// cr: haimiya md saca
// fitur tambahan Haimiya MD (ninja/ninja-skill)
module.exports = require('../../lib/adapter/e9.js').plugin("ninja/ninja-skill", {"command":["ninja-skill"],"category":"rpg","desc":"Lihat/upgrade skill","usage":".ninja-skill"})
