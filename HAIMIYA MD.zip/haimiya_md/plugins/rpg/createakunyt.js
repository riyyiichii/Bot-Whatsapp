// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/createakunyt)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/createakunyt", {"command":["createakunyt","createakun"],"category":"rpg","desc":"Fitur createakunyt createakun","usage":".createakunyt","group":true})
