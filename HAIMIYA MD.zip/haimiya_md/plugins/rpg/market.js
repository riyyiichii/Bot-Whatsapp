// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/market)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/market", {"command":["market"],"category":"rpg","desc":"Jual/beli di pasar antar player","usage":".market"})
