// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/talent)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/talent", {"command":["talent"],"category":"rpg","desc":"Fitur talent","usage":".talent"})
