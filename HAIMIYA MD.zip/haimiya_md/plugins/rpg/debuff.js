// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/debuff)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/debuff", {"command":["debuff"],"category":"rpg","desc":"Fitur debuff","usage":".debuff"})
