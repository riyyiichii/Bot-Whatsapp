// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/rpg-warnet)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/rpg-warnet", {"command":["rpg-warnet"],"category":"rpg","desc":"Fitur rpg-warnet","usage":".rpg-warnet","group":true})
