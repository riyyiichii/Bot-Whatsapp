// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/expedition)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/expedition", {"command":["expedition"],"category":"rpg","desc":"Kirim ekspedisi otomatis untuk item","usage":".expedition"})
