// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/taxy)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/taxy", {"command":["taxy"],"category":"rpg","desc":"Fitur taxy","usage":".taxy","group":true})
