// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/rpg-mentransfer)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/rpg-mentransfer", {"command":["rpg-mentransfer"],"category":"rpg","desc":"Fitur rpg-mentransfer","usage":".rpg-mentransfer","group":true})
