// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/rpg-nebang)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/rpg-nebang", {"command":["rpg-nebang"],"category":"rpg","desc":"Fitur rpg-nebang","usage":".rpg-nebang","group":true})
