// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/collect)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/collect", {"command":["collect"],"category":"rpg","desc":"Fitur collect","usage":".collect","group":true})
