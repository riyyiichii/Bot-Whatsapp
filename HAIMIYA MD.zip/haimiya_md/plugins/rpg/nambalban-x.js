// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/nambalban)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/nambalban", {"command":["nambalban"],"category":"rpg","desc":"Buka jasa tambal ban, awas ban meledak!","usage":".nambalban"})
