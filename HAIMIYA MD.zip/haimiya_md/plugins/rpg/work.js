// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/work)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/work", {"command":["work"],"category":"rpg","desc":"Bekerja untuk mendapatkan uang","usage":".work"})
