// cr: haimiya md saca
// fitur tambahan Haimiya MD (clan/clanlevel)
module.exports = require('../../lib/adapter/e9.js').plugin("clan/clanlevel", {"command":["clanlevel"],"category":"rpg","desc":"Lihat level clan","usage":".clanlevel"})
