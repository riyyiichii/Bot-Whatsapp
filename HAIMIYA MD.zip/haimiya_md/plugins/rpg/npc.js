// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/npc)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/npc", {"command":["npc"],"category":"rpg","desc":"Bicara dengan NPC","usage":".npc"})
