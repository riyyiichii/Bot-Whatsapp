// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/garden)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/garden", {"command":["garden"],"category":"rpg","desc":"Berkebun dan panen tanaman","usage":".garden"})
