// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/akunyt)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/akunyt", {"command":["akunyt"],"category":"rpg","desc":"Fitur akunyt","usage":".akunyt","group":true})
