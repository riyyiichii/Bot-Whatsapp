// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/death)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/death", {"command":["death"],"category":"rpg","desc":"Fitur death","usage":".death"})
