// cr: haimiya md saca
// fitur tambahan Haimiya MD (clan/clanwarhistory)
module.exports = require('../../lib/adapter/e9.js').plugin("clan/clanwarhistory", {"command":["clanwarhistory"],"category":"rpg","desc":"Lihat riwayat clan war","usage":".clanwarhistory"})
