// cr: haimiya md saca
// fitur tambahan Haimiya MD (zombie/zombie-beli)
module.exports = require('../../lib/adapter/e9.js').plugin("zombie/zombie-beli", {"command":["zombie-beli"],"category":"rpg","desc":"Toko perlengkapan","usage":".zombie-beli"})
