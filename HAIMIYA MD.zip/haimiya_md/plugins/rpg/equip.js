// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/equip)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/equip", {"command":["equip"],"category":"rpg","desc":"Fitur equip","usage":".equip"})
