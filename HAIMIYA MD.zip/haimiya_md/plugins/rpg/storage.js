// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/storage)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/storage", {"command":["storage"],"category":"rpg","desc":"Fitur storage","usage":".storage"})
