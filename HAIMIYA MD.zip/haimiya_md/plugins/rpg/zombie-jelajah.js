// cr: haimiya md saca
// fitur tambahan Haimiya MD (zombie/zombie-jelajah)
module.exports = require('../../lib/adapter/e9.js').plugin("zombie/zombie-jelajah", {"command":["zombie-jelajah"],"category":"rpg","desc":"Jelajah Reruntuhan","usage":".zombie-jelajah"})
