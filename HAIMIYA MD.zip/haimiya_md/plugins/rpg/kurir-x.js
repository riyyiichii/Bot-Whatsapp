// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/kurir)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/kurir", {"command":["kurir"],"category":"rpg","desc":"Nganter paket orang, awas anjing galak!","usage":".kurir"})
