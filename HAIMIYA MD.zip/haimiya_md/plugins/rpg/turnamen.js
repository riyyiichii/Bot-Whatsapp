// cr: haimiya md saca
// fitur tambahan Haimiya MD (clan/turnamen)
module.exports = require('../../lib/adapter/e9.js').plugin("clan/turnamen", {"command":["turnamen"],"category":"rpg","desc":"Fitur turnamen","usage":".turnamen"})
