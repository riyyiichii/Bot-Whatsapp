// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/party)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/party", {"command":["party"],"category":"rpg","desc":"Fitur party","usage":".party"})
