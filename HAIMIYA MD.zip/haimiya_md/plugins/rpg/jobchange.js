// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/jobchange)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/jobchange", {"command":["jobchange"],"category":"rpg","desc":"Fitur jobchange","usage":".jobchange"})
