// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/codex)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/codex", {"command":["codex"],"category":"rpg","desc":"Fitur codex","usage":".codex"})
