// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/alchemy)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/alchemy", {"command":["alchemy"],"category":"rpg","desc":"Buat potion dan ramuan dari herba","usage":".alchemy"})
