// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/learnskill)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/learnskill", {"command":["learnskill"],"category":"rpg","desc":"Fitur learnskill","usage":".learnskill"})
