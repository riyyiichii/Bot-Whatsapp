// cr: haimiya md saca
// fitur tambahan Haimiya MD (clan/clanannounce)
module.exports = require('../../lib/adapter/e9.js').plugin("clan/clanannounce", {"command":["clanannounce"],"category":"rpg","desc":"Kirim pengumuman ke semua member clan","usage":".clanannounce"})
