// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/mutate)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/mutate", {"command":["mutate"],"category":"rpg","desc":"Fitur mutate","usage":".mutate"})
