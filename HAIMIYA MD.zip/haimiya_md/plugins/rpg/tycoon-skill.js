// cr: haimiya md saca
// fitur tambahan Haimiya MD (tycoon/tycoon-skill)
module.exports = require('../../lib/adapter/e9.js').plugin("tycoon/tycoon-skill", {"command":["tycoon-skill"],"category":"rpg","desc":"Lihat/upgrade skill","usage":".tycoon-skill"})
