// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/jual)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/jual", {"command":["jual"],"category":"rpg","desc":"Fitur jual <item> <jumlah>","usage":".jual"})
