// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/build)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/build", {"command":["build"],"category":"rpg","desc":"Fitur build","usage":".build"})
