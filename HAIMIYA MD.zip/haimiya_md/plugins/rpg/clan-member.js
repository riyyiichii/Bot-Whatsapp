// cr: haimiya md saca
// fitur tambahan Haimiya MD (clan/clan-member)
module.exports = require('../../lib/adapter/e9.js').plugin("clan/clan-member", {"command":["clan-member"],"category":"rpg","desc":"Daftar anggota clan: .clan-member <nama>","usage":".clan-member","group":true})
