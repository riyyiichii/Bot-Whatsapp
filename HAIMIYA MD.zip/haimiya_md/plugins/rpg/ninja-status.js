// cr: haimiya md saca
// fitur tambahan Haimiya MD (ninja/ninja-status)
module.exports = require('../../lib/adapter/e9.js').plugin("ninja/ninja-status", {"command":["ninja-status"],"category":"rpg","desc":"Kartu pemain","usage":".ninja-status"})
