// cr: haimiya md saca
// fitur tambahan Haimiya MD (koboy/koboy-help)
module.exports = require('../../lib/adapter/e9.js').plugin("koboy/koboy-help", {"command":["koboy-help"],"category":"rpg","desc":"Fitur koboy-help","usage":".koboy-help"})
