// cr: haimiya md saca
// fitur tambahan Haimiya MD (clan/clanjoinraid)
module.exports = require('../../lib/adapter/e9.js').plugin("clan/clanjoinraid", {"command":["clanjoinraid"],"category":"rpg","desc":"Join raid clan dan kill monster","usage":".clanjoinraid"})
