// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/divorce)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/divorce", {"command":["divorce"],"category":"rpg","desc":"Bercerai dari pasangan","usage":".divorce"})
