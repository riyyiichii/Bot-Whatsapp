// cr: haimiya md saca
// fitur tambahan Haimiya MD (clan/clanwaraccept)
module.exports = require('../../lib/adapter/e9.js').plugin("clan/clanwaraccept", {"command":["clanwaraccept"],"category":"rpg","desc":"Terima tantangan clan war","usage":".clanwaraccept"})
