// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/puzzle)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/puzzle", {"command":["puzzle"],"category":"rpg","desc":"Fitur puzzle","usage":".puzzle"})
