// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/pet)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/pet", {"command":["pet"],"category":"rpg","desc":"Kelola pet/hewan peliharaan","usage":".pet"})
