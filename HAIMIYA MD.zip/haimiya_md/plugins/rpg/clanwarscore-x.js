// cr: haimiya md saca
// fitur tambahan Haimiya MD (clan/clanwarscore)
module.exports = require('../../lib/adapter/e9.js').plugin("clan/clanwarscore", {"command":["clanwarscore"],"category":"rpg","desc":"Lihat skor clan war","usage":".clanwarscore"})
