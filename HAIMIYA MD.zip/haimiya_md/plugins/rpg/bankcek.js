// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/bankcek)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/bankcek", {"command":["bankcek"],"category":"rpg","desc":"Fitur bankcek","usage":".bankcek","group":true})
