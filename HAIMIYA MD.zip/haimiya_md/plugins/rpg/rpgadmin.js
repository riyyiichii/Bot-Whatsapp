// cr: haimiya md saca
// fitur tambahan Haimiya MD (economy/rpgadmin)
module.exports = require('../../lib/adapter/e9.js').plugin("economy/rpgadmin", {"command":["rpgadmin","resetmoney","setlimit","setmoney"],"category":"rpg","desc":"Fitur rpgadmin addlimit <user> <jumlah>","usage":".rpgadmin","owner":true})
