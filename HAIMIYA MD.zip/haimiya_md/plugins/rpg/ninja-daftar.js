// cr: haimiya md saca
// fitur tambahan Haimiya MD (ninja/ninja-daftar)
module.exports = require('../../lib/adapter/e9.js').plugin("ninja/ninja-daftar", {"command":["ninja-daftar"],"category":"rpg","desc":"Daftar & pilih peran","usage":".ninja-daftar"})
