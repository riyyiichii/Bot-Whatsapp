// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/rpg-reward)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/rpg-reward", {"command":["rpg-reward","harian","claim","mingguan","weekly","monthly","bulanan"],"category":"rpg","desc":"Fitur rpg-reward daily","usage":".rpg-reward"})
