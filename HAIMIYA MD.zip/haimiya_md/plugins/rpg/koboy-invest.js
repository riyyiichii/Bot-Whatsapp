// cr: haimiya md saca
// fitur tambahan Haimiya MD (koboy/koboy-invest)
module.exports = require('../../lib/adapter/e9.js').plugin("koboy/koboy-invest", {"command":["koboy-invest"],"category":"rpg","desc":"Fitur koboy-invest","usage":".koboy-invest"})
