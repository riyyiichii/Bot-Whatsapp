// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/defend)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/defend", {"command":["defend"],"category":"rpg","desc":"Fitur defend","usage":".defend"})
