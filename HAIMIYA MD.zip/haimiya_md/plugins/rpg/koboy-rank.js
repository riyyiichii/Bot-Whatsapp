// cr: haimiya md saca
// fitur tambahan Haimiya MD (koboy/koboy-rank)
module.exports = require('../../lib/adapter/e9.js').plugin("koboy/koboy-rank", {"command":["koboy-rank"],"category":"rpg","desc":"Fitur koboy-rank","usage":".koboy-rank"})
