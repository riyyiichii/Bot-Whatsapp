// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/bossfight)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/bossfight", {"command":["bossfight"],"category":"rpg","desc":"Fitur bossfight","usage":".bossfight"})
