// cr: haimiya md saca
// fitur tambahan Haimiya MD (koboy/koboy-equip)
module.exports = require('../../lib/adapter/e9.js').plugin("koboy/koboy-equip", {"command":["koboy-equip"],"category":"rpg","desc":"Fitur koboy-equip","usage":".koboy-equip"})
