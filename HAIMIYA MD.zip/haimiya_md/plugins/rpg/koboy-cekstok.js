// cr: haimiya md saca
// fitur tambahan Haimiya MD (koboy/koboy-cekstok)
module.exports = require('../../lib/adapter/e9.js').plugin("koboy/koboy-cekstok", {"command":["koboy-cekstok"],"category":"rpg","desc":"Fitur koboy-cekstok","usage":".koboy-cekstok"})
