// cr: haimiya md saca
// fitur tambahan Haimiya MD (clan/clan-create)
module.exports = require('../../lib/adapter/e9.js').plugin("clan/clan-create", {"command":["clan-create"],"category":"rpg","desc":"Buat clan: .clan-create <nama>","usage":".clan-create","group":true})
