// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/berladang)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/berladang", {"command":["berladang"],"category":"rpg","desc":"Berladang untuk mendapat hasil panen","usage":".berladang"})
