// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/ngamen)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/ngamen", {"command":["ngamen"],"category":"rpg","desc":"Ngamen di jalanan untuk mencari koin","usage":".ngamen"})
