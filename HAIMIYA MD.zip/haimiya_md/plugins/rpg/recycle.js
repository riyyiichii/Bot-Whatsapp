// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/recycle)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/recycle", {"command":["recycle"],"category":"rpg","desc":"Fitur recycle","usage":".recycle"})
