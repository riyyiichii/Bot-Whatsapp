// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/grab)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/grab", {"command":["grab"],"category":"rpg","desc":"Fitur grab","usage":".grab"})
