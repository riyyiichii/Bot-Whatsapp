// cr: haimiya md saca
// fitur tambahan Haimiya MD (clan/clandesc)
module.exports = require('../../lib/adapter/e9.js').plugin("clan/clandesc", {"command":["clandesc"],"category":"rpg","desc":"Edit deskripsi clan","usage":".clandesc"})
