// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/scout)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/scout", {"command":["scout"],"category":"rpg","desc":"Fitur scout","usage":".scout"})
