// cr: haimiya md saca
// fitur tambahan Haimiya MD (zombie/zombie-peran)
module.exports = require('../../lib/adapter/e9.js').plugin("zombie/zombie-peran", {"command":["zombie-peran"],"category":"rpg","desc":"Daftar/ganti peran","usage":".zombie-peran"})
