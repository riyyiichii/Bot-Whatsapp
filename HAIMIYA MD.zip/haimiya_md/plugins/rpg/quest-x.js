// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/quest)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/quest", {"command":["quest"],"category":"rpg","desc":"Misi harian (kumpulkan item)","usage":".quest"})
