// cr: haimiya md saca
// fitur tambahan Haimiya MD (tycoon/tycoon-pindah)
module.exports = require('../../lib/adapter/e9.js').plugin("tycoon/tycoon-pindah", {"command":["tycoon-pindah"],"category":"rpg","desc":"Pindah lokasi","usage":".tycoon-pindah"})
