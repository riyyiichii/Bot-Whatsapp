// cr: haimiya md saca
// economy/xp-ceksn — satu file: metadata + kode fitur (gabungan dari engine2/plugins/economy/xp-ceksn.js)
const __hm = require("../../lib/adapter/e2.js")
const __meta = {
  "command": [
    "ceksn"
  ],
  "category": "rpg",
  "owner": false,
  "group": false,
  "admin": false,
  "botAdmin": false,
  "desc": "Fitur ceksn (dari Haimiya-pack)"
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/economy").split('\\').join('/')
module.exports = __hm.plugin("economy/xp-ceksn", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/xp-ceksn.js'
  const __hmExports = {};
  const { createHash } = require("crypto");
  
  let handler = async function (m) {
  	let sn = createHash('md5').update(m.sender).digest('hex');
  	m.reply(`*SN:* ${sn}`);
  };
  
  handler.help = ['ceksn'];
  handler.tags = ['xp'];
  handler.command = /^(ceksn)$/i;
  handler.register = true;
  const __hmDefault = handler;
  
  Object.defineProperty(__hmExports, "default", { enumerable: true, get: () => __hmDefault });
  return __hmExports
})
