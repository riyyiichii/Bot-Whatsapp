// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/rpg-rank)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/rpg-rank", {"command":["rpg-rank"],"category":"rpg","desc":"Fitur rpg-rank","usage":".rpg-rank","group":true})
