// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/gacha)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/gacha", {"command":["gacha","jambahagia","happyhour"],"category":"rpg","desc":"Fitur gacha","usage":".gacha"})
