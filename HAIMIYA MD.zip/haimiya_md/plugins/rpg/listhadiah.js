// cr: haimiya md saca
// fitur tambahan Haimiya MD (economy/listhadiah)
module.exports = require('../../lib/adapter/e9.js').plugin("economy/listhadiah", {"command":["listhadiah"],"category":"rpg","desc":"Lihat daftar code hadiah (owner)","usage":".listhadiah","owner":true})
