// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/mailbox)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/mailbox", {"command":["mailbox"],"category":"rpg","desc":"Fitur mailbox","usage":".mailbox"})
