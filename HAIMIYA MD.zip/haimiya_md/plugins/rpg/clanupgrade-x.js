// cr: haimiya md saca
// fitur tambahan Haimiya MD (clan/clanupgrade)
module.exports = require('../../lib/adapter/e9.js').plugin("clan/clanupgrade", {"command":["clanupgrade"],"category":"rpg","desc":"Upgrade level clan menggunakan kas clan","usage":".clanupgrade"})
