// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/stat)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/stat", {"command":["stat"],"category":"rpg","desc":"Fitur stat","usage":".stat"})
