// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/upgrade)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/upgrade", {"command":["upgrade"],"category":"rpg","desc":"Fitur upgrade","usage":".upgrade"})
