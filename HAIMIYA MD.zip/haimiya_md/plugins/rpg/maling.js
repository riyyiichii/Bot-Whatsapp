// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/maling)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/maling", {"command":["maling"],"category":"rpg","desc":"Mencopet orang di pasar (lebih berisiko dari crime)","usage":".maling"})
