// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/marketplace)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/marketplace", {"command":["marketplace","7eleven","foodshop","marketstall","buyfood"],"category":"rpg","desc":"Fitur marketplace 7eleven","usage":".marketplace"})
