// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/ramuan)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/ramuan", {"command":["ramuan"],"category":"rpg","desc":"Fitur ramuan","usage":".ramuan","group":true})
