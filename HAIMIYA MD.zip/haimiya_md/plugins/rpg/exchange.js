// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/exchange)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/exchange", {"command":["exchange"],"category":"rpg","desc":"Fitur exchange","usage":".exchange"})
