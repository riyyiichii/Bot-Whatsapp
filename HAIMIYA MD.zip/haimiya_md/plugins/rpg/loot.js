// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/loot)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/loot", {"command":["loot"],"category":"rpg","desc":"Fitur loot","usage":".loot"})
