// cr: haimiya md saca
// fitur tambahan Haimiya MD (ninja/ninja-intai)
module.exports = require('../../lib/adapter/e9.js').plugin("ninja/ninja-intai", {"command":["ninja-intai"],"category":"rpg","desc":"Misi Mata-Mata","usage":".ninja-intai"})
