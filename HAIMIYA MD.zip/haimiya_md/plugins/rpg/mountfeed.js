// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/mountfeed)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/mountfeed", {"command":["mountfeed"],"category":"rpg","desc":"Fitur mountfeed","usage":".mountfeed"})
