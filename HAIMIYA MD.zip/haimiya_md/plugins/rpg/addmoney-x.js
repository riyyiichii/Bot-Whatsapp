// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/addmoney)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/addmoney", {"command":["addmoney"],"category":"rpg","desc":"Fitur addmoney","usage":".addmoney"})
