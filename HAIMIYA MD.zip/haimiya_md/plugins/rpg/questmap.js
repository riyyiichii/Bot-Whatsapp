// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/questmap)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/questmap", {"command":["questmap"],"category":"rpg","desc":"Fitur questmap","usage":".questmap"})
