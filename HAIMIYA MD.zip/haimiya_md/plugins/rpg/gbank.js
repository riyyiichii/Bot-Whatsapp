// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/gbank)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/gbank", {"command":["gbank"],"category":"rpg","desc":"Fitur gbank","usage":".gbank"})
