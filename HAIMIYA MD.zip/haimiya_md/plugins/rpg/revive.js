// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/revive)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/revive", {"command":["revive"],"category":"rpg","desc":"Fitur revive","usage":".revive"})
