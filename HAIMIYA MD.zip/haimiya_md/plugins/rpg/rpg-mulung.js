// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/rpg-mulung)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/rpg-mulung", {"command":["rpg-mulung"],"category":"rpg","desc":"Fitur rpg-mulung","usage":".rpg-mulung","group":true})
