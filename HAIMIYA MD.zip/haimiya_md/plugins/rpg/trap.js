// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/trap)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/trap", {"command":["trap"],"category":"rpg","desc":"Fitur trap","usage":".trap"})
