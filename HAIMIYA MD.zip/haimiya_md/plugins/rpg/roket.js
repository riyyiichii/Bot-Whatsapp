// cr: haimiya md saca
// rpg/roket — satu file: metadata + kode fitur (gabungan dari engine7/plugins/rpg/roket.js)
const __hm = require("../../lib/adapter/e7.js")
const __meta = {
  "name": "roket",
  "command": [
    "roket",
    "ngroket",
    "groket",
    "jadiroket"
  ],
  "category": "rpg",
  "desc": "Imported from Haimiya MD V4.6",
  "usage": "",
  "owner": false,
  "group": true,
  "private": false,
  "premium": false,
  "cooldown": 3,
  "energi": 1,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/rpg").split('\\').join('/')
module.exports = __hm.plugin("rpg/roket", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/roket.js'
  const __hmExports = {};
  const FEATURE_CREDIT = "Fitur By: Haimiya MD\nFitur SC Bot Haimiya MD 👑";
  
  
  const pluginConfig = {
    name: "roket",
    alias: ["ngroket", "groket", "jadiroket"],
    category: "rpg",
    description: "Imported from Haimiya MD V4.6",
    usage: "",
    example: "",
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    cooldown: 3,
    energi: 1,
    isEnabled: true,
  };
  
  async function handler(m, { sock, prefix }) {
      const conn = sock;
      const usedPrefix = prefix || m.prefix || ".";
      let __timers = (new Date - global.db.data.users[m.sender].lastmisi)
      let _timers = (3600000 - __timers)
      let user = global.db.data.users[m.sender]
      let order = global.db.data.users[m.sender].rokets
      let timers = clockString(_timers)
      let name = user.registered ? user.name: conn.getName(m.sender)
      let id = m.sender
      let kerja = 'Roket'
      conn.misi = conn.misi ? conn.misi: {}
      if (id in conn.misi) {
          conn.reply(m.chat, `Selesaikan Misi ${conn.misi[id][0]} Terlebih Dahulu`, m)
          throw false
      }
      if (user.health < 80) return m.reply(`Anda Harus Memiliki Minimal 80Health`)
      if (new Date - global.db.data.users[m.sender].lastmisi > 3600000) {
          let ngerok4 = Math.floor(Math.random() * 10)
          let ngerok5 = Math.floor(Math.random() * 10)
  
          let ngrk4 = (ngerok4 * 100000)
          let ngrk5 = (ngerok5 * 1000)
  
          let rokit = `🌕
  
  
  ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
  ▒▒▄▄▄▒▒▒█▒▒▒▒▄▒▒▒▒▒▒▒▒
  ▒█▀█▀█▒█▀█▒▒█▀█▒▄███▄▒
  ░█▀█▀█░█▀██░█▀█░█▄█▄█░
  ░█▀█▀█░█▀████▀█░█▄█▄█░
  ████████▀█████████████
  🚀
  
  👨‍🚀 Memulai penerbangan....
  `.trim()
  
          let rokit2 = `🌕
  
  
  🚀
  ▒▒▄▄▄▒▒▒█▒▒▒▒▄▒▒▒▒▒▒▒▒
  ▒█▀█▀█▒█▀█▒▒█▀█▒▄███▄▒
  ░█▀█▀█░█▀██░█▀█░█▄█▄█░
  ░█▀█▀█░█▀████▀█░█▄█▄█░
  ████████▀█████████████
  
  ➕ Dalam penerbangan....
  `.trim()
  
          let rokit3 = `🌕🚀
  
  
  ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
  ▒▒▄▄▄▒▒▒█▒▒▒▒▄▒▒▒▒▒▒▒▒
  ▒█▀█▀█▒█▀█▒▒█▀█▒▄███▄▒
  ░█▀█▀█░█▀██░█▀█░█▄█▄█░
  ░█▀█▀█░█▀████▀█░█▄█▄█░
  ████████▀█████████████
  
  ➕ Sampai di tujuan....
  `.trim()
  
          let rokit4 = `🌕🚀
  
  ➕ Sukses Mendarat.... 👨‍🚀
  `.trim()
  
          let hsl = `
  *—[ Hasil Ngroket ${name} ]—*
  ➕ 💹 Uang = [ ${ngrk4} ]
  ➕ ✨ Exp = [ ${ngrk5} ]
  ➕ 😍 Mendarat Selesai = +1
  ➕  📥Total Mendarat Sebelumnya : ${order}
  `.trim()
  
          user.money += ngrk4
          user.exp += ngrk5
          user.rokets += 1
          user.health -= 80
  
  		conn.misi[id] = [
              kerja,
              setTimeout(() => {
                  delete conn.misi[id]
              }, 27000)
          ]
          
          setTimeout(() => {
              conn.reply(m.chat, hsl, m)
          }, 27000)
  
          setTimeout(() => {
              conn.reply(m.chat, rokit4, m)
          }, 25000)
  
          setTimeout(() => {
              conn.reply(m.chat, rokit3, m)
          }, 20000)
  
          setTimeout(() => {
              conn.reply(m.chat, rokit2, m)
          }, 15000)
  
          setTimeout(() => {
              conn.reply(m.chat, rokit, m)
          }, 10000)
  
          setTimeout(() => {
              conn.reply(m.chat, `🔍 ${name} Mencari Lokasi.....`, m)
          }, 0)
          user.lastmisi = new Date * 1
      } else m.reply(`Silahkan Menunggu Selama ${timers}, Untuk Menyelesaikan Misi Kembali`)
  }
  handler.register = true
  handler.level = 10
  function clockString(ms) {
      let h = Math.floor(ms / 3600000)
      let m = Math.floor(ms / 60000) % 60
      let s = Math.floor(ms / 1000) % 60
      return [h, m, s].map(v => v.toString().padStart(2, 0)).join(':')
  }
  
  
  
  Object.defineProperty(__hmExports, "FEATURE_CREDIT", { enumerable: true, get: () => FEATURE_CREDIT });
  Object.defineProperty(__hmExports, "config", { enumerable: true, get: () => pluginConfig });
  Object.defineProperty(__hmExports, "handler", { enumerable: true, get: () => handler });
  return __hmExports
})
