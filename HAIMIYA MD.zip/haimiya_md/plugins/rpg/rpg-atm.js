// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/rpg-atm)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/rpg-atm", {"command":["rpg-atm"],"category":"rpg","desc":"Fitur rpg-atm","usage":".rpg-atm","group":true})
