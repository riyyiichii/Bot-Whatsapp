// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/rpg-market)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/rpg-market", {"command":["rpg-market","pasar","mjual","mbeli","mtarik","mku"],"category":"rpg","desc":"Fitur rpg-market market","usage":".rpg-market","group":true})
