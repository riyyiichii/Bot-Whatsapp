// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/cooking)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/cooking", {"command":["cooking"],"category":"rpg","desc":"Masak makanan untuk stamina dan HP","usage":".cooking"})
