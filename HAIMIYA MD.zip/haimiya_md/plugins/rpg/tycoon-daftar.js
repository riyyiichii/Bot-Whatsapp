// cr: haimiya md saca
// fitur tambahan Haimiya MD (tycoon/tycoon-daftar)
module.exports = require('../../lib/adapter/e9.js').plugin("tycoon/tycoon-daftar", {"command":["tycoon-daftar"],"category":"rpg","desc":"Daftar & pilih peran","usage":".tycoon-daftar"})
