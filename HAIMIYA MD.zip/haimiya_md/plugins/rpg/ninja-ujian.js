// cr: haimiya md saca
// fitur tambahan Haimiya MD (ninja/ninja-ujian)
module.exports = require('../../lib/adapter/e9.js').plugin("ninja/ninja-ujian", {"command":["ninja-ujian"],"category":"rpg","desc":"Ujian Kenaikan Pangkat","usage":".ninja-ujian"})
