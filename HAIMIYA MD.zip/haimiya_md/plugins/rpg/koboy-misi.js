// cr: haimiya md saca
// fitur tambahan Haimiya MD (koboy/koboy-misi)
module.exports = require('../../lib/adapter/e9.js').plugin("koboy/koboy-misi", {"command":["koboy-misi"],"category":"rpg","desc":"Fitur koboy-misi","usage":".koboy-misi"})
