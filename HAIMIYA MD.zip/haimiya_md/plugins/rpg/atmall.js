// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/atmall)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/atmall", {"command":["atmall"],"category":"rpg","desc":"Fitur atmall","usage":".atmall"})
