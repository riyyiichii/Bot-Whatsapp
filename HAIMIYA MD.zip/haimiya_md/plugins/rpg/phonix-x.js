// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/phonix)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/phonix", {"command":["phonix"],"category":"rpg","desc":"Fitur phonix","usage":".phonix","group":true})
