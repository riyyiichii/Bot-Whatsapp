// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/buff)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/buff", {"command":["buff"],"category":"rpg","desc":"Fitur buff","usage":".buff"})
