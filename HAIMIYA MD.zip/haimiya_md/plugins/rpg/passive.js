// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/passive)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/passive", {"command":["passive"],"category":"rpg","desc":"Fitur passive","usage":".passive"})
