// cr: haimiya md saca
// fitur tambahan Haimiya MD (koboy/koboy-kerja_berani)
module.exports = require('../../lib/adapter/e9.js').plugin("koboy/koboy-kerja_berani", {"command":["koboy-kerja_berani"],"category":"rpg","desc":"Fitur koboy-kerja_berani","usage":".koboy-kerja_berani"})
