// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/fightnaga)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/fightnaga", {"command":["fightnaga"],"category":"rpg","desc":"Fitur fightnaga","usage":".fightnaga","group":true})
