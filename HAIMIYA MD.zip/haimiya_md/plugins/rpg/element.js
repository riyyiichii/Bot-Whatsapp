// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/element)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/element", {"command":["element"],"category":"rpg","desc":"Fitur element","usage":".element"})
