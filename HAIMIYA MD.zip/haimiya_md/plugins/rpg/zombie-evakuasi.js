// cr: haimiya md saca
// fitur tambahan Haimiya MD (zombie/zombie-evakuasi)
module.exports = require('../../lib/adapter/e9.js').plugin("zombie/zombie-evakuasi", {"command":["zombie-evakuasi"],"category":"rpg","desc":"Misi Evakuasi","usage":".zombie-evakuasi"})
