// cr: haimiya md saca
// fitur tambahan Haimiya MD (zombie/zombie-skill)
module.exports = require('../../lib/adapter/e9.js').plugin("zombie/zombie-skill", {"command":["zombie-skill"],"category":"rpg","desc":"Lihat/upgrade skill","usage":".zombie-skill"})
