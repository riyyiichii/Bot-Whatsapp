// cr: haimiya md saca
// fitur tambahan Haimiya MD (clan/clanboss)
module.exports = require('../../lib/adapter/e9.js').plugin("clan/clanboss", {"command":["clanboss"],"category":"rpg","desc":"Fight boss clan untuk dapet XP dan reward","usage":".clanboss"})
