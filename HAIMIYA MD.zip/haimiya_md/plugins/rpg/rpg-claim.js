// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/rpg-claim)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/rpg-claim", {"command":["rpg-claim"],"category":"rpg","desc":"Fitur claim","usage":".rpg-claim","group":true})
