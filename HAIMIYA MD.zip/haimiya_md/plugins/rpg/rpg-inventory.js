// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/rpg-inventory)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/rpg-inventory", {"command":["rpg-inventory"],"category":"rpg","desc":"Fitur rpg-inventory","usage":".rpg-inventory","group":true})
