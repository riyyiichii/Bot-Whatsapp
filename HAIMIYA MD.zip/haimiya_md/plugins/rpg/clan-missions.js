// cr: haimiya md saca
// fitur tambahan Haimiya MD (clan/clan-missions)
module.exports = require('../../lib/adapter/e9.js').plugin("clan/clan-missions", {"command":["clan-missions"],"category":"rpg","desc":"Misi harian & mingguan clan","usage":".clan-missions","group":true})
