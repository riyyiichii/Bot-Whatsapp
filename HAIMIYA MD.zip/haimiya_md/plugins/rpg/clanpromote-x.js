// cr: haimiya md saca
// fitur tambahan Haimiya MD (clan/clanpromote)
module.exports = require('../../lib/adapter/e9.js').plugin("clan/clanpromote", {"command":["clanpromote"],"category":"rpg","desc":"Naikkan jabatan member (Co-Leader/Elder)","usage":".clanpromote","group":true})
