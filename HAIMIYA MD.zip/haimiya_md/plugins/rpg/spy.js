// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/spy)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/spy", {"command":["spy"],"category":"rpg","desc":"Fitur spy","usage":".spy"})
