// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/invasion)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/invasion", {"command":["invasion"],"category":"rpg","desc":"Fitur invasion","usage":".invasion"})
