// cr: haimiya md saca
// fitur tambahan Haimiya MD (relationship/couple-tabungan)
module.exports = require('../../lib/adapter/e9.js').plugin("relationship/couple-tabungan", {"command":["couple-tabungan","nabung","tabungan","tariktabungan","setujutarik","tolaktarik"],"category":"rpg","desc":"Fitur couple-tabungan nabung","usage":".couple-tabungan","group":true})
