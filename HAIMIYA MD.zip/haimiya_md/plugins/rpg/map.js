// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/map)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/map", {"command":["map"],"category":"rpg","desc":"Fitur map","usage":".map"})
