// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/rpg-adventure)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/rpg-adventure", {"command":["rpg-adventure"],"category":"rpg","desc":"Fitur rpg-adventure","usage":".rpg-adventure","group":true})
