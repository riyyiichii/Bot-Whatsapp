// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/elementatk)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/elementatk", {"command":["elementatk"],"category":"rpg","desc":"Fitur elementatk","usage":".elementatk"})
