// cr: haimiya md saca
// fitur tambahan Haimiya MD (clan/clan-leave)
module.exports = require('../../lib/adapter/e9.js').plugin("clan/clan-leave", {"command":["clan-leave"],"category":"rpg","desc":"Keluar dari clan","usage":".clan-leave","group":true})
