// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/buykoin)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/buykoin", {"command":["buykoin"],"category":"rpg","desc":"Tukar EXP menjadi Koin","usage":".buykoin"})
