// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/narrator)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/narrator", {"command":["narrator"],"category":"rpg","desc":"Fitur narrator","usage":".narrator"})
