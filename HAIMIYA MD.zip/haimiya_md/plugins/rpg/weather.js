// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/weather)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/weather", {"command":["weather"],"category":"rpg","desc":"Fitur weather","usage":".weather"})
