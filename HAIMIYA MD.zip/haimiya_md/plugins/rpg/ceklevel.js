// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/ceklevel)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/ceklevel", {"command":["ceklevel"],"category":"rpg","desc":"Fitur ceklevel","usage":".ceklevel"})
