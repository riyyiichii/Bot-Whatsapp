// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/rpg-lbmingguan)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/rpg-lbmingguan", {"command":["rpg-lbmingguan"],"category":"rpg","desc":"Fitur rpg-lbmingguan","usage":".rpg-lbmingguan"})
