// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/whereami)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/whereami", {"command":["whereami"],"category":"rpg","desc":"Fitur whereami","usage":".whereami"})
