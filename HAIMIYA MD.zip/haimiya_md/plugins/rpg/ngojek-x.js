// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/ngojek)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/ngojek", {"command":["ngojek"],"category":"rpg","desc":"Ngojek untuk mendapat uang","usage":".ngojek"})
