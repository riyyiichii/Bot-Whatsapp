// cr: haimiya md saca
// fitur tambahan Haimiya MD (clan/clan-war)
module.exports = require('../../lib/adapter/e9.js').plugin("clan/clan-war", {"command":["clan-war"],"category":"rpg","desc":"Mulai war melawan clan acak","usage":".clan-war","group":true})
