// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/misi)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/misi", {"command":["misi"],"category":"rpg","desc":"Fitur misi","usage":".misi"})
