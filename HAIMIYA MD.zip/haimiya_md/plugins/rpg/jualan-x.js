// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/jualan)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/jualan", {"command":["jualan"],"category":"rpg","desc":"Dagang asongan keliling","usage":".jualan"})
