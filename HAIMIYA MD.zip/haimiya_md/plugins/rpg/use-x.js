// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/use)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/use", {"command":["use"],"category":"rpg","desc":"Menggunakan item consumable atau membuka crate","usage":".use"})
