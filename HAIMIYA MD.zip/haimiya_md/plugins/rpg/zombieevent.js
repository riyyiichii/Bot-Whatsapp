// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/zombieevent)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/zombieevent", {"command":["zombieevent"],"category":"rpg","desc":"Fitur zombieevent","usage":".zombieevent"})
