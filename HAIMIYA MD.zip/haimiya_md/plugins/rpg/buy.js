// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/buy)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/buy", {"command":["buy"],"category":"rpg","desc":"Beli item dari toko","usage":".buy"})
