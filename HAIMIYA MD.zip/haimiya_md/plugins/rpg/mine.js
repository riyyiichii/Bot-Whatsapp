// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/mine)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/mine", {"command":["mine"],"category":"rpg","desc":"Fitur mine","usage":".mine"})
