// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/marry)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/marry", {"command":["marry"],"category":"rpg","desc":"Menikahi player lain","usage":".marry","group":true})
