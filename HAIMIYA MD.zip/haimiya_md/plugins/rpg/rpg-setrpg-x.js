// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/rpg-setrpg)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/rpg-setrpg", {"command":["rpg-setrpg"],"category":"rpg","desc":"Fitur rpg-setrpg","usage":".rpg-setrpg","group":true})
