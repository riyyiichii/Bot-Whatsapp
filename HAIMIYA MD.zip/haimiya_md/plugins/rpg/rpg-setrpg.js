// cr: haimiya md saca
// rpg/rpg-setrpg — satu file: metadata + kode fitur (gabungan dari engine2/plugins/rpg/rpg-setrpg.js)
const __hm = require("../../lib/adapter/e2.js")
const __meta = {
  "command": [
    "setrpg"
  ],
  "category": "rpg",
  "owner": false,
  "group": true,
  "admin": false,
  "botAdmin": false,
  "desc": "Fitur setrpg (dari Haimiya-pack)"
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/rpg").split('\\').join('/')
module.exports = __hm.plugin("rpg/rpg-setrpg", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/rpg-setrpg.js'
  const __hmExports = {};
  let handler = async (m,{conn,args})=>{
  
  let user = global.db.data.users[m.sender]
  
  let type = (args[0]||'').toLowerCase()
  
  if(type !== 'Haimiya MD')
  return conn.reply(m.chat,'Gunakan:\n.setrpg Haimiya MD',m)
  
  if(user.haimiya)
  return conn.reply(m.chat,'Kamu sudah menjadi Adventurer Haimiya MD',m)
  
  user.haimiya = true
  
  conn.reply(m.chat,`
  🌸 *Haimiya MD RPG* ❀
  
  Selamat datang Adventurer!
  
  Sekarang kamu bisa berburu monster dengan:
  .huntanya
  `,m)
  
  }
  
  handler.help = ['setrpg']
  handler.tags = ['rpg']
  handler.command = /^(setrpg)$/i
  handler.group = true
  
  const __hmDefault = handler
  Object.defineProperty(__hmExports, "default", { enumerable: true, get: () => __hmDefault });
  return __hmExports
})
