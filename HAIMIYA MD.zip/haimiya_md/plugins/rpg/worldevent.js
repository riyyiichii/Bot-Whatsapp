// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/worldevent)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/worldevent", {"command":["worldevent"],"category":"rpg","desc":"Fitur worldevent","usage":".worldevent"})
