// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/rpg-buyatm)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/rpg-buyatm", {"command":["rpg-buyatm"],"category":"rpg","desc":"Fitur rpg-buyatm","usage":".rpg-buyatm"})
