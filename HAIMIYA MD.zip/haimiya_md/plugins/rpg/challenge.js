// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/challenge)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/challenge", {"command":["challenge"],"category":"rpg","desc":"Daily challenge untuk hadiah spesial","usage":".challenge"})
