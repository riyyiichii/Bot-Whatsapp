// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/bansos)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/bansos", {"command":["bansos"],"category":"rpg","desc":"Fitur korupsi","usage":".bansos","group":true})
