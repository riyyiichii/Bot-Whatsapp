// cr: haimiya md saca
// fitur tambahan Haimiya MD (koboy/koboy-lepas)
module.exports = require('../../lib/adapter/e9.js').plugin("koboy/koboy-lepas", {"command":["koboy-lepas"],"category":"rpg","desc":"Fitur koboy-lepas","usage":".koboy-lepas"})
