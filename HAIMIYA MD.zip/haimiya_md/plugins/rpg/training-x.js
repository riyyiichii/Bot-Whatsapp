// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/training)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/training", {"command":["training"],"category":"rpg","desc":"Latihan untuk meningkatkan stats","usage":".training"})
