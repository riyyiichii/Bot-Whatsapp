// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/rpg-eat)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/rpg-eat", {"command":["rpg-eat"],"category":"rpg","desc":"Fitur rpg-eat","usage":".rpg-eat","group":true})
