// cr: haimiya md saca
// fitur tambahan Haimiya MD (tycoon/tycoon-top)
module.exports = require('../../lib/adapter/e9.js').plugin("tycoon/tycoon-top", {"command":["tycoon-top"],"category":"rpg","desc":"Ranking pemain","usage":".tycoon-top"})
