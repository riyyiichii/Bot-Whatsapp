// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/itemuse)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/itemuse", {"command":["itemuse"],"category":"rpg","desc":"Fitur itemuse","usage":".itemuse"})
