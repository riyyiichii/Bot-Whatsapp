// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/saham)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/saham", {"command":["saham","belisaham","beritasaham","jualsaham","portofolio"],"category":"rpg","desc":"Fitur saham","usage":".saham","group":true})
