// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/mount)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/mount", {"command":["mount"],"category":"rpg","desc":"Fitur mount","usage":".mount"})
