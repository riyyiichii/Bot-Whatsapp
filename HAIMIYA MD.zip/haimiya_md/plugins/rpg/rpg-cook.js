// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/rpg-cook)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/rpg-cook", {"command":["rpg-cook"],"category":"rpg","desc":"Fitur rpg-cook","usage":".rpg-cook","group":true})
