// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/rpg)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/rpg", {"command":["rpg"],"category":"rpg","desc":"Fitur dungeon","usage":".rpg","group":true})
