// cr: haimiya md saca
// fitur tambahan Haimiya MD (zombie/zombie-status)
module.exports = require('../../lib/adapter/e9.js').plugin("zombie/zombie-status", {"command":["zombie-status"],"category":"rpg","desc":"Kartu pemain","usage":".zombie-status"})
