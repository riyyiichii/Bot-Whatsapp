// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/enchant)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/enchant", {"command":["enchant"],"category":"rpg","desc":"Upgrade equipment dengan enchantment","usage":".enchant"})
