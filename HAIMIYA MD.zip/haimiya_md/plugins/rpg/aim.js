// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/aim)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/aim", {"command":["aim"],"category":"rpg","desc":"Fitur aim","usage":".aim"})
