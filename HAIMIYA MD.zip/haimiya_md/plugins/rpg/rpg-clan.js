// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/rpg-clan)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/rpg-clan", {"command":["rpg-clan"],"category":"rpg","desc":"Fitur rpg-clan","usage":".rpg-clan","group":true})
