// cr: haimiya md saca
// fitur tambahan Haimiya MD (relationship/putuspasangan)
module.exports = require('../../lib/adapter/e9.js').plugin("relationship/putuspasangan", {"command":["putuspasangan"],"category":"rpg","desc":"Fitur putuspasangan","usage":".putuspasangan","owner":true})
