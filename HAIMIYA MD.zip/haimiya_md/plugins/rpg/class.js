// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/class)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/class", {"command":["class"],"category":"rpg","desc":"Fitur class","usage":".class"})
