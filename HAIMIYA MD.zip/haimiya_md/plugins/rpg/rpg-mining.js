// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/rpg-mining)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/rpg-mining", {"command":["rpg-mining"],"category":"rpg","desc":"Fitur rpg-mining","usage":".rpg-mining","group":true})
