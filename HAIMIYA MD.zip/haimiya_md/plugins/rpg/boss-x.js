// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/boss)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/boss", {"command":["boss"],"category":"rpg","desc":"Lawan boss untuk hadiah besar","usage":".boss"})
