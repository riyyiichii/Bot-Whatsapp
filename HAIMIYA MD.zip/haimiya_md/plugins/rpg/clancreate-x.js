// cr: haimiya md saca
// fitur tambahan Haimiya MD (clan/clancreate)
module.exports = require('../../lib/adapter/e9.js').plugin("clan/clancreate", {"command":["clancreate"],"category":"rpg","desc":"Buat clan baru","usage":".clancreate"})
