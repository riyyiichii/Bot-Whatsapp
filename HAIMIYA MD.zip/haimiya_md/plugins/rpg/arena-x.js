// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/arena)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/arena", {"command":["arena"],"category":"rpg","desc":"Bertarung di arena PvP","usage":".arena","group":true})
