// cr: haimiya md saca
// fitur tambahan Haimiya MD (clan/claninvite)
module.exports = require('../../lib/adapter/e9.js').plugin("clan/claninvite", {"command":["claninvite"],"category":"rpg","desc":"Invite & langsung tambahkan user ke clan","usage":".claninvite"})
