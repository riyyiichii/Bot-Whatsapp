// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/ward)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/ward", {"command":["ward"],"category":"rpg","desc":"Fitur ward","usage":".ward"})
