// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/prestige)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/prestige", {"command":["prestige"],"category":"rpg","desc":"Fitur prestige","usage":".prestige"})
