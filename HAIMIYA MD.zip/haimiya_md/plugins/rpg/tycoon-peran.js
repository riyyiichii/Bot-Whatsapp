// cr: haimiya md saca
// fitur tambahan Haimiya MD (tycoon/tycoon-peran)
module.exports = require('../../lib/adapter/e9.js').plugin("tycoon/tycoon-peran", {"command":["tycoon-peran"],"category":"rpg","desc":"Daftar/ganti peran","usage":".tycoon-peran"})
