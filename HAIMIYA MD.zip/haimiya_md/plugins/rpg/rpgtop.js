// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/rpgtop)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/rpgtop", {"command":["rpgtop"],"category":"rpg","desc":"Fitur rpgtop","usage":".rpgtop"})
