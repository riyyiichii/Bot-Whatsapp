// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/stashall)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/stashall", {"command":["stashall"],"category":"rpg","desc":"Fitur stashall","usage":".stashall"})
