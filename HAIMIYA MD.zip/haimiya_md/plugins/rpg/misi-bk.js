// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/misi-bk)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/misi-bk", {"command":["misi-bk"],"category":"rpg","desc":"Fitur misi","usage":".misi-bk","group":true})
