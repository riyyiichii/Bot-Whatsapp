// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/sawer)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/sawer", {"command":["sawer"],"category":"rpg","desc":"Fitur sawer","usage":".sawer","group":true})
