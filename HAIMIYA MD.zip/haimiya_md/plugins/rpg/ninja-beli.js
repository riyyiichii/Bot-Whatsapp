// cr: haimiya md saca
// fitur tambahan Haimiya MD (ninja/ninja-beli)
module.exports = require('../../lib/adapter/e9.js').plugin("ninja/ninja-beli", {"command":["ninja-beli"],"category":"rpg","desc":"Toko perlengkapan","usage":".ninja-beli"})
