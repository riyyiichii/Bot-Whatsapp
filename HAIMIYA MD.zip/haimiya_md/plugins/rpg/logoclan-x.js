// cr: haimiya md saca
// fitur tambahan Haimiya MD (clan/logoclan)
module.exports = require('../../lib/adapter/e9.js').plugin("clan/logoclan", {"command":["logoclan"],"category":"rpg","desc":"Set logo clan (reply gambar)","usage":".logoclan"})
