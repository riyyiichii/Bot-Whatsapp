// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/inv)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/inv", {"command":["inv"],"category":"rpg","desc":"Lihat inventory","usage":".inv"})
