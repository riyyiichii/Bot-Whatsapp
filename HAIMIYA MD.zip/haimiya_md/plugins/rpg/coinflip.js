// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/coinflip)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/coinflip", {"command":["coinflip"],"category":"rpg","desc":"Gambling coin flip","usage":".coinflip"})
