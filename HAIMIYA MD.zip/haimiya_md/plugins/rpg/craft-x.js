// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/craft)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/craft", {"command":["craft"],"category":"rpg","desc":"Craft armor (tulang + kulit)","usage":".craft"})
