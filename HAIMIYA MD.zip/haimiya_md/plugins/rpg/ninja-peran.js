// cr: haimiya md saca
// fitur tambahan Haimiya MD (ninja/ninja-peran)
module.exports = require('../../lib/adapter/e9.js').plugin("ninja/ninja-peran", {"command":["ninja-peran"],"category":"rpg","desc":"Daftar/ganti peran","usage":".ninja-peran"})
