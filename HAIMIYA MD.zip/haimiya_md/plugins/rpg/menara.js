// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/menara)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/menara", {"command":["menara","climb","menaratop","naiklantai","tower","towertop"],"category":"rpg","desc":"Fitur menara","usage":".menara","group":true})
