// cr: haimiya md saca
// fitur tambahan Haimiya MD (ninja/ninja-misi)
module.exports = require('../../lib/adapter/e9.js').plugin("ninja/ninja-misi", {"command":["ninja-misi"],"category":"rpg","desc":"Ambil Misi","usage":".ninja-misi"})
