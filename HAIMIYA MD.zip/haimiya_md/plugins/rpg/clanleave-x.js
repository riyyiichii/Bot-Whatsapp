// cr: haimiya md saca
// fitur tambahan Haimiya MD (clan/clanleave)
module.exports = require('../../lib/adapter/e9.js').plugin("clan/clanleave", {"command":["clanleave"],"category":"rpg","desc":"Keluar dari clan","usage":".clanleave"})
