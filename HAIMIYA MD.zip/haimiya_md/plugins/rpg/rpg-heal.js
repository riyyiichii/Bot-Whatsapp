// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/rpg-heal)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/rpg-heal", {"command":["rpg-heal"],"category":"rpg","desc":"Fitur rpg-heal","usage":".rpg-heal","group":true})
