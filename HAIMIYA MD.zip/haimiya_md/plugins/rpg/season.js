// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/season)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/season", {"command":["season"],"category":"rpg","desc":"Fitur season","usage":".season"})
