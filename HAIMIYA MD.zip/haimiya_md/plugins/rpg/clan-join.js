// cr: haimiya md saca
// fitur tambahan Haimiya MD (clan/clan-join)
module.exports = require('../../lib/adapter/e9.js').plugin("clan/clan-join", {"command":["clan-join"],"category":"rpg","desc":"Minta bergabung ke clan: .clan-join <nama>","usage":".clan-join","group":true})
