// cr: haimiya md saca
// fitur tambahan Haimiya MD (koboy/koboy-daftar)
module.exports = require('../../lib/adapter/e9.js').plugin("koboy/koboy-daftar", {"command":["koboy-daftar"],"category":"rpg","desc":"Fitur koboy-daftar","usage":".koboy-daftar"})
