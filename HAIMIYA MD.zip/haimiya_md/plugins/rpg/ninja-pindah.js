// cr: haimiya md saca
// fitur tambahan Haimiya MD (ninja/ninja-pindah)
module.exports = require('../../lib/adapter/e9.js').plugin("ninja/ninja-pindah", {"command":["ninja-pindah"],"category":"rpg","desc":"Pindah lokasi","usage":".ninja-pindah"})
