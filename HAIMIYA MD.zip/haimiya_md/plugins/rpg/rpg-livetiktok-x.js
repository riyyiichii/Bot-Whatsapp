// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/rpg-livetiktok)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/rpg-livetiktok", {"command":["rpg-livetiktok"],"category":"rpg","desc":"Fitur rpg-livetiktok","usage":".rpg-livetiktok"})
