// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/hero)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/hero", {"command":["hero"],"category":"rpg","desc":"Fitur hero","usage":".hero"})
