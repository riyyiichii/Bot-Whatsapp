// cr: haimiya md saca
// fitur tambahan Haimiya MD (clan/clan-list)
module.exports = require('../../lib/adapter/e9.js').plugin("clan/clan-list", {"command":["clan-list"],"category":"rpg","desc":"Daftar semua clan","usage":".clan-list","group":true})
