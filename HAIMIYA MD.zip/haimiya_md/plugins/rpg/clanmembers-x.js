// cr: haimiya md saca
// fitur tambahan Haimiya MD (clan/clanmembers)
module.exports = require('../../lib/adapter/e9.js').plugin("clan/clanmembers", {"command":["clanmembers"],"category":"rpg","desc":"Lihat daftar member clan","usage":".clanmembers"})
