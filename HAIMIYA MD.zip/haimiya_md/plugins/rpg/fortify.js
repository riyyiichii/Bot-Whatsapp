// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/fortify)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/fortify", {"command":["fortify"],"category":"rpg","desc":"Fitur fortify","usage":".fortify"})
