// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/reedem)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/reedem", {"command":["reedem"],"category":"rpg","desc":"Fitur reedem <kode>","usage":".reedem"})
