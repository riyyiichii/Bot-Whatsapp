// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/sell)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/sell", {"command":["sell"],"category":"rpg","desc":"Jual item ke sistem","usage":".sell"})
