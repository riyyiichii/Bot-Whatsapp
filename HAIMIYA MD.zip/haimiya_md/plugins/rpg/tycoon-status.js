// cr: haimiya md saca
// fitur tambahan Haimiya MD (tycoon/tycoon-status)
module.exports = require('../../lib/adapter/e9.js').plugin("tycoon/tycoon-status", {"command":["tycoon-status"],"category":"rpg","desc":"Kartu pemain","usage":".tycoon-status"})
