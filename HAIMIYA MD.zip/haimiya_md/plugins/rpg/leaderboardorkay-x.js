// cr: haimiya md saca
// fitur tambahan Haimiya MD (economy/leaderboardorkay)
module.exports = require('../../lib/adapter/e9.js').plugin("economy/leaderboardorkay", {"command":["leaderboardorkay"],"category":"rpg","desc":"Ranking orang paling kaya ala Haimiya AI dengan dashboard keren 💰🔥","usage":".leaderboardorkay","group":true})
