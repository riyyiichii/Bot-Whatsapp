// cr: haimiya md saca
// fitur tambahan Haimiya MD (clan/clanrename)
module.exports = require('../../lib/adapter/e9.js').plugin("clan/clanrename", {"command":["clanrename"],"category":"rpg","desc":"Ganti nama clan","usage":".clanrename"})
