// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/summon)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/summon", {"command":["summon"],"category":"rpg","desc":"Fitur summon","usage":".summon"})
