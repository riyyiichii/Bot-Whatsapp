// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/meditation)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/meditation", {"command":["meditation"],"category":"rpg","desc":"Istirahat untuk pulihkan HP dan stamina","usage":".meditation"})
