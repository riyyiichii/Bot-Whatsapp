// cr: haimiya md saca
// fitur tambahan Haimiya MD (clan/clan-task)
module.exports = require('../../lib/adapter/e9.js').plugin("clan/clan-task", {"command":["clan-task"],"category":"rpg","desc":"Task clan","usage":".clan-task","group":true})
