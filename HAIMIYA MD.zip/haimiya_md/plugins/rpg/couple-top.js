// cr: haimiya md saca
// fitur tambahan Haimiya MD (relationship/couple-top)
module.exports = require('../../lib/adapter/e9.js').plugin("relationship/couple-top", {"command":["couple-top"],"category":"rpg","desc":"Fitur couple-top","usage":".couple-top","group":true})
