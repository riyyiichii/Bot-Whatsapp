// cr: haimiya md saca
// fitur tambahan Haimiya MD (relationship/couple-date)
module.exports = require('../../lib/adapter/e9.js').plugin("relationship/couple-date", {"command":["couple-date"],"category":"rpg","desc":"Fitur couple-date","usage":".couple-date","group":true})
