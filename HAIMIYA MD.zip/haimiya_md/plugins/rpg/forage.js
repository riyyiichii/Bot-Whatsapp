// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/forage)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/forage", {"command":["forage"],"category":"rpg","desc":"Fitur forage","usage":".forage"})
