// cr: haimiya md saca
// fitur tambahan Haimiya MD (koboy/koboy-tembak)
module.exports = require('../../lib/adapter/e9.js').plugin("koboy/koboy-tembak", {"command":["koboy-tembak"],"category":"rpg","desc":"Fitur koboy-tembak","usage":".koboy-tembak"})
