// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/rpg-bansos)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/rpg-bansos", {"command":["rpg-bansos"],"category":"rpg","desc":"Fitur rpg-bansos","usage":".rpg-bansos","group":true})
