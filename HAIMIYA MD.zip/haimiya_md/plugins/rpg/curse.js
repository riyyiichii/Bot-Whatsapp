// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/curse)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/curse", {"command":["curse"],"category":"rpg","desc":"Fitur curse","usage":".curse"})
