// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/travel)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/travel", {"command":["travel"],"category":"rpg","desc":"Fitur travel","usage":".travel"})
