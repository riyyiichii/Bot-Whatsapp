// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/skill)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/skill", {"command":["skill"],"category":"rpg","desc":"Fitur skill","usage":".skill"})
