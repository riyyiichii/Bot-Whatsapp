// cr: haimiya md saca
// fitur tambahan Haimiya MD (zombie/zombie-pindah)
module.exports = require('../../lib/adapter/e9.js').plugin("zombie/zombie-pindah", {"command":["zombie-pindah"],"category":"rpg","desc":"Pindah lokasi","usage":".zombie-pindah"})
