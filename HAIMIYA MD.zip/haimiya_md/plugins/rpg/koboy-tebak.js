// cr: haimiya md saca
// fitur tambahan Haimiya MD (koboy/koboy-tebak)
module.exports = require('../../lib/adapter/e9.js').plugin("koboy/koboy-tebak", {"command":["koboy-tebak"],"category":"rpg","desc":"Fitur koboy-tebak","usage":".koboy-tebak"})
