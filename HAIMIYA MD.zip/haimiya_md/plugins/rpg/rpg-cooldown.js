// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/rpg-cooldown)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/rpg-cooldown", {"command":["rpg-cooldown"],"category":"rpg","desc":"Fitur rpg-cooldown","usage":".rpg-cooldown","group":true})
