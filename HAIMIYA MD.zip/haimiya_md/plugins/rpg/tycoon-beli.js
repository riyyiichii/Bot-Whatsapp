// cr: haimiya md saca
// fitur tambahan Haimiya MD (tycoon/tycoon-beli)
module.exports = require('../../lib/adapter/e9.js').plugin("tycoon/tycoon-beli", {"command":["tycoon-beli"],"category":"rpg","desc":"Toko perlengkapan","usage":".tycoon-beli"})
