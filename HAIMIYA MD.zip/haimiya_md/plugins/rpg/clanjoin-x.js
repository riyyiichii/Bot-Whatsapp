// cr: haimiya md saca
// fitur tambahan Haimiya MD (clan/clanjoin)
module.exports = require('../../lib/adapter/e9.js').plugin("clan/clanjoin", {"command":["clanjoin"],"category":"rpg","desc":"Gabung ke clan","usage":".clanjoin"})
