// cr: haimiya md saca
// fitur tambahan Haimiya MD (koboy/koboy-status)
module.exports = require('../../lib/adapter/e9.js').plugin("koboy/koboy-status", {"command":["koboy-status"],"category":"rpg","desc":"Fitur koboy-status","usage":".koboy-status"})
