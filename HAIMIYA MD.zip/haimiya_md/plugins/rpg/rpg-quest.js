// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/rpg-quest)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/rpg-quest", {"command":["rpg-quest"],"category":"rpg","desc":"Fitur rpg-quest","usage":".rpg-quest","group":true})
