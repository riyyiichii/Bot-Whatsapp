// cr: haimiya md saca
// fitur tambahan Haimiya MD (koboy/koboy-beli)
module.exports = require('../../lib/adapter/e9.js').plugin("koboy/koboy-beli", {"command":["koboy-beli"],"category":"rpg","desc":"Fitur koboy-beli","usage":".koboy-beli"})
