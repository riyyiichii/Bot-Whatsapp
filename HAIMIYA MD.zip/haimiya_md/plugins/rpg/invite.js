// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/invite)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/invite", {"command":["invite","undang","kodeinvite","pakaikode","redeeminvite","referral"],"category":"rpg","desc":"Fitur invite","usage":".invite"})
