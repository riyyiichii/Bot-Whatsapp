// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/karung)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/karung", {"command":["karung"],"category":"rpg","desc":"Fitur karung","usage":".karung","group":true})
