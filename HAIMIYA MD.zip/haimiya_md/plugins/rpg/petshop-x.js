// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/petshop)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/petshop", {"command":["petshop"],"category":"rpg","desc":"Beli pet dari toko","usage":".petshop"})
