// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/simulator)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/simulator", {"command":["simulator"],"category":"rpg","desc":"Fitur simulator","usage":".simulator"})
