// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/rpg-bagiuang)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/rpg-bagiuang", {"command":["rpg-bagiuang"],"category":"rpg","desc":"Fitur rpg-bagiuang","usage":".rpg-bagiuang","group":true})
