// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/duel)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/duel", {"command":["duel"],"category":"rpg","desc":"Duel PvP dengan player lain","usage":".duel","group":true})
