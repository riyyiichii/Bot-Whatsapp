// cr: haimiya md saca
// fitur tambahan Haimiya MD (zombie/zombie-rampas)
module.exports = require('../../lib/adapter/e9.js').plugin("zombie/zombie-rampas", {"command":["zombie-rampas"],"category":"rpg","desc":"Rampas perbekalan","usage":".zombie-rampas"})
