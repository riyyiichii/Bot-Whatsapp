// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/stamina)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/stamina", {"command":["stamina"],"category":"rpg","desc":"Cek dan pulihkan stamina","usage":".stamina"})
