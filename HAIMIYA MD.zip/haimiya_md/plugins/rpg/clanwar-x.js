// cr: haimiya md saca
// fitur tambahan Haimiya MD (clan/clanwar)
module.exports = require('../../lib/adapter/e9.js').plugin("clan/clanwar", {"command":["clanwar"],"category":"rpg","desc":"War melawan clan lain","usage":".clanwar"})
