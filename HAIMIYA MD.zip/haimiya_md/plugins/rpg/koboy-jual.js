// cr: haimiya md saca
// fitur tambahan Haimiya MD (koboy/koboy-jual)
module.exports = require('../../lib/adapter/e9.js').plugin("koboy/koboy-jual", {"command":["koboy-jual"],"category":"rpg","desc":"Fitur koboy-jual","usage":".koboy-jual"})
