// cr: haimiya md saca
// fitur tambahan Haimiya MD (economy/buathadiah)
module.exports = require('../../lib/adapter/e9.js').plugin("economy/buathadiah", {"command":["buathadiah"],"category":"rpg","desc":"Buat code hadiah (owner)","usage":".buathadiah","owner":true})
