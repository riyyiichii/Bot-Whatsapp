// cr: haimiya md saca
// fitur tambahan Haimiya MD (clan/clankick)
module.exports = require('../../lib/adapter/e9.js').plugin("clan/clankick", {"command":["clankick"],"category":"rpg","desc":"Kick member dari clan (leader only)","usage":".clankick"})
