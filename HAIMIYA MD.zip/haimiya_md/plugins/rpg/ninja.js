// cr: haimiya md saca
// fitur tambahan Haimiya MD (ninja/ninja)
module.exports = require('../../lib/adapter/e9.js').plugin("ninja/ninja", {"command":["ninja"],"category":"rpg","desc":"Menu ninja","usage":".ninja"})
