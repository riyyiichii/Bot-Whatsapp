// cr: haimiya md saca
// fitur tambahan Haimiya MD (ninja/ninja-duel)
module.exports = require('../../lib/adapter/e9.js').plugin("ninja/ninja-duel", {"command":["ninja-duel"],"category":"rpg","desc":"Duel ninja","usage":".ninja-duel"})
