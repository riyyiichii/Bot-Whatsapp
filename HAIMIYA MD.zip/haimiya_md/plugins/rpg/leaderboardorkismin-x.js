// cr: haimiya md saca
// fitur tambahan Haimiya MD (economy/leaderboardorkismin)
module.exports = require('../../lib/adapter/e9.js').plugin("economy/leaderboardorkismin", {"command":["leaderboardorkismin"],"category":"rpg","desc":"Ranking orang paling miskin versi Haimiya AI 🗿💸","usage":".leaderboardorkismin","group":true})
