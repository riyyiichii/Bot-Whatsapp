// cr: haimiya md saca
// fitur tambahan Haimiya MD (koboy/koboykejar)
module.exports = require('../../lib/adapter/e9.js').plugin("koboy/koboykejar", {"command":["koboykejar"],"category":"rpg","desc":"Fitur koboykejar","usage":".koboykejar"})
