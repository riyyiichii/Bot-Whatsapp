// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/trapwild)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/trapwild", {"command":["trapwild"],"category":"rpg","desc":"Fitur trapwild","usage":".trapwild"})
