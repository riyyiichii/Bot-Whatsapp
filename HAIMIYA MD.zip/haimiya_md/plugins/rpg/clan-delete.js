// cr: haimiya md saca
// fitur tambahan Haimiya MD (clan/clan-delete)
module.exports = require('../../lib/adapter/e9.js').plugin("clan/clan-delete", {"command":["clan-delete"],"category":"rpg","desc":"Hapus clan milikmu (ketua)","usage":".clan-delete","group":true})
