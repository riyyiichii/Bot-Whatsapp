// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/roket)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/roket", {"command":["roket"],"category":"rpg","desc":"Fitur roket","usage":".roket","group":true})
