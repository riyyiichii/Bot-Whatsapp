// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/livett)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/livett", {"command":["livett"],"category":"rpg","desc":"Fitur livett <judul>","usage":".livett"})
