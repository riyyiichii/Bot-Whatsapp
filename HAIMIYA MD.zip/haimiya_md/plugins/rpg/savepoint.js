// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/savepoint)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/savepoint", {"command":["savepoint"],"category":"rpg","desc":"Fitur savepoint","usage":".savepoint"})
