// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/mulai)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/mulai", {"command":["mulai"],"category":"rpg","desc":"Fitur mulai","usage":".mulai"})
