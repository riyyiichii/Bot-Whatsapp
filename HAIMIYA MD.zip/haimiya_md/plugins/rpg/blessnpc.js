// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/blessnpc)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/blessnpc", {"command":["blessnpc"],"category":"rpg","desc":"Fitur blessnpc","usage":".blessnpc"})
