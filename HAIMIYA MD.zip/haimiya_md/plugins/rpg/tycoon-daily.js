// cr: haimiya md saca
// fitur tambahan Haimiya MD (tycoon/tycoon-daily)
module.exports = require('../../lib/adapter/e9.js').plugin("tycoon/tycoon-daily", {"command":["tycoon-daily"],"category":"rpg","desc":"Bonus harian","usage":".tycoon-daily"})
