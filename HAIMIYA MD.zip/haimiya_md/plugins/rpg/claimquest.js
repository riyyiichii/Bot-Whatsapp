// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/claimquest)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/claimquest", {"command":["claimquest"],"category":"rpg","desc":"Klaim hadiah quest harian","usage":".claimquest"})
