// cr: haimiya md saca
// fitur tambahan Haimiya MD (relationship/addpasangan)
module.exports = require('../../lib/adapter/e9.js').plugin("relationship/addpasangan", {"command":["addpasangan"],"category":"rpg","desc":"Fitur addpasangan","usage":".addpasangan","owner":true})
