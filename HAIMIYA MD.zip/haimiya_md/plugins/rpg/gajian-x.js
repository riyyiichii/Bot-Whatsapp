// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/gajian)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/gajian", {"command":["gajian"],"category":"rpg","desc":"Fitur gajian","usage":".gajian","group":true})
