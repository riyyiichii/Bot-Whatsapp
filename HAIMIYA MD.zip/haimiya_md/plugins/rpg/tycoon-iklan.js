// cr: haimiya md saca
// fitur tambahan Haimiya MD (tycoon/tycoon-iklan)
module.exports = require('../../lib/adapter/e9.js').plugin("tycoon/tycoon-iklan", {"command":["tycoon-iklan"],"category":"rpg","desc":"Kampanye Iklan","usage":".tycoon-iklan"})
