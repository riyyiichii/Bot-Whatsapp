// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/rpg-kandang)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/rpg-kandang", {"command":["rpg-kandang"],"category":"rpg","desc":"Fitur rpg-kandang","usage":".rpg-kandang"})
