// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/polisi)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/polisi", {"command":["polisi"],"category":"rpg","desc":"Fitur polisi","usage":".polisi"})
