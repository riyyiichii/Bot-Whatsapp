// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/trade)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/trade", {"command":["trade"],"category":"rpg","desc":"Fitur trade","usage":".trade"})
