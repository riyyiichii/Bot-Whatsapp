// cr: haimiya md saca
// fitur tambahan Haimiya MD (koboy/koboy-tangkap)
module.exports = require('../../lib/adapter/e9.js').plugin("koboy/koboy-tangkap", {"command":["koboy-tangkap"],"category":"rpg","desc":"Fitur koboy-tangkap","usage":".koboy-tangkap"})
