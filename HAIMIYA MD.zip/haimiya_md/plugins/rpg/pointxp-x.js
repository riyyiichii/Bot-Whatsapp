// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/pointxp)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/pointxp", {"command":["pointxp"],"category":"rpg","desc":"Fitur pointxp","usage":".pointxp"})
