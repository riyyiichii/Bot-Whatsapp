// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/stash)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/stash", {"command":["stash"],"category":"rpg","desc":"Fitur stash","usage":".stash"})
