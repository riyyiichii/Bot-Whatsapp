// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/rumor)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/rumor", {"command":["rumor"],"category":"rpg","desc":"Fitur rumor","usage":".rumor"})
