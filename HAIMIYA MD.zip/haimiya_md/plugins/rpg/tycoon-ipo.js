// cr: haimiya md saca
// fitur tambahan Haimiya MD (tycoon/tycoon-ipo)
module.exports = require('../../lib/adapter/e9.js').plugin("tycoon/tycoon-ipo", {"command":["tycoon-ipo"],"category":"rpg","desc":"IPO Perusahaan","usage":".tycoon-ipo"})
