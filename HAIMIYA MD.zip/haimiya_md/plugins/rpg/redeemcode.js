// cr: haimiya md saca
// fitur tambahan Haimiya MD (economy/redeemcode)
module.exports = require('../../lib/adapter/e9.js').plugin("economy/redeemcode", {"command":["redeemcode"],"category":"rpg","desc":"Tukar code hadiah jadi limit","usage":".redeemcode"})
