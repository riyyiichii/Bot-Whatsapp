// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/medal)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/medal", {"command":["medal"],"category":"rpg","desc":"Fitur medal","usage":".medal"})
