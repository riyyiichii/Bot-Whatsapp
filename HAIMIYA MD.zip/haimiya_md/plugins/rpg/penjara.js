// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/penjara)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/penjara", {"command":["penjara","kabur","statuspenjara"],"category":"rpg","desc":"Fitur penjara @tag","usage":".penjara","group":true})
