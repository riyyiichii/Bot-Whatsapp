// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/creatett)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/creatett", {"command":["creatett"],"category":"rpg","desc":"Fitur creatett <username>","usage":".creatett"})
