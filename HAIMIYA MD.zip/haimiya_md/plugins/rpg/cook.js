// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/cook)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/cook", {"command":["cook"],"category":"rpg","desc":"Masak makanan dari resep","usage":".cook"})
