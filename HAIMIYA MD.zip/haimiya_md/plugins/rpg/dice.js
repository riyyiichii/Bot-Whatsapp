// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/dice)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/dice", {"command":["dice"],"category":"rpg","desc":"Lempar dadu untuk gambling","usage":".dice"})
