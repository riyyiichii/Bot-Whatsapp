// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/nyapu)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/nyapu", {"command":["nyapu"],"category":"rpg","desc":"Nyapu jalan, siapa tau nemu barang jatuh!","usage":".nyapu"})
