// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/farm)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/farm", {"command":["farm"],"category":"rpg","desc":"Bertani, panen gandum/apel","usage":".farm"})
