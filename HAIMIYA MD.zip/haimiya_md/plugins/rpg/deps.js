// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/deps)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/deps", {"command":["deps"],"category":"rpg","desc":"Fitur deps","usage":".deps","owner":true})
