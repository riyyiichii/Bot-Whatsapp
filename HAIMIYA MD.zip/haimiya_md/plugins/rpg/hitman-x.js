// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/hitman)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/hitman", {"command":["hitman"],"category":"rpg","desc":"Fitur hitman","usage":".hitman"})
