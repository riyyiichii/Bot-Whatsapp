// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/leveluprpg)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/leveluprpg", {"command":["leveluprpg"],"category":"rpg","desc":"Toggle notifikasi level up RPG","usage":".leveluprpg"})
