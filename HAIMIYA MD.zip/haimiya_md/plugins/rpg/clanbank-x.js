// cr: haimiya md saca
// fitur tambahan Haimiya MD (clan/clanbank)
module.exports = require('../../lib/adapter/e9.js').plugin("clan/clanbank", {"command":["clanbank"],"category":"rpg","desc":"Cek saldo kas clan","usage":".clanbank"})
