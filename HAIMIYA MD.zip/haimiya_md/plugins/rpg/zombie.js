// cr: haimiya md saca
// fitur tambahan Haimiya MD (zombie/zombie)
module.exports = require('../../lib/adapter/e9.js').plugin("zombie/zombie", {"command":["zombie"],"category":"rpg","desc":"Menu zombie","usage":".zombie"})
