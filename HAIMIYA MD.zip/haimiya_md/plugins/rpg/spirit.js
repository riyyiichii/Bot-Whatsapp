// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/spirit)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/spirit", {"command":["spirit"],"category":"rpg","desc":"Fitur spirit","usage":".spirit"})
