// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/bless)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/bless", {"command":["bless"],"category":"rpg","desc":"Fitur bless","usage":".bless"})
