// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/escrow)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/escrow", {"command":["escrow"],"category":"rpg","desc":"Fitur escrow","usage":".escrow"})
