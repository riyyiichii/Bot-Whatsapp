// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/hourly)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/hourly", {"command":["hourly"],"category":"rpg","desc":"Klaim hadiah per jam","usage":".hourly"})
