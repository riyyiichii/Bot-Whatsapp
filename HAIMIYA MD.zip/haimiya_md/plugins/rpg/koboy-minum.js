// cr: haimiya md saca
// fitur tambahan Haimiya MD (koboy/koboy-minum)
module.exports = require('../../lib/adapter/e9.js').plugin("koboy/koboy-minum", {"command":["koboy-minum"],"category":"rpg","desc":"Fitur koboy-minum","usage":".koboy-minum"})
