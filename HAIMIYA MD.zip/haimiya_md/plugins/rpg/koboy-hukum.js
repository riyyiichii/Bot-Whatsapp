// cr: haimiya md saca
// fitur tambahan Haimiya MD (koboy/koboy-hukum)
module.exports = require('../../lib/adapter/e9.js').plugin("koboy/koboy-hukum", {"command":["koboy-hukum"],"category":"rpg","desc":"Fitur koboy-hukum","usage":".koboy-hukum"})
