// cr: haimiya md saca
// fitur tambahan Haimiya MD (rpg/guild)
module.exports = require('../../lib/adapter/e9.js').plugin("rpg/guild", {"command":["guild"],"category":"rpg","desc":"Buat/join guild","usage":".guild"})
