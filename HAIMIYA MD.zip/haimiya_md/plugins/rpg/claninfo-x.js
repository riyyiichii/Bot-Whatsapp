// cr: haimiya md saca
// fitur tambahan Haimiya MD (clan/claninfo)
module.exports = require('../../lib/adapter/e9.js').plugin("clan/claninfo", {"command":["claninfo"],"category":"rpg","desc":"Lihat info clan","usage":".claninfo"})
