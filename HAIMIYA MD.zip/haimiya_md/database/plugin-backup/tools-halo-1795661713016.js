module.exports = {
  name: 'halo',
  command: ['halo', 'hai'],
  category: 'tools',
  desc: 'uji',
  run: async ({ reply }) => reply('halo')
}