// cr: haimiya md saca
/*
 ┌──────────────────────────────────────────────────────────────────┐
 │  SETTINGS — satu-satunya file pengaturan bot (gaya global.*)     │
 │  Ubah → simpan → restart bot.                                    │
 │  ⚠️  Jangan kirim/screenshot file ini: berisi kunci rahasia.      │
 └──────────────────────────────────────────────────────────────────┘

  DAFTAR ISI
   1. Identitas & stiker
   2. Menu & tampilan (thumbnail, animasi, audio)
   3. Mode rich / tampilan kartu
   4. Kontak & saluran
   5. Grup
   6. Downloader
   7. API key (semua kunci di satu tempat)
   8. Alamat dasar API
   9. Fitur tambahan (GitHub, Telegram, API utama plugins.zip)
  10. Payment gateway (AutoOrder QRIS)
  11. Panel Pterodactyl, VPS, SMM
  12. AI
  13. Lain-lain & pesan bot
*/


// ════════════════════════════════════════════════════════════════
//  1. IDENTITAS & STIKER
// ════════════════════════════════════════════════════════════════
global.botname       = 'Haimiya MD'      // nama bot
global.ownername     = 'Haimiya MD'      // nama owner
global.ownernumber   = '628984646117'          // nomor owner utama (tanpa + / spasi) → tampil di .owner, dipakai .report, dll
global.owner         = []                     // owner TAMBAHAN, mis. ['62812xxxxxxx'] (atau pakai .addowner / .claimowner)
global.prefix        = '.'
global.sessionName   = 'session'              // nama folder sesi login (jangan diubah kalau bot sudah login)
global.pairingNumber = ''                     // nomor WA bot untuk pairing code, mis. '628123456789' (kosong = ditanya di console, hanya kalau belum login)
global.packname      = 'Haimiya MD'      // nama pack stiker
global.author        = 'Haimiya MD'      // author stiker
global.stickerPack   = { packname: 'Haimiya MD', author: 'Haimiya' }   // dipakai fitur stiker tambahan
global.footer        = 'By Haimiya MD'
global.credit        = 'KurezaMD'        // kredit pembuat script (tampil di menu)


// ════════════════════════════════════════════════════════════════
//  2. MENU & TAMPILAN
// ════════════════════════════════════════════════════════════════
// ---- Thumbnail ----
global.thumbnail    = './media/thumbnail.jpg'   // foto thumbnail bot: link https://... ATAU path lokal './media/thumbnail.jpg' (kosong = gambar bawaan)
global.thumbnailGif = false                   // true = menu memakai GIF/video di bawah | false = hanya foto
global.thumbnailvid = ''                      // sumber GIF: link .mp4 ATAU path lokal './media/thumbnail.mp4' (link mati → otomatis foto)
global.fotoreply    = 'https://img3.pixhost.to/images/6927/798844258_media_1793795404996.jpg'   // foto reply palsu (kosong = pakai global.thumbnail). Ganti lewat .ubah reply
global.music        = 'https://cdn.nekohime.site/file/j8n4a9q4.mp4'   // voice note setelah menu ('' = nonaktif)

// ---- Alur .menu / .allmenu ----
// "Loading ." → "Loading .." → "Loading ..." → "Loading Complete ✓" (pesan di-EDIT) → menu asli → audio.
global.menuLoading      = true                // true = animasi loading sebelum menu | false = langsung menu
global.menuLoadingDelay = 500                 // jeda tiap frame animasi (milidetik)
global.menuWithAudio    = true                // true = kirim audio tepat di bawah menu | false = menu saja
global.menuAudio        = './media/menu.mp3'  // path lokal ATAU link https://... (file lokal tidak ada → pakai global.music)
global.menuAudioPtt     = false               // true = audio sebagai voice note | false = audio biasa
global.menuCommands     = ['menu', 'help', 'allmenu']   // perintah yang memakai alur ini
global.menuFlowMainOnly = true                // true = hanya .menu/.allmenu polos (pilih kategori lewat tombol tidak mengulang animasi & audio)
global.menuPromo        = 'Panel Kureza\n> harga murah, kualitas legal, no delay, terpercaya'   // teks paling bawah di semua menu ('' = mati)


// ════════════════════════════════════════════════════════════════
//  3. MODE RICH / TAMPILAN KARTU
// ════════════════════════════════════════════════════════════════
global.richMode       = true                  // pesan bertombol/carousel | false = teks biasa
global.richHints      = true                  // petunjuk "balas pesan ini dengan angka" di kartu bertombol
global.richNative     = true                  // true = rich HTML ASLI (bawaan) | false = matikan paksa (balasan jadi teks)
global.richAutoRender = true                  // true = kartu rich langsung tampil tanpa tombol "Unduh" | false = perilaku lama

global.uiMode   = 'text'                      // 'rich' = kartu RICH HTML | 'text' = teks biasa. Ganti lewat chat: .uimode rich / .uimode text
global.uiTheme  = 'haimiya'                   // tema kartu rich: koboy (bawaan) | obsidian | angker | neraka | iblis | aurora | sunset | ocean | emerald | sakura | gold | ruby | mono. Ganti lewat chat: .tema rich <nama>
global.uiCopy   = 'auto'                      // tombol Salin di mode rich: 'auto' (hasil berisi data) | 'all' (semua balasan) | 'off'
global.uiPlain  = []                          // perintah yang tetap teks biasa, mis. ['ai', 'hash']
global.uiRestyle = true                      // true = bingkai ╭─「 」┃ bawaan engine lain diubah jadi gaya Haimiya (judul tebal + butir) | false = apa adanya
global.uiBotJid = '867051314767696@bot'       // JID bot untuk pesan rich (sama seperti di ytPlayer)
global.uiMenuBanner = false                   // true = banner foto di atas kartu menu rich (tema koboy: assets/koboy-banner.jpg, tema lain: thumbnail)
global.uiBanner       = false                 // false = tanpa foto banner di kartu (kartu lebih ringan, tidak kepotong saat dikirim)
global.uiNavButtons = false                   // true = tampilkan tombol native "Tap Here!" di bawah kartu menu
global.uiTapLink    = false                   // true = tap perintah di kartu membuka chat bot dengan perintah terisi (wa.me)


// ════════════════════════════════════════════════════════════════
//  4. KONTAK & SALURAN
// ════════════════════════════════════════════════════════════════
global.ig       = 'vnzgg85'
global.tele     = 'Haimiya MD'
global.saluran  = 'https://whatsapp.com/channel/0029Vb7JOvhEwEjnQgO8Ui3d'
global.wagc     = 'https://chat.whatsapp.com/FMD3px1d5iQ9cxY18SEkZs'
global.channel  = '120363424132521336@newsletter'   // JID channel untuk label "Diteruskan" ('' = nonaktif)
global.channeln = 'Haimiya MD'                 // nama channel untuk label tsb

// ════════════════════════════════════════════════════════════════
//  5. GRUP
// ════════════════════════════════════════════════════════════════
global.antilink  = { maxWarn: 3 }             // setelah N peringatan pelanggar dikeluarkan (0 = hanya hapus + peringatan)
global.warnLimit = 3                          // batas .warn / antibadword sebelum dikeluarkan (bot harus admin)


// ════════════════════════════════════════════════════════════════
//  6. DOWNLOADER
// ════════════════════════════════════════════════════════════════
global.downloader = {
  maxMB: 80,                                  // batas ukuran file
  maxImages: 10,                              // batas foto/slide per permintaan
  ytQuality: '720',                           // 360 / 480 / 720 / 1080
  cobalt: { url: '', apiKey: '' },            // opsional (instance cobalt milikmu)
  scriptmind: true,                           // YouTube lewat scriptmind.co
  ytultra: true,                              // YouTube lewat ytultra.com
  cobaltPool: true,                           // cobalt komunitas (instances.cobalt.best)
  scrapers: true,                             // TikTok (mobile API, snaptik) & Instagram (savefromins, instaloadr)
  ytdlp: {
    path: '',                                 // kosong = otomatis
    cookies: '',                              // path cookies.txt (atau kirim lewat .ytcookies)
    proxy: '',                                // mis. 'http://user:pass@host:port' (atau .ytdlp proxy)
    autoInstall: true,
    maxMinutes: 30
  }
}


// ════════════════════════════════════════════════════════════════
//  7. API KEY  — semua kunci fitur dikumpulkan di sini
//     Isi di antara tanda kutip → simpan → restart bot.
//     Kosong = fitur terkait membalas "butuh apikey" (bot tidak crash).
// ════════════════════════════════════════════════════════════════
// ---- AI & pencarian ----
global.geminikey   = 'AQ.Ab8RN6Ibl0uRvS5ijViprP258v5zwCMIklcGzLXiJPpQXUcIPQ'   // Google Gemini   → https://aistudio.google.com/apikey (gratis). Dipakai: vision/nanobanana, .aiagent, AI gambar
global.groqkey     = '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'   // Groq            → https://console.groq.com/keys (gratis). Dipakai: .transkrip, .aiagent
global.aquakey     = 'SK-wmKywW4bb47ib9K8w37rhuw'                                  // Free-RestAPI    → https://free-restapi.biz.id . Dipakai: .ai-models .kimi-vision .talkingphoto .age-detection .gpt2image
global.fishkey     = ''                       // Fish Audio      → https://fish.audio (menu API Keys). Dipakai: suara AI
global.youtubekey  = ''                       // YouTube Data v3 → https://console.cloud.google.com . Dipakai: pencarian YouTube resmi

// ---- Downloader & media ----
global.loaderkey   = 'dfcb6d76f2f6a9894gjkege8a4ab232222'   // loader.to/savenow → https://loader.to . Dipakai: .ytmp3 .ytmp4
global.topmediakey = 'dac23a9006fc4039ae6aac98ae7c7b46'     // TopMedia          → scraper media. Ganti kalau pemilik layanan memberi kunci baru
global.anabotkey   = 'freeApikey'             // Anabot       → https://anabot.my.id (kunci publik 'freeApikey'). Dipakai: .ringtone .izen, downloader cadangan
global.miftahkey   = 'miftah'                 // Miftahganzz  → https://api.miftahganzz.my.id (kunci publik). Dipakai: downloader Twitter cadangan
global.cukikey     = 'cuki-x'                 // Cuki API     → https://api.cuki.biz.id (kunci publik 'cuki-x'). Dipakai: .pin .pap .lahelu .susutaro .hotline dll

// ---- Maker, stiker & hiburan ----
global.lolkey      = '65663da894ff86ca7fdd8b3a'   // LoLHuman → https://api.lolhuman.xyz (Dashboard). Dipakai: .superhero .stikerwa .kannabrat .ohno .meme2 .meme3 .pacarsertifikat .facedetector
global.neoxrkey    = 'wva249cmayitsulf0nqevf'     // Neoxr    → https://api.neoxr.eu (dashboard). Dipakai ±90 fitur: .attp2 .emojimix .getmusik .carimusik .pixiv .bingimage .jadwalbola dll
global.theresavkey = 'JpLZ3'                  // Theresav → https://api.theresav.biz.id . Dipakai: .bratcewek2 .animebrat2 .animebrat3
global.fgsikey     = ''                       // FGSI     → https://fgsi.dpdns.org (format fgsiapi-xxxx). Dipakai: .sora2 dll
global.fireflykey  = ''                       // Firefly  → https://firefly.maiku.my.id . Dipakai: .pinvid .text2img .npmstalk .ytstalk
global.albykey     = ''                       // Alby     → https://albyoffc.my.id (format albymd-xxxx). Dipakai: .suppbypass
global.xrinakey    = ''                       // Xrina    → https://apiii-xrina.vercel.app (minta ke pemilik API). Dipakai: .rch (react channel)
global.btc         = ''                       // BetaBotz → https://api.betabotz.eu.org (format btz-xxxx). Dipakai fitur hasil port yang memanggil api.betabotz
global.xyro        = ''                       // Xyroinee → https://api.xyroinee.xyz (menu Profile/Dashboard). Dipakai fitur hasil port yang memanggil api.xyroinee

// ---- Layanan lain ----
global.jasaotpkey  = ''                       // JasaOTP  → https://jasaotp.id (menu API). Dipakai: .nokos versi JasaOTP
global.pitucodekey = '7C0dEefbfc1'            // PituCode → https://api.pitucode.com . Dipakai: .ceknamadana (cek nama e-wallet)

// ---- Kumpulan kunci (dibaca plugin lewat global.apiKeys.<nama>) ----
global.apiKeys = {
  // kunci khusus fitur tertentu
  kyzz: 'kyzz87061175',                       // WAJIB untuk: .brat(black/green/pink/gojo/v2/vermeil/vid*) .qc .ssweb .twitstalk
  azbry: '',                                  // .spotifydl (bila API-nya meminta kunci)
  siputzx: '',
  covenant: '',                               // .melolo (bila penyedia API meminta kunci)
  obscura: '',                                // api.obscuraworks.org → .nikparser
  vercel: '',                                 // token Vercel → .deploy (owner)
  shoppanel: 'sk_live_f2bf413384ed6a217da3ed7b870e19370182f0d632dccc00',   // reseller API panel → .produkpanel .belipanel .cekpay dst.
  vamx: 'vamx_live_b11467d947846ab9c3412d2059197ba6',                      // .nftoken .netflixtoken .nftv (kunci bawaan fitur; ganti kalau punya sendiri)
  // dari daftar di atas
  lolhuman: global.lolkey,   betabotz: global.btc,        xyroinee: global.xyro,
  neoxr: global.neoxrkey,    cuki: global.cukikey,        anabot: global.anabotkey,   theresav: global.theresavkey,
  miftah: global.miftahkey,  fgsi: global.fgsikey,        alby: global.albykey,       xrina: global.xrinakey,
  firefly: global.fireflykey, aqua: global.aquakey,       gemini: global.geminikey,
  groq: global.groqkey,      jasaotp: global.jasaotpkey,  fishaudio: global.fishkey,  youtube: global.youtubekey,
  topmedia: global.topmediakey, loaderto: global.loaderkey, pitucode: global.pitucodekey
}


// ════════════════════════════════════════════════════════════════
//  8. ALAMAT DASAR API  (ganti kalau alamat penyedia berubah)
// ════════════════════════════════════════════════════════════════
global.APIs = {
  kyzz: 'https://api.kyzzz.xyz',
  siputzx: 'https://api.siputzx.my.id',
  azbry: 'https://api.azbry.com',
  deline: 'https://api.deline.web.id'         // .bratcewek
}


// ════════════════════════════════════════════════════════════════
//  9. FITUR TAMBAHAN
// ════════════════════════════════════════════════════════════════
// ---- API utama fitur dari plugins.zip (±200 fitur ai/downloader/maker/game/dll) ----
// Memakai satu penyedia REST API lewat global.web + global.apikey.vxapi.
// Kunci kosong = fitur terkait membalas error dari server. Ganti global.web bila domain penyedia API kamu beda.
global.web    = 'https://api.jerexd.my.id'
global.apikey = { vxapi: 'OZIlRr2fEizs5Y1S' }

// ---- GitHub & Telegram ----
global.ghTokens = ''                          // token GitHub (classic, scope: gist + repo) → .gist .upgh/.url/.cdn .ubah
global.userGh   = ''                          // username pemilik token (repo CDN cdn1..cdn5 dibuat otomatis)
global.tgToken  = '9130034756:AAFLnSB5HFW_6aGCAYul70W9Ofb29ehnW4U'   // token bot Telegram (dari @BotFather) → .sticketele


// ════════════════════════════════════════════════════════════════
// 10. PAYMENT GATEWAY (AutoOrder QRIS)
//     Docs: https://auto-order.alxzyy.my.id/docs — QRIS otomatis (order toko, topup saldo bot, premium)
// ════════════════════════════════════════════════════════════════
global.autoorder = {
  apiKey: 'AOC-32B4A15AFEB7511213E8CBD112D2A82A8403BE533F047184',   // X-API-Key dari dashboard AutoOrder (kosong = QRIS otomatis mati)
  baseUrl: 'https://auto-order.alxzyy.my.id/api/v2',
  storageKey: '',                             // key Storage (ak_live_...) bila beda dari apiKey; kosong = pakai apiKey
  minTopup: 1000,                             // minimal topup saldo bot (Rp). Batas API: 300
  maxTopup: 1000000,                          // maksimal sekali bayar (Rp). Batas API: 10.000.000
  topupRate: 1,                               // 1 Rp = N saldo bot (money). Contoh 10 → bayar Rp1.000 dapat 10.000 money
  maxPending: 3,                              // maksimal tagihan QRIS belum dibayar per user
  premium: { 7: 5000, 30: 15000 },            // paket premium otomatis { hari: harga Rp }. {} = matikan .premqris
  nokos: true,                                // jual nomor virtual OTP (.nokos); harga dipotong dari saldo bot pembeli, modal dari saldo AutoOrder
  nokosMarkup: { percent: 10, flat: 0 }       // harga jual = (harga API × (1 + percent/100)) + flat, lalu × topupRate jadi saldo bot
}


// ════════════════════════════════════════════════════════════════
// 11. PANEL PTERODACTYL, VPS, SMM
// ════════════════════════════════════════════════════════════════
// ---- Pterodactyl multi-server (v1–v5) ----
// Dipakai: cadminv1..v5, listserverv1..v5, delserverv1..v5, serverinfov1..v5, listadminv1..v5, deladminv1..v5, gcseller, rolemanager
// Kosongkan domain/apikey server yang tidak dipakai. ownerPanels/sellers = nomor (tanpa +) yang boleh mengelola panel.
global.pterodactyl = {
  ownerPanels: [],
  sellers: [],
  server1: { domain: '', apikey: '', capikey: '', egg: 15, nestid: 5, location: 1 },
  server2: { domain: '', apikey: '', capikey: '', egg: 15, nestid: 5, location: 1 },
  server3: { domain: '', apikey: '', capikey: '', egg: 15, nestid: 5, location: 1 },
  server4: { domain: '', apikey: '', capikey: '', egg: 15, nestid: 5, location: 1 },
  server5: { domain: '', apikey: '', capikey: '', egg: 15, nestid: 5, location: 1 }
}

// ---- VPS DigitalOcean (.createvps .listvps .cekvps .delvps) ----
global.digitalocean = {
  token: '',                                  // API token DigitalOcean (kosong = fitur VPS nonaktif)
  region: 'sgp1',
  ownerPanels: [],
  sellers: []
}

// ---- SMM / suntik sosmed (.smmorder .smmservices .smmstatus) ----
global.alipshop = { baseUrl: '', apiKey: '' } // kosong = fitur SMM menampilkan peringatan belum diatur


// ════════════════════════════════════════════════════════════════
// 12. AI (.ai)
// ════════════════════════════════════════════════════════════════
global.ai = {
  provider: 'openai',                         // 'openai' (kompatibel OpenAI/OpenRouter/Groq) | 'anthropic' (Claude resmi)
  url: 'https://api.openai.com/v1/chat/completions',
  apiKey: '',                                 // ISI DI SINI. Kosong = pakai layanan gratis (Pollinations)
  model: 'gpt-4o-mini',                       // untuk anthropic mis. 'claude-sonnet-5-5'
  free: { url: 'https://gen.pollinations.ai/v1/chat/completions', model: 'openai' },
  system: 'Kamu adalah Haimiya MD, asisten WhatsApp yang ramah dan membantu. Jawab singkat, jelas, dan dalam bahasa yang dipakai pengguna.'
}


// ════════════════════════════════════════════════════════════════
// 13. LAIN-LAIN & PESAN BOT
// ════════════════════════════════════════════════════════════════
global.weather = { name: 'Jakarta, Indonesia', lat: -6.2088, lon: 106.8456 }

global.mess = {
  error: {
    fitur: 'Hah?! Eror?! 💢 Ini pasti gara-gara kamu yang aneh-aneh! Sana laporin ke Haimiya MD (628984646117) biar dia yang urus! 😤'
  },
  only: {
    group: 'Hmph! 😤 Fitur ini cuma bisa dipake di dalam grup ya! Jangan sok asik mau pake di sini!',
    owner: 'Fitur ini hanya dapat digunakan oleh owner.',
    admin: 'Sadar diri dong! 😤 Fitur ini khusus buat Admin grup aja. Kamu kan bukan siapa-siapa di sini!',
    badmin: 'Gimana aku mau kerja kalau aku nggak dijadiin Admin? 💢 Cepetan jadiin aku Admin dulu, baru aku bantuin!'
  }
}
